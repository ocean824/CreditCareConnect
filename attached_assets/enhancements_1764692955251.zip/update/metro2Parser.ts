import { spawn } from 'child_process';

/**
 * Types for parsed Metro 2 content. A Metro 2 file contains a header record,
 * a base segment per account, and optional segments (J1, J2, K1–K4, L1, N1).
 * Each alphanumeric field must be left‑justified and blank‑filled and monetary
 * values must be reported in whole dollars, with cents truncated【442302616850999†L34-L55】.
 */
export interface Metro2BaseSegment {
  accountNumber: string;
  consumer: string;
  balance: number;
  // add other fields as needed
}

export interface Metro2OptionalSegment {
  type: string;
  data: Record<string, unknown>;
}

export interface Metro2Record {
  header: Record<string, unknown>;
  baseSegments: Metro2BaseSegment[];
  optionalSegments: Metro2OptionalSegment[];
  trailer: Record<string, unknown>;
}

/**
 * Parse a Metro 2 file using the moov-io/metro2 CLI. This implementation
 * spawns the Metro2 binary with the `validate` command and the `--json`
 * flag, which causes the tool to parse the file into JSON. The moov-io
 * project implements a reader, writer and validator for consumer credit
 * history reports in an HTTP server and Go library【963798989112927†L41-L46】.  In a real
 * deployment you could instead depend on a JavaScript/TypeScript parser or
 * call the HTTP server directly.
 *
 * Note: the Metro2 CLI must be installed and available on the system
 * `PATH`. If it's not available this function will reject.
 */
export async function parseMetro2File(filePath: string): Promise<Metro2Record> {
  return new Promise((resolve, reject) => {
    const proc = spawn('metro2', ['validate', filePath, '--json']);
    let stdout = '';
    let stderr = '';
    proc.stdout.on('data', (chunk: Buffer) => {
      stdout += chunk.toString();
    });
    proc.stderr.on('data', (chunk: Buffer) => {
      stderr += chunk.toString();
    });
    proc.on('close', (code: number) => {
      if (code !== 0) {
        return reject(new Error(`Metro2 CLI exited with code ${code}: ${stderr}`));
      }
      try {
        const result = JSON.parse(stdout);
        resolve(result as Metro2Record);
      } catch (err) {
        reject(err);
      }
    });
  });
}