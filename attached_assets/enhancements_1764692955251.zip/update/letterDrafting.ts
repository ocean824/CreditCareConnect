import { OpenAIApi, Configuration } from 'openai';
import { Violation } from './fcraRules';

// Data structure representing basic consumer information needed for the letter.
export interface ConsumerInfo {
  name: string;
  address: string;
  reportDate: string;
  bureau: string;
}

// Create an OpenAI client using API key from environment variables.  Be sure
// to configure OPENAI_API_KEY in your environment or secrets.  If you
// integrate with a different LLM, adjust accordingly.
const openai = new OpenAIApi(
  new Configuration({
    apiKey: process.env.OPENAI_API_KEY,
  })
);

/**
 * Generate a dispute letter using a large language model.  This function
 * constructs a prompt based on the DocsBot AI prompt template for credit
 * repair dispute letters【761844791029762†L34-L60】.  It enumerates each violation,
 * including the FCRA section codes, and asks the LLM to craft a firm yet
 * professional letter demanding correction.  The returned letter should be
 * ready to send to the relevant credit bureau.
 */
export async function draftDisputeLetter(
  violations: Violation[],
  consumer: ConsumerInfo,
  accountEntries: { accountNumber: string; description?: string }[]
): Promise<string> {
  // Build a summary of violations for the prompt
  const violationSummary = violations
    .map((v, idx) => `${idx + 1}. [${v.code}] ${v.description} (FCRA ${v.fcraSection})`)
    .join('\n');

  const itemsSummary = accountEntries
    .map((item) => `Account ${item.accountNumber}: ${item.description ?? 'see report details'}`)
    .join('\n');

  const prompt = `You are an expert credit repair specialist tasked with generating aggressive, legally compliant dispute letters for negative items on a ${consumer.bureau} credit report.\n\n` +
    `Consumer Name: ${consumer.name}\nConsumer Address: ${consumer.address}\nReport Date: ${consumer.reportDate}\n\n` +
    `Negative Items:\n${itemsSummary}\n\n` +
    `Violations:\n${violationSummary}\n\n` +
    `Draft a professional, firm and legally forceful dispute letter that:\n` +
    `- Prioritizes claims that each negative item is inaccurate, outdated or incomplete.\n` +
    `- Cites the strongest relevant legal codes and specific violations applicable under federal law, such as the Fair Credit Reporting Act (FCRA), and any Metro 2 compliance code where appropriate.\n` +
    `- Makes clear, enforceable demands for the permanent deletion or correction of each negative item based on these violations.\n` +
    `- Explains the consumer's rights under the law in clear, precise terms.\n` +
    `- Adheres strictly to all legal compliance requirements regarding dispute communications.\n` +
    `Write the letter as a formal business letter addressed to the credit bureau. Include placeholders for the consumer’s identifying information, date, and signature.\n`;

  const completion = await openai.createChatCompletion({
    model: process.env.OPENAI_MODEL || 'gpt-4',
    messages: [
      { role: 'system', content: 'You are a helpful assistant that drafts credit report dispute letters.' },
      { role: 'user', content: prompt },
    ],
    temperature: 0.4,
  });

  const letter = completion.data.choices[0]?.message?.content?.trim() || '';
  return letter;
}