/**
 * Definitions of FCRA violation detection rules. These rules implement
 * additional compliance checks beyond the original examples provided in the
 * application.  They mirror common Fair Credit Reporting Act (FCRA)
 * violations described by legal experts【713945439834194†L107-L136】.  Each rule examines
 * a parsed credit report entry and returns an array of violation objects when
 * applicable.  Violation objects include a code, a description and the
 * relevant FCRA section to help strengthen dispute letters.
 */

export interface Violation {
  /** Unique code identifying the violation type. */
  code: string;
  /** Human‑readable description of the issue discovered. */
  description: string;
  /** Specific FCRA section or Metro 2 code supporting the violation. */
  fcraSection: string;
}

// Example of a parsed account entry from a credit report or Metro 2 base segment
export interface AccountEntry {
  accountNumber: string;
  balance: number;
  status: string;
  dateOpened?: Date;
  dateReported?: Date;
  dischargedInBankruptcy?: boolean;
  isDisputed?: boolean;
  // Add additional fields from Metro 2 or PDF parser as needed
}

/**
 * Rule: failing to note disputed debts.  If an entry is marked as disputed by
 * the consumer but the credit report does not contain the dispute flag, this
 * rule returns a violation.  FCRA requires credit reporting agencies to note
 * disputed debts; failure to do so can lead to additional collection actions
 * against the consumer【713945439834194†L107-L111】.
 */
export function ruleDisputedDebt(entry: AccountEntry): Violation[] {
  const violations: Violation[] = [];
  if (entry.isDisputed && entry.status !== 'disputed') {
    violations.push({
      code: 'FCRA_DISPUTE_NOT_NOTED',
      description:
        'The account is currently in dispute, but the credit report does not note the dispute, which violates FCRA requirements for disputed debts',
      fcraSection: '§1681s-2(a)(3)',
    });
  }
  return violations;
}

/**
 * Rule: reporting inaccurate or outdated information.  Creditors must verify
 * their data and correct inaccuracies; reporting resolved debts as unpaid or
 * delinquent harms consumers【713945439834194†L113-L118】.  This rule checks for
 * negative statuses when the balance is zero or the account has been closed.
 */
export function ruleInaccurateInformation(entry: AccountEntry): Violation[] {
  const violations: Violation[] = [];
  if ((entry.balance === 0 || entry.status === 'closed') && entry.status === 'delinquent') {
    violations.push({
      code: 'FCRA_INACCURATE_INFO',
      description:
        'The account has been paid off or closed, but it is still reported as delinquent, violating accuracy requirements under the FCRA',
      fcraSection: '§1681e(b)',
    });
  }
  return violations;
}

/**
 * Rule: continuing to report expired data.  Negative financial data generally
 * drops off a credit report after seven years, or sooner in some cases【713945439834194†L120-L124】.  This rule flags entries
 * whose dateOpened is older than seven years and still reported as negative.
 */
export function ruleExpiredData(entry: AccountEntry): Violation[] {
  const violations: Violation[] = [];
  const sevenYearsMs = 7 * 365 * 24 * 60 * 60 * 1000;
  if (entry.dateOpened && entry.status === 'negative') {
    const age = Date.now() - entry.dateOpened.getTime();
    if (age > sevenYearsMs) {
      violations.push({
        code: 'FCRA_EXPIRED_DATA',
        description:
          'Negative data is being reported more than seven years after the account was opened, which violates FCRA limitations on reporting expired data',
        fcraSection: '§1681c(a)',
      });
    }
  }
  return violations;
}

/**
 * Rule: misclassifying debt discharged by bankruptcy.  When a debt is
 * discharged in bankruptcy, it must be reported as discharged.  Reporting
 * discharged debt as active or charged‑off misleads other creditors and is a
 * common FCRA violation【713945439834194†L126-L130】.
 */
export function ruleBankruptcyMisclassification(entry: AccountEntry): Violation[] {
  const violations: Violation[] = [];
  if (entry.dischargedInBankruptcy && entry.status !== 'discharged') {
    violations.push({
      code: 'FCRA_BANKRUPTCY_MISCLASS',
      description:
        'A debt discharged in bankruptcy is misreported as active or charged‑off, violating FCRA requirements for accurate reporting of bankruptcy status',
      fcraSection: '§1681c(a)(1)',
    });
  }
  return violations;
}

/**
 * Rule: mixing files of different consumers.  Creditors and reporting agencies
 * must keep each consumer’s records distinct; mixing files can incorrectly add
 * debts and late payments to another consumer’s report【713945439834194†L132-L135】.  This rule
 * flags an entry if the consumer identifier does not match the primary
 * consumer of the report.
 */
export function ruleMixedFiles(entry: AccountEntry, primaryConsumerId: string): Violation[] {
  const violations: Violation[] = [];
  // In a real implementation, entry would contain a consumer identifier
  const entryConsumerId = (entry as any).consumerId;
  if (entryConsumerId && entryConsumerId !== primaryConsumerId) {
    violations.push({
      code: 'FCRA_MIXED_FILES',
      description:
        'Account data appears to belong to a different consumer, indicating a mixed file error',
      fcraSection: '§1681e(b)',
    });
  }
  return violations;
}

/**
 * Execute all FCRA rules against a given account entry.  This helper
 * aggregates the results of each rule into a single array.
 */
export function evaluateFCRARules(entry: AccountEntry, primaryConsumerId: string): Violation[] {
  return [
    ...ruleDisputedDebt(entry),
    ...ruleInaccurateInformation(entry),
    ...ruleExpiredData(entry),
    ...ruleBankruptcyMisclassification(entry),
    ...ruleMixedFiles(entry, primaryConsumerId),
  ];
}