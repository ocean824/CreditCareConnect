import React from 'react';

export interface ReviewEntry {
  id: string;
  accountNumber: string;
  description: string;
  violations: string[];
  flagged: boolean;
}

export interface ReportReviewProps {
  entries: ReviewEntry[];
  onToggleFlag: (entryId: string, flagged: boolean) => void;
}

/**
 * ReportReview is a React component that allows users to review parsed credit
 * report entries and confirm or override detected violations before letter
 * generation.  Each row displays the account number, a summary and the
 * violations identified by the rules engine.  Users can toggle a checkbox to
 * include or exclude an item from dispute letters or edit the description as
 * needed.
 */
const ReportReview: React.FC<ReportReviewProps> = ({ entries, onToggleFlag }) => {
  return (
    <div className="space-y-4">
      {entries.map((entry) => (
        <div
          key={entry.id}
          className="border p-4 rounded-md shadow-sm flex flex-col md:flex-row md:items-center md:justify-between"
        >
          <div className="flex-1">
            <div className="font-medium">Account {entry.accountNumber}</div>
            <div className="text-sm text-gray-600 mt-1">{entry.description}</div>
            {entry.violations.length > 0 && (
              <ul className="mt-2 text-xs text-red-600 list-disc pl-5">
                {entry.violations.map((v, idx) => (
                  <li key={idx}>{v}</li>
                ))}
              </ul>
            )}
          </div>
          <div className="mt-3 md:mt-0 md:ml-4 flex items-center">
            <label className="inline-flex items-center">
              <input
                type="checkbox"
                className="form-checkbox h-4 w-4 text-blue-600"
                checked={entry.flagged}
                onChange={(e) => onToggleFlag(entry.id, e.target.checked)}
              />
              <span className="ml-2 text-sm">Include in dispute</span>
            </label>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ReportReview;