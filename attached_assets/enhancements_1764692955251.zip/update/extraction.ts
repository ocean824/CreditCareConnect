import fs from 'fs';
import pdfParse from 'pdf-parse';
import { createWorker } from 'tesseract.js';

/**
 * Extract text from a PDF or other report file using multiple strategies.  The
 * pipeline first attempts to extract text using pdf-parse (suitable for
 * digital PDFs).  If the extracted text is empty or below a threshold, it
 * falls back to OCR using Tesseract.js to handle scanned documents or images.
 * Additional extraction methods (e.g., tabular extraction via camelot or
 * tabula) could be incorporated as needed.
 */
export async function extractReportText(filePath: string): Promise<string> {
  // Try to read the PDF file
  const dataBuffer = await fs.promises.readFile(filePath);
  let text = '';
  try {
    const parsed = await pdfParse(dataBuffer);
    text = parsed.text.trim();
  } catch (err) {
    console.warn('pdf-parse failed, falling back to OCR:', err);
  }
  // If pdf-parse succeeded and found substantial text, return it
  if (text && text.length > 200) {
    return text;
  }
  // Fall back to OCR with Tesseract.js
  const worker = await createWorker();
  await worker.loadLanguage('eng');
  await worker.initialize('eng');
  const { data } = await worker.recognize(dataBuffer);
  await worker.terminate();
  return data.text.trim();
}