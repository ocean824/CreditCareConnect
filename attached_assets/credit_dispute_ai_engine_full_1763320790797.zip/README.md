# Credit Dispute AI Engine

This project is a Replit-ready, AI-enhanced credit dispute engine that:

- Parses tri-merge credit reports (e.g., IdentityIQ PDFs -> normalized JSON).
- Detects issues using FCRA, FDCPA, and Metro 2–style rules.
- Generates three rounds of dispute letters for credit bureaus (CRA) and collectors.
- Exports dispute letters as PDF and DOCX for download.
- Provides REST endpoints for upload, job status, and letter download.

## Stack

- Runtime: Node.js 20 (Replit)
- Language: TypeScript
- Framework: Express
- PDF export: `pdf-lib`
- DOCX export: `docx`

## Key Folders

- `src/types.ts` – Core TypeScript models (accounts, issues, letters, profiles).
- `src/rules/` – Balance/status rules and issue detection logic.
- `src/engine/analyze.ts` – Main violation engine entrypoint.
- `src/templates/` – CRA and collector letter templates (3-round CRA, LVNV/Jefferson FDCPA).
- `src/utils/` – PDF/DOCX exporters.
- `src/services/DisputeEngineService.ts` – DisputeEngineService + in-memory queue & worker.
- `src/pipeline/creditReportPipeline.ts` – High-level pipeline for a single PDF.
- `src/routes/disputes.ts` – REST endpoints:
  - `POST /api/reports/upload`
  - `GET /api/reports/:jobId/status`
  - `GET /api/letters/:letterId.pdf?jobId=...`
  - `GET /api/letters/:letterId.docx?jobId=...`
- `data/sample_accounts_with_violations.json` – Sample parsed accounts with realistic violations.
- `python/violation_engine.py` – Python version of the violation engine (optional microservice).
- `docs/REPLIT_AGENT_PROMPT.md` – Prompt & design brief for Replit Agent.

## Quickstart on Replit

1. Upload this ZIP into a new Replit Node.js project and extract.
2. Run:

   ```bash
   npm install
   npm start
   ```

3. The server will listen on `PORT` (default 5000 on local; on Replit it uses the assigned port).

4. Test upload endpoint (e.g. via Postman / curl):

   ```bash
   curl -X POST https://your-repl-url/api/reports/upload \
     -F "report=@/path/to/report.pdf" \
     -F 'consumer={ "fullName": "John Doe", "addressLine1": "123 Main", "city": "Naples", "state": "FL", "postalCode": "34117" }' \
     -F "round=1"
   ```

5. Use returned `jobId` with:

   - `GET /api/reports/:jobId/status`
   - `GET /api/letters/:letterId.pdf?jobId=...`
   - `GET /api/letters/:letterId.docx?jobId=...`

Replace the dummy IdentityIQ parser in `pdfToAccounts` when you're ready to parse real PDFs.
