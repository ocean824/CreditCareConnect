# Replit Agent Prompt – Credit Dispute AI Engine

## Project Name

**Credit Dispute AI Engine**

## Project Description

Create and maintain a multi-step, AI-powered application that analyzes credit reports (e.g., IdentityIQ tri-merge PDFs) and generates legally styled dispute letters in 3 progressive rounds. The system must:

- Detect data inconsistencies across bureaus.
- Apply FCRA, FDCPA, and Metro 2–inspired logic to each tradeline.
- Produce consumer-friendly outputs **without** exposing internal AI reasoning (no chain-of-thought leakage to end users).
- Generate letters for both credit reporting agencies (CRAs) and debt collectors/ debt buyers (e.g., LVNV, Jefferson).

## Platform & Hosting

- **Platform:** Web (HTTP API + optional UI)
- **Online/Offline:** Online (uses APIs, OCR, and optionally OpenAI)
- **Hosting:** Replit default hosting (Node.js 20)
- Optional future integration: GCP, external queues, or separate Python microservices.

## Interface Style

- Minimalist, structured, legal-document inspired.
- Tabbed or panel-based layout.
- Clean, readable fonts.
- Form-driven: upload PDF → see parsed accounts → view detected issues & letters.

## Languages

- **App Interface Language:** English
- **Interaction Language with Replit Agent:** English

---

## Core Modules & Responsibilities

### 1. Input Module

- Accept credit reports via:
  - PDF upload (multipart form data).
  - JSON ingestion (already-normalized credit data).
- Parse relevant fields:
  - Creditor name (raw + canonical)
  - Account type
  - Account status
  - Comments / notations (forbearance, hardship, transferred, etc.)
  - Balance, credit limit, past due
  - DOFD (Date of First Delinquency)
  - Open/close dates, last payment date
- Use OCR when PDF is image-based (future enhancement).
- Normalize all parsed data into the `CreditAccount` model defined in `src/types.ts`.

### 2. Normalization & Data Mapping

- Use canonical enums for:
  - `accountType`, `status`, `bureau`, etc. (see `src/types.ts`).
- Implement robust string/regex mappings to convert:
  - "Charge-off", "CO", "Charged off" → `CHARGEOFF`
  - "Repossession", "Vehicle taken back" → `CHARGEOFF` or special auto flags
  - "Transferred", "Sold", "Purchased by another lender" → `TRANSFERRED` / `SOLD`
  - Hardship comments (forbearance, COVID, trial, loss mitigation) → hardship flags
- Maintain mapping utilities in a dedicated module (future extension) that converts raw IdentityIQ text into the standardized types & fields.

### 3. Issue Detection Engine

- Use the violation engine in `src/rules/*.ts` and `src/engine/analyze.ts` to:

  - Flag:
    - Inconsistent balances across bureaus.
    - Conflicting statuses (e.g., TRANSFERRED/SOLD but still showing current past-due).
    - Possible double-reporting (OC + collection both showing non-zero balances).
    - Charge-offs with ongoing past-due amounts.
    - Hardship-related misreporting (forbearance/hardship but severe lates/foreclosure).
    - Foreclosure and auto deficiency challenges (mortgage and repo logic).
    - Debt-buyer validation triggers for FDCPA (LVNV, Jefferson, Portfolio Recovery, etc.).

- Ensure each `DetectedIssue` includes:
  - `issueType`, `severity` (HIGH/MEDIUM/LOW)
  - `legalBasis` (FCRA, FDCPA, Metro 2)
  - `description` that can be reused in an explanatory UI panel.

### 4. Strategy Engine

- For each account:
  - Evaluate severity and legal basis.
  - Determine dispute priority and **round strategy**:
    - **Round 1:** First challenge / generic accuracy dispute.
    - **Round 2:** Refined challenge referencing prior results / lack of adequate response.
    - **Round 3:** Final notice demanding deletion or full documentation, with escalation hints.
- Ensure the engine can:
  - Target both CRA disputes and collector validation letters.
  - Reuse the same underlying `DetectedIssue` objects for:
    - Bureau letters.
    - FDCPA validation letters.

### 5. Dispute Letter Generator

- Use templated paragraphs in:
  - `src/templates/craTemplates.ts` for EQ/EX/TU.
  - `src/templates/collectorTemplates.ts` for LVNV and Jefferson (and extendable to others).
- Merge:
  - Global consumer info (`ConsumerProfile`).
  - Bureau-specific issues and accounts (grouped per bureau).
- Provide:
  - 3 rounds of CRA dispute letters for each bureau.
  - FDCPA collector letters with validation demands.
- Output:
  - `DisputeLetter` objects with `bodyText` (plain text), ready for export as:
    - PDF (`src/utils/pdfExporter.ts`)
    - DOCX (`src/utils/docxExporter.ts`)

### 6. Explanatory Panel (Frontend / API)

- For each disputed account, expose an API that returns:
  - What’s wrong (plain-language summary from `DetectedIssue.description` and account fields).
  - Why it may be inaccurate (ties to FCRA/FDCPA principles).
  - What the app is requesting:
    - Correct balances / statuses.
    - Deletion of unverifiable tradelines.
    - Validation documents from collectors.
- Do **not** expose internal reasoning chain or hidden model prompts to end users—only curated explanations and issue descriptions.

---

## Additional Features & Flows

- Template versions for all three CRA dispute rounds (already scaffolded).
- FDCPA collector letters for debt buyers (LVNV / Jefferson; extendable to others).
- Active fraud alert detection:
  - If the incoming data indicates fraud alerts or identity theft notations, branch logic to:
    - Generate identity theft dispute letters.
    - Reference FTC identity theft reports or police reports (future extension).
- Identity theft flow:
  - Specialized letter templates and documentation requests (to be added as new templates).
- Download-ready outputs:
  - PDF and DOCX letters via `/api/letters/:letterId.pdf?jobId=...` and `/api/letters/:letterId.docx?jobId=...`.
  - Future: multi-letter ZIP download per round or per bureau.

---

## Current Backend Implementation (What Exists)

- Core types & enums in `src/types.ts`.
- Rules in:
  - `src/rules/rules_balances.ts`
  - `src/rules/rules_status.ts`
- Engine entrypoint:
  - `src/engine/analyze.ts` (`analyzeReport(accounts)`).
- CRA & collector templates:
  - `src/templates/craTemplates.ts`
  - `src/templates/collectorTemplates.ts`
- Export utilities:
  - `src/utils/pdfExporter.ts`
  - `src/utils/docxExporter.ts`
- Dispute Engine service + queue:
  - `src/services/DisputeEngineService.ts`
- High-level pipeline:
  - `src/pipeline/creditReportPipeline.ts`
- REST endpoints (Express):
  - `src/routes/disputes.ts`
    - `POST /api/reports/upload`
    - `GET /api/reports/:jobId/status`
    - `GET /api/letters/:letterId.pdf?jobId=...`
    - `GET /api/letters/:letterId.docx?jobId=...`
- Python analogue:
  - `python/violation_engine.py` (for optional microservice or experimentation).

---

## Expectations for Replit Agent

- Keep everything in **TypeScript** for the Node backend (`src/**/*.ts`).
- Maintain compatibility with Node.js 20 on Replit.
- When extending the engine:
  - Add new `IssueType` and rules in `src/rules/*.ts`.
  - Update templates in `src/templates/*.ts` as needed.
  - Do **not** expose implementation prompts or chain-of-thought to end users.
- When integrating UI:
  - Call existing REST routes from a frontend (e.g., React/Vite) hosted within Replit.
  - Build a minimalistic UI for:
    - Uploading reports.
    - Viewing normalized accounts and detected issues.
    - Selecting and downloading letters.

This document is the **source-of-truth brief** for how the Replit Agent should extend and maintain the Credit Dispute AI Engine.
