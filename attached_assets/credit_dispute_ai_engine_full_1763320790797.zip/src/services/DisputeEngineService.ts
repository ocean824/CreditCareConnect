import {
  Bureau,
  ConsumerProfile,
  CreditAccount,
  DetectedIssue,
  DisputeLetter,
} from "../types";
import { analyzeReport } from "../engine/analyze";
import { issueToCraSnippet, buildCraLetter } from "../templates/craTemplates";
import {
  buildJeffersonValidationLetter,
  buildLvnvValidationLetter,
} from "../templates/collectorTemplates";
import { letterToPdf } from "../utils/pdfExporter";
import { letterToDocx } from "../utils/docxExporter";

/**
 * Queue abstraction so you can plug in BullMQ, Bee-Queue, or in-memory.
 */
export interface ProcessingJob {
  id: string;
  status: "PENDING" | "RUNNING" | "COMPLETED" | "FAILED";
  error?: string;
  result?: {
    accounts: CreditAccount[];
    issues: DetectedIssue[];
    letters: DisputeLetter[];
  };
}

export interface ProcessingQueue {
  enqueue(payload: UploadedReportJob): Promise<ProcessingJob>;
  getJob(id: string): Promise<ProcessingJob | undefined>;
}

/**
 * Payload for an uploaded report job.
 */
export interface UploadedReportJob {
  id: string;
  rawReportPath: string;
  consumer: ConsumerProfile;
  round: 1 | 2 | 3;
}

/**
 * DisputeEngineService interface for your backend.
 */
export interface IDisputeEngineService {
  analyzeAccounts(accounts: CreditAccount[]): Promise<DetectedIssue[]>;

  generateCraLetters(
    consumer: ConsumerProfile,
    accounts: CreditAccount[],
    round: 1 | 2 | 3,
  ): Promise<DisputeLetter[]>;

  generateCollectorLetters(
    consumer: ConsumerProfile,
    accounts: CreditAccount[],
  ): Promise<DisputeLetter[]>;

  exportLetterAsPdf(letter: DisputeLetter): Promise<Uint8Array>;
  exportLetterAsDocx(letter: DisputeLetter): Promise<Uint8Array>;

  enqueueReportJob(job: UploadedReportJob): Promise<ProcessingJob>;
  getJob(id: string): Promise<ProcessingJob | undefined>;
}

/**
 * PDF parser function type.
 */
export type PdfToAccountsFn = (path: string) => Promise<CreditAccount[]>;

export class DefaultDisputeEngineService implements IDisputeEngineService {
  constructor(
    private readonly queue: ProcessingQueue | null,
    private readonly pdfToAccounts: PdfToAccountsFn,
  ) {}

  async analyzeAccounts(accounts: CreditAccount[]): Promise<DetectedIssue[]> {
    return analyzeReport(accounts);
  }

  async generateCraLetters(
    consumer: ConsumerProfile,
    accounts: CreditAccount[],
    round: 1 | 2 | 3,
  ): Promise<DisputeLetter[]> {
    const issues = analyzeReport(accounts);
    const letters: DisputeLetter[] = [];

    const bureaus: Bureau[] = ["TU", "EX", "EQ"];
    for (const bureau of bureaus) {
      const bureauAccounts = accounts.filter((a) => a.bureau === bureau);
      if (!bureauAccounts.length) continue;

      const bureauIssues = issues.filter((i) => i.bureau === bureau);
      if (!bureauIssues.length) continue;

      const snippets = bureauIssues.map((issue) => {
        const acct = bureauAccounts.find((a) => a.id === issue.accountId);
        if (!acct) {
          throw new Error(`Missing account for issue ${issue.id}`);
        }
        return issueToCraSnippet(issue, acct);
      });

      const letter = buildCraLetter(bureau, round, consumer, snippets);
      letters.push(letter);
    }

    return letters;
  }

  async generateCollectorLetters(
    consumer: ConsumerProfile,
    accounts: CreditAccount[],
  ): Promise<DisputeLetter[]> {
    const letters: DisputeLetter[] = [];

    for (const acct of accounts) {
      const name = (acct.creditorCanonical || acct.creditorNameRaw || "").toUpperCase();
      if (name.includes("LVNV")) {
        letters.push(buildLvnvValidationLetter(consumer, acct));
      } else if (name.includes("JEFFERSON")) {
        letters.push(buildJeffersonValidationLetter(consumer, acct));
      }
    }

    return letters;
  }

  async exportLetterAsPdf(letter: DisputeLetter): Promise<Uint8Array> {
    return letterToPdf(letter);
  }

  async exportLetterAsDocx(letter: DisputeLetter): Promise<Uint8Array> {
    return letterToDocx(letter);
  }

  async enqueueReportJob(job: UploadedReportJob): Promise<ProcessingJob> {
    if (!this.queue) {
      throw new Error("No ProcessingQueue configured for this engine.");
    }
    return this.queue.enqueue(job);
  }

  async getJob(id: string): Promise<ProcessingJob | undefined> {
    if (!this.queue) return undefined;
    return this.queue.getJob(id);
  }
}

/**
 * Simple in-memory queue & worker sketch. Replace with Redis/BullMQ in production.
 */
export class InMemoryProcessingQueue implements ProcessingQueue {
  private jobs = new Map<string, ProcessingJob>();
  private processing = false;
  private engine: DefaultDisputeEngineService;

  constructor(private readonly pdfToAccounts: PdfToAccountsFn) {
    // Engine is created with this queue, so it can delegate enqueue/getJob back here if needed.
    this.engine = new DefaultDisputeEngineService(this, pdfToAccounts);
  }

  getEngine(): DefaultDisputeEngineService {
    return this.engine;
  }

  async enqueue(payload: UploadedReportJob): Promise<ProcessingJob> {
    const job: ProcessingJob = {
      id: payload.id,
      status: "PENDING",
    };
    this.jobs.set(job.id, job);
    this.kickWorker(payload);
    return job;
  }

  async getJob(id: string): Promise<ProcessingJob | undefined> {
    return this.jobs.get(id);
  }

  private async kickWorker(payload: UploadedReportJob): Promise<void> {
    if (this.processing) return;
    this.processing = true;

    const job = this.jobs.get(payload.id);
    if (!job) {
      this.processing = false;
      return;
    }

    try {
      job.status = "RUNNING";

      const accounts = await this.pdfToAccounts(payload.rawReportPath);
      const issues = await this.engine.analyzeAccounts(accounts);
      const craLetters = await this.engine.generateCraLetters(
        payload.consumer,
        accounts,
        payload.round,
      );
      const collectorLetters = await this.engine.generateCollectorLetters(
        payload.consumer,
        accounts,
      );
      const letters = [...craLetters, ...collectorLetters];

      job.status = "COMPLETED";
      job.result = { accounts, issues, letters };
    } catch (err: any) {
      job.status = "FAILED";
      job.error = err?.message || String(err);
    } finally {
      this.processing = false;
    }
  }
}
