import { CreditAccount, DetectedIssue, LegalBasis, newId } from "../types";

/**
 * Status / hardship / foreclosure / debt-buyer rules.
 */

export function runStatusRules(acct: CreditAccount): DetectedIssue[] {
  const issues: DetectedIssue[] = [];

  // Rule: transferred/sold but still mis-coded as late with a past-due amount
  if (
    (acct.status === "TRANSFERRED" || acct.status === "SOLD") &&
    (acct.pastDue ?? 0) > 0
  ) {
    issues.push({
      id: newId(),
      accountId: acct.id,
      bureau: acct.bureau,
      issueType: "TRANSFERRED_MIS_STATUS",
      severity: "MEDIUM",
      legalBasis: withLegal("FCRA_MAXIMUM_POSSIBLE_ACCURACY", "METRO2_CODING"),
      description:
        "Account is reported as transferred/sold but still shows a current past-due status, which may misrepresent the account.",
      fieldsInQuestion: ["status", "pastDue"],
      data: {
        status: acct.status,
        pastDue: acct.pastDue ?? 0,
      },
    });
  }

  // Rule: hardship / forbearance keywords with heavy lates/foreclosure
  const hardshipKeywords = [
    "forbearance",
    "partial payment",
    "trial",
    "loss mitigation",
    "covid",
    "cares",
    "hardship",
  ];
  const lowerComments = (acct.commentsRaw || "").toLowerCase();
  const hasHardshipWords = hardshipKeywords.some((k) => lowerComments.includes(k));

  if (
    hasHardshipWords &&
    (acct.status === "FORECLOSURE" ||
      acct.status === "OPEN_LATE_90" ||
      acct.status === "OPEN_LATE_120")
  ) {
    issues.push({
      id: newId(),
      accountId: acct.id,
      bureau: acct.bureau,
      issueType: "HARDSHIP_MISREPORTING",
      severity: "HIGH",
      legalBasis: withLegal(
        "FCRA_MAXIMUM_POSSIBLE_ACCURACY",
        "FCRA_REINVESTIGATION",
        "METRO2_CODING",
      ),
      description:
        "Account shows severe delinquency or foreclosure while comments suggest forbearance or hardship assistance.",
      fieldsInQuestion: ["status", "commentsRaw"],
      data: {
        status: acct.status,
        comments: acct.commentsRaw ?? "",
      },
    });
  }

  // Rule: foreclosure status challenge for mortgages, especially with forbearance history
  if (acct.isMortgage && acct.status === "FORECLOSURE") {
    issues.push({
      id: newId(),
      accountId: acct.id,
      bureau: acct.bureau,
      issueType: "FORECLOSURE_STATUS_CHALLENGE",
      severity: "HIGH",
      legalBasis: withLegal(
        "FCRA_MAXIMUM_POSSIBLE_ACCURACY",
        "FCRA_REINVESTIGATION",
        "METRO2_CODING",
      ),
      description:
        "Mortgage is reported as in foreclosure; consumer may challenge the delinquency timeline and status in light of forbearance or loss-mitigation programs.",
      fieldsInQuestion: ["status", "dateOfFirstDelinquency", "commentsRaw"],
      data: {
        dateOfFirstDelinquency: acct.dateOfFirstDelinquency ?? null,
      },
    });
  }

  // Rule: repo status challenge for auto loans
  if (acct.isAuto && (acct.status === "CHARGEOFF" || acct.status === "COLLECTION")) {
    issues.push({
      id: newId(),
      accountId: acct.id,
      bureau: acct.bureau,
      issueType: "REPO_STATUS_CHALLENGE",
      severity: "HIGH",
      legalBasis: withLegal(
        "FCRA_MAXIMUM_POSSIBLE_ACCURACY",
        "FCRA_REINVESTIGATION",
        "METRO2_CODING",
      ),
      description:
        "Auto account is charged-off/collection; consumer may challenge deficiency balance, sale proceeds, and timeline after repossession.",
      fieldsInQuestion: ["balance", "status", "pastDue"],
      data: {
        balance: acct.balance,
        pastDue: acct.pastDue ?? 0,
      },
    });
  }

  // Rule: debt buyer validation trigger
  if (acct.isDebtBuyer && acct.accountType === "COLLECTION") {
    issues.push({
      id: newId(),
      accountId: acct.id,
      bureau: acct.bureau,
      issueType: "DEBT_BUYER_NEEDS_VALIDATION",
      severity: "HIGH",
      legalBasis: withLegal("FDCPA_VALIDATION", "FCRA_MAXIMUM_POSSIBLE_ACCURACY"),
      description:
        "Debt buyer collection account requires validation and chain-of-title documentation under FDCPA and FCRA accuracy standards.",
      fieldsInQuestion: ["creditorNameRaw", "balance", "commentsRaw"],
      data: {
        creditor: acct.creditorNameRaw,
        balance: acct.balance,
      },
    });
  }

  return issues;
}

function withLegal(...basis: LegalBasis[]): LegalBasis[] {
  return basis;
}
