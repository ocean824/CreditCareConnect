import { AccountGroup, CreditAccount, DetectedIssue, LegalBasis, newId } from "../types";

/**
 * Balance / past-due–oriented rules.
 *
 * These rules focus on:
 * - charge-off with ongoing past-due amounts
 * - cross-bureau inconsistent balances
 * - possible double-reporting (OC + CA both reporting non-zero for same debt)
 */

export function runBalanceRulesPerAccount(acct: CreditAccount): DetectedIssue[] {
  const issues: DetectedIssue[] = [];

  // Rule: charge-off but still shows large past due
  if (acct.status === "CHARGEOFF" && acct.balance >= 0 && (acct.pastDue ?? 0) > 0) {
    issues.push({
      id: newId(),
      accountId: acct.id,
      bureau: acct.bureau,
      issueType: "INCONSISTENT_PAST_DUE_AFTER_CHARGEOFF",
      severity: "MEDIUM",
      legalBasis: withLegal("FCRA_MAXIMUM_POSSIBLE_ACCURACY", "METRO2_CODING"),
      description:
        "Account is reported as charged-off but still shows an active past-due amount, which may misrepresent the status.",
      fieldsInQuestion: ["status", "pastDue"],
      data: {
        balance: acct.balance,
        pastDue: acct.pastDue ?? 0,
      },
    });
  }

  return issues;
}

export function runBalanceRulesCrossBureau(groups: AccountGroup[]): DetectedIssue[] {
  const issues: DetectedIssue[] = [];

  for (const group of groups) {
    const balances = group.accounts.map((a) => a.balance);
    const uniqueBalances = new Set(balances.map((b) => Number.isFinite(b) ? b : NaN));

    // Rule: different balances for same logical account
    if (uniqueBalances.size > 1) {
      for (const acct of group.accounts) {
        issues.push({
          id: newId(),
          accountId: acct.id,
          bureau: acct.bureau,
          issueType: "INCONSISTENT_BALANCE",
          severity: "HIGH",
          legalBasis: withLegal("FCRA_MAXIMUM_POSSIBLE_ACCURACY"),
          description:
            "Balance for this account differs from other bureaus for the same alleged debt.",
          fieldsInQuestion: ["balance"],
          data: {
            allBureauBalances: group.accounts.map((a) => ({
              bureau: a.bureau,
              balance: a.balance,
            })),
          },
        });
      }
    }

    // Rule: possible double-reporting (OC + CA both showing non-zero)
    const hasOriginalWithBalance = group.accounts.some(
      (a) => a.isOriginalCreditor && a.balance > 0,
    );
    const hasCollectorWithBalance = group.accounts.some(
      (a) => a.isDebtBuyer && a.balance > 0,
    );
    if (hasOriginalWithBalance && hasCollectorWithBalance) {
      for (const acct of group.accounts) {
        issues.push({
          id: newId(),
          accountId: acct.id,
          bureau: acct.bureau,
          issueType: "POSSIBLE_DOUBLE_REPORTING",
          severity: "HIGH",
          legalBasis: withLegal("FCRA_MAXIMUM_POSSIBLE_ACCURACY", "METRO2_CODING"),
          description:
            "Both an original creditor and a collection/debt buyer appear to be reporting non-zero balances for the same debt.",
          fieldsInQuestion: ["balance", "status"],
          data: {
            creditors: group.accounts.map((a) => ({
              creditor: a.creditorNameRaw,
              isDebtBuyer: !!a.isDebtBuyer,
              balance: a.balance,
            })),
          },
        });
      }
    }
  }

  return issues;
}

function withLegal(...basis: LegalBasis[]): LegalBasis[] {
  return basis;
}
