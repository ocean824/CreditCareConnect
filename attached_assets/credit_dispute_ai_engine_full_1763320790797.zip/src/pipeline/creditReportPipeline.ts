import fs from "fs/promises";
import path from "path";
import {
  ConsumerProfile,
  CreditAccount,
  DisputeLetter,
} from "../types";
import {
  DefaultDisputeEngineService,
  InMemoryProcessingQueue,
  PdfToAccountsFn,
} from "../services/DisputeEngineService";

/**
 * Dummy PDF -> accounts parser. Replace with a real parser for IdentityIQ.
 */
const dummyPdfToAccounts: PdfToAccountsFn = async (pdfPath: string) => {
  console.warn("[dummyPdfToAccounts] using sample JSON only. Replace with real parser.");
  const samplePath = path.join(__dirname, "..", "..", "data", "sample_accounts_with_violations.json");
  const content = await fs.readFile(samplePath, "utf8");
  const payload = JSON.parse(content) as {
    accounts: CreditAccount[];
  };
  return payload.accounts;
};

/**
 * High-level API to process a single uploaded PDF synchronously.
 */
export async function processUploadedPdfReport(
  pdfPath: string,
  consumer: ConsumerProfile,
  round: 1 | 2 | 3,
): Promise<{
  accounts: CreditAccount[];
  letters: DisputeLetter[];
}> {
  const queue = new InMemoryProcessingQueue(dummyPdfToAccounts);
  const engine: DefaultDisputeEngineService = queue.getEngine();

  const accounts = await dummyPdfToAccounts(pdfPath);
  const craLetters = await engine.generateCraLetters(consumer, accounts, round);
  const collectorLetters = await engine.generateCollectorLetters(consumer, accounts);

  return {
    accounts,
    letters: [...craLetters, ...collectorLetters],
  };
}

/**
 * Express-style wiring sketch is in src/routes/disputes.ts.
 */
