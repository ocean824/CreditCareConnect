import {
  AccountGroup,
  CreditAccount,
  DetectedIssue,
} from "../types";
import { runBalanceRulesPerAccount, runBalanceRulesCrossBureau } from "../rules/rules_balances";
import { runStatusRules } from "../rules/rules_status";

/**
 * Group accounts by a "logical key" so that cross-bureau rules can compare
 * balances and statuses for what is effectively the same debt.
 */
export function groupAccounts(accounts: CreditAccount[]): AccountGroup[] {
  const map = new Map<string, CreditAccount[]>();

  for (const acct of accounts) {
    const normalizedName = (acct.creditorCanonical || acct.creditorNameRaw || "")
      .toUpperCase()
      .replace(/\s+/g, "");
    const tail = acct.acctNumberMasked.replace(/[^0-9]/g, "").slice(-4);
    const key = `${normalizedName}_${tail || "UNK"}`;
    const list = map.get(key) ?? [];
    list.push(acct);
    map.set(key, list);
  }

  const groups: AccountGroup[] = [];
  for (const [logicalKey, groupAccounts] of map.entries()) {
    groups.push({
      logicalKey,
      accounts: groupAccounts,
    });
  }
  return groups;
}

/**
 * Main entrypoint for the violation engine.
 */
export function analyzeReport(accounts: CreditAccount[]): DetectedIssue[] {
  const issues: DetectedIssue[] = [];

  // Per-account rules
  for (const acct of accounts) {
    issues.push(...runBalanceRulesPerAccount(acct));
    issues.push(...runStatusRules(acct));
  }

  // Cross-bureau rules
  const groups = groupAccounts(accounts);
  issues.push(...runBalanceRulesCrossBureau(groups));

  return issues;
}
