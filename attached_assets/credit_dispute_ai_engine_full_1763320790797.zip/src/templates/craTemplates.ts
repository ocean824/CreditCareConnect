import {
  Bureau,
  ConsumerProfile,
  CreditAccount,
  DetectedIssue,
  DisputeLetter,
  DisputeSnippet,
  newId,
} from "../types";

/**
 * Map an issue + account into a single paragraph/snippet inside a CRA dispute letter.
 */
export function issueToCraSnippet(issue: DetectedIssue, acct: CreditAccount): DisputeSnippet {
  const base = {
    accountId: acct.id,
    bureau: acct.bureau,
    creditorName: acct.creditorCanonical || acct.creditorNameRaw,
    acctNumberMasked: acct.acctNumberMasked,
    issueIds: [issue.id],
  };

  switch (issue.issueType) {
    case "INCONSISTENT_PAST_DUE_AFTER_CHARGEOFF":
      return {
        ...base,
        text: `The tradeline for ${base.creditorName} (Acct #${base.acctNumberMasked}) is reported as a charge-off but still shows an active past-due amount of ${acct.pastDue}. This may misrepresent the true status of the account. Please verify the correct Metro 2 coding for a charged-off account and either correct the past-due and status fields or delete the tradeline if it cannot be verified.`,
      };

    case "INCONSISTENT_BALANCE":
      return {
        ...base,
        text: `The balance for ${base.creditorName} (Acct #${base.acctNumberMasked}) is reported differently on various credit reports for the same alleged debt. Under the FCRA's accuracy requirements, please obtain documentation from the furnisher, correct any inconsistent balances across all bureaus, or delete the tradeline if it cannot be fully substantiated.`,
      };

    case "TRANSFERRED_MIS_STATUS":
      return {
        ...base,
        text: `The account for ${base.creditorName} (Acct #${base.acctNumberMasked}) is reported as transferred or sold but still shows a current past-due status. Once an account is transferred with a zero balance, it should not continue to be reported as currently delinquent. Please verify the proper status and past-due fields and correct or delete the tradeline as needed.`,
      };

    case "HARDSHIP_MISREPORTING":
      return {
        ...base,
        text: `The ${base.creditorName} tradeline (Acct #${base.acctNumberMasked}) shows severe delinquency or foreclosure while the comments indicate forbearance or hardship assistance. Please confirm whether the reported delinquency accurately reflects periods when no payment was due or when payments were under modified terms, and correct or remove the derogatory notations if they cannot be substantiated.`,
      };

    case "POSSIBLE_DOUBLE_REPORTING":
      return {
        ...base,
        text: `For ${base.creditorName} (Acct #${base.acctNumberMasked}), both an original creditor and a collection or debt buyer appear to be reporting non-zero balances for the same underlying account. This may result in double-reporting of a single debt, contrary to the FCRA's requirement for maximum possible accuracy. Please verify the correct reporting structure and delete any duplicate or inaccurate tradeline(s).`,
      };

    case "DEBT_BUYER_NEEDS_VALIDATION":
      return {
        ...base,
        text: `The collection account for ${base.creditorName} (Acct #${base.acctNumberMasked}) appears to be a debt-buyer tradeline. I dispute the accuracy and completeness of this reporting and request that you obtain full documentation from the furnisher, including the original contract, chain of title, payment history, and date of first delinquency, and update or delete the tradeline accordingly.`,
      };

    case "FORECLOSURE_STATUS_CHALLENGE":
      return {
        ...base,
        text: `The mortgage tradeline for ${base.creditorName} (Acct #${base.acctNumberMasked}) is reported as being in foreclosure. I dispute the foreclosure status and delinquency timeline in light of forbearance, hardship, or loss-mitigation options that were in place. Please obtain full servicing and payment records from the furnisher and correct or delete any foreclosure or severe-delinquency coding that cannot be fully verified.`,
      };

    case "REPO_STATUS_CHALLENGE":
      return {
        ...base,
        text: `The auto account for ${base.creditorName} (Acct #${base.acctNumberMasked}) is reported as a charged-off or collection account following repossession. I dispute the deficiency balance, the application of any sale proceeds or insurance, and the delinquency coding. Please obtain detailed documentation from the furnisher and correct the balance, past-due amount, and status or delete the tradeline if it cannot be fully substantiated.`,
      };

    default:
      return {
        ...base,
        text: `The reporting for ${base.creditorName} (Acct #${base.acctNumberMasked}) appears inaccurate or incomplete. I request a full reinvestigation and correction or deletion of any unverifiable information under the FCRA and Metro 2 reporting standards.`,
      };
  }
}

/**
 * Build the CRA dispute letter body from snippets (Round 1, 2, or 3).
 */
export function buildCraLetter(
  bureau: Bureau,
  round: 1 | 2 | 3,
  consumer: ConsumerProfile,
  snippets: DisputeSnippet[],
): DisputeLetter {
  const recipientInfo = getBureauAddress(bureau);

  const intro = buildIntroParagraph(round);
  const bodyLines = snippets.map((s) => `- ${s.text}`).join("\n\n");
  const outro = buildOutroParagraph(round);

  const bodyText = [
    headerBlock(consumer),
    "",
    `${recipientInfo.name}`,
    recipientInfo.address,
    "",
    intro,
    "",
    "Items in dispute:",
    "",
    bodyLines,
    "",
    outro,
    "",
    "Sincerely,",
    "",
    consumer.fullName,
  ].join("\n");

  return {
    id: newId(),
    recipientType: "CRA",
    round,
    recipientName: recipientInfo.name,
    recipientAddress: recipientInfo.address,
    bodyText,
    snippets,
    meta: { bureau, createdAt: new Date().toISOString() },
  };
}

function headerBlock(consumer: ConsumerProfile): string {
  const addr2 = consumer.addressLine2 ? `\n${consumer.addressLine2}` : "";
  const contact: string[] = [];
  if (consumer.phone) contact.push(`Phone: ${consumer.phone}`);
  if (consumer.email) contact.push(`Email: ${consumer.email}`);
  if (consumer.ssnLast4) contact.push(`SSN (last 4): ${consumer.ssnLast4}`);
  if (consumer.dob) contact.push(`DOB: ${consumer.dob}`);

  return [
    consumer.fullName,
    consumer.addressLine1,
    addr2,
    `${consumer.city}, ${consumer.state} ${consumer.postalCode}`,
    contact.join(" | "),
    "",
    new Date().toLocaleDateString(),
  ]
    .filter(Boolean)
    .join("\n");
}

function buildIntroParagraph(round: 1 | 2 | 3): string {
  const roundText =
    round === 1
      ? "request for reinvestigation"
      : round === 2
      ? "second request for reinvestigation"
      : "final notice regarding your failure to conduct a reasonable reinvestigation";

  return `I am writing to you in connection with my credit file and to submit a ${roundText} of multiple tradelines that appear inaccurate or incomplete, as permitted under the Fair Credit Reporting Act (FCRA). I request that you conduct a reasonable reinvestigation, obtain documentation from each furnisher, and correct or delete any information that cannot be fully verified.`;
}

function buildOutroParagraph(round: 1 | 2 | 3): string {
  if (round === 1) {
    return "At the conclusion of your reinvestigation, please provide me with written results, a free updated copy of my credit report, and a description of the method of verification used for each item, including the contact information of any furnishers you relied upon.";
  }
  if (round === 2) {
    return "Because this is a follow-up dispute, please describe in detail the steps you took during your reinvestigation and provide the documents or information you relied upon. If any furnisher cannot fully substantiate the disputed information, please delete the tradeline.";
  }
  return "Because this is my third dispute on these items without adequate correction or explanation, I request deletion of the disputed tradelines. If you refuse to delete them, please provide a detailed description of your reinvestigation and all documents relied upon, as I am considering formal complaints to regulators and exploring my legal options.";
}

function getBureauAddress(bureau: Bureau): { name: string; address: string } {
  switch (bureau) {
    case "TU":
      return {
        name: "TransUnion LLC",
        address: "P.O. Box 2000\nChester, PA 19016-2000",
      };
    case "EX":
      return {
        name: "Experian",
        address: "P.O. Box 4500\nAllen, TX 75013",
      };
    case "EQ":
    default:
      return {
        name: "Equifax Information Services LLC",
        address: "P.O. Box 740256\nAtlanta, GA 30374-0256",
      };
  }
}
