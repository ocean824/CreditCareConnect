import {
  ConsumerProfile,
  CreditAccount,
  DisputeLetter,
  DisputeSnippet,
  newId,
} from "../types";

/**
 * Build FDCPA validation demand letters for LVNV Funding and Jefferson Capital.
 */

export function buildLvnvValidationLetter(
  consumer: ConsumerProfile,
  acct: CreditAccount,
): DisputeLetter {
  const snippet: DisputeSnippet = {
    accountId: acct.id,
    bureau: acct.bureau,
    creditorName: acct.creditorCanonical || acct.creditorNameRaw,
    acctNumberMasked: acct.acctNumberMasked,
    issueIds: [],
    text: "",
  };

  const bodyText = [
    headerBlock(consumer),
    "",
    "LVNV Funding LLC",
    "[Insert LVNV Address Line 1]",
    "[City, State ZIP]",
    "",
    `Re: Debt Validation Request under FDCPA – Account No. ${acct.acctNumberMasked} / Alleged Balance: ${acct.balance.toFixed(
      2,
    )}`,
    "",
    "To Whom It May Concern:",
    "",
    "I am writing in response to your reporting and/or collection activity regarding the alleged debt referenced above, which appears on my credit report as a collection account in the approximate amount indicated. This letter serves as a formal request for validation of the debt pursuant to the Fair Debt Collection Practices Act (FDCPA), 15 U.S.C. § 1692g, and notice that I dispute this alleged debt in its entirety.",
    "",
    "Until you provide full validation as described below, you must cease all collection activity regarding this account, including reporting or updating this debt with any credit reporting agencies in a manner that is false, misleading, or incomplete, and ensure that my credit file reflects this account as disputed by consumer where you choose to report it.",
    "",
    "Please provide the following:",
    "",
    "1. Proof of the debt and amount:",
    "   - A copy of the original signed contract or application establishing the account in my name.",
    "   - A complete itemized accounting showing how you calculated the alleged balance (principal, interest, fees, and any other charges).",
    "",
    "2. Chain of title / ownership:",
    "   - Documentation showing that LVNV Funding LLC is the current owner of the debt, including all assignments/bills of sale from the original creditor through each intermediary, if any.",
    "   - Documents showing that you have the legal right to collect this debt in my state.",
    "",
    "3. Statute of limitations & date of first delinquency:",
    "   - The date of first delinquency (DOFD) that led to the charge-off.",
    "   - The date of last payment on the original account.",
    "   - Confirmation that this account is not time-barred under my state’s applicable statute of limitations.",
    "",
    "4. Details of any judgments or legal actions:",
    "   - If any judgment exists, provide a copy of the judgment, case number, and court.",
    "   - If no judgment exists, please confirm that you have not obtained any judgment regarding this account.",
    "",
    "5. Credit reporting accuracy:",
    "   - The specific information you are furnishing to each credit reporting agency regarding this account.",
    "   - Confirmation that you will update all credit bureaus to clearly reflect this account as disputed by consumer while it is under investigation.",
    "",
    "If you cannot provide complete and adequate validation of the alleged debt, or if you are unable to demonstrate a clear chain of title and legal right to collect, I demand that you cease all collection efforts, instruct all credit reporting agencies to delete the LVNV collection tradeline, and confirm in writing that you have done so.",
    "",
    "Any continued collection activity on an unvalidated or improperly validated debt, or any false/misleading representations in connection with the collection of a debt, may constitute violations of the FDCPA and other applicable laws. I am keeping detailed records of all correspondence for potential complaints to the Consumer Financial Protection Bureau (CFPB), the Federal Trade Commission (FTC), my state Attorney General, and for use in any legal action if necessary.",
    "",
    "You may respond in writing to the address above.",
    "",
    "Sincerely,",
    "",
    consumer.fullName,
  ].join("\n");

  return {
    id: newId(),
    recipientType: "DEBT_COLLECTOR",
    round: 1,
    recipientName: "LVNV Funding LLC",
    recipientAddress: "[Insert LVNV Address Line 1]\n[City, State ZIP]",
    bodyText,
    snippets: [snippet],
    meta: {
      collector: "LVNV",
      createdAt: new Date().toISOString(),
    },
  };
}

export function buildJeffersonValidationLetter(
  consumer: ConsumerProfile,
  acct: CreditAccount,
): DisputeLetter {
  const snippet: DisputeSnippet = {
    accountId: acct.id,
    bureau: acct.bureau,
    creditorName: acct.creditorCanonical || acct.creditorNameRaw,
    acctNumberMasked: acct.acctNumberMasked,
    issueIds: [],
    text: "",
  };

  const bodyText = [
    headerBlock(consumer),
    "",
    "Jefferson Capital Systems, LLC",
    "[Insert Jefferson Address Line 1]",
    "[City, State ZIP]",
    "",
    `Re: Debt Validation and Status Request under FDCPA – Account No. ${acct.acctNumberMasked} (Original Creditor reference)`,
    "",
    "To Whom It May Concern:",
    "",
    "I recently reviewed my credit report and saw references indicating that a prior account has been charged off and sold or purchased by another lender, and it appears that Jefferson Capital Systems, LLC may now claim to own or collect this alleged debt.",
    "",
    "This letter serves as a formal request for validation of the alleged debt under the Fair Debt Collection Practices Act (FDCPA), 15 U.S.C. § 1692g, and as notice that I dispute this alleged obligation in its entirety.",
    "",
    "Please provide the following:",
    "",
    "1. Proof of the alleged debt and balance:",
    "   - A copy of the original signed agreement or application establishing the account in my name.",
    "   - A full account history / itemized statement from account opening through charge-off, including all payments, interest, fees, and any post-charge-off additions.",
    "",
    "2. Chain of title / assignment:",
    "   - Documentation showing that Jefferson Capital Systems, LLC is the current owner or authorized agent for this debt, including all assignments or purchase agreements from the original creditor or any intermediary debt buyers.",
    "   - Evidence that you have the legal right to collect in my state.",
    "",
    "3. Current status & statute of limitations:",
    "   - The date of first delinquency (DOFD) that led to the charge-off.",
    "   - The date of last payment on this account.",
    "   - Confirmation whether the alleged debt is within or beyond the statute of limitations in my state.",
    "",
    "4. Credit reporting and balances:",
    "   - The specific tradeline(s) you currently furnish to any credit reporting agencies regarding this account (if any).",
    "   - Confirmation that you are not reporting (and will not report) misleading balances or statuses, especially if the original creditor already reports a charge-off with a $0 balance due to sale or transfer.",
    "",
    "Unless and until you provide full, adequate validation as requested above, please cease all collection activity, including phone calls, letters, and credit reporting, and ensure that any existing credit reporting related to this account clearly reflects disputed by consumer.",
    "",
    "If you are not in fact collecting on this obligation or if you determine that you cannot validate it, please confirm in writing that you have no claim against me regarding this account, refrain from any future collection activity on this alleged debt, and notify any credit reporting agencies to delete or correct any related tradeline as appropriate.",
    "",
    "Any attempt to continue collection efforts on an unvalidated debt, or any false/misleading credit reporting, may violate the FDCPA and other applicable consumer protection statutes. I am documenting all communications for potential complaints and legal remedies.",
    "",
    "You may respond in writing to the address above.",
    "",
    "Sincerely,",
    "",
    consumer.fullName,
  ].join("\n");

  return {
    id: newId(),
    recipientType: "DEBT_COLLECTOR",
    round: 1,
    recipientName: "Jefferson Capital Systems, LLC",
    recipientAddress: "[Insert Jefferson Address Line 1]\n[City, State ZIP]",
    bodyText,
    snippets: [snippet],
    meta: {
      collector: "JEFFERSON",
      createdAt: new Date().toISOString(),
    },
  };
}

function headerBlock(consumer: ConsumerProfile): string {
  const addr2 = consumer.addressLine2 ? `\n${consumer.addressLine2}` : "";
  const contact: string[] = [];
  if (consumer.phone) contact.push(`Phone: ${consumer.phone}`);
  if (consumer.email) contact.push(`Email: ${consumer.email}`);
  if (consumer.ssnLast4) contact.push(`SSN (last 4): ${consumer.ssnLast4}`);
  if (consumer.dob) contact.push(`DOB: ${consumer.dob}`);

  return [
    consumer.fullName,
    consumer.addressLine1,
    addr2,
    `${consumer.city}, ${consumer.state} ${consumer.postalCode}`,
    contact.join(" | "),
    "",
    new Date().toLocaleDateString(),
  ]
    .filter(Boolean)
    .join("\n");
}
