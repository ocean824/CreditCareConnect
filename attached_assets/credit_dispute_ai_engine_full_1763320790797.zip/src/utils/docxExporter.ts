import { Document, Packer, Paragraph, TextRun } from "docx";
import { DisputeLetter } from "../types";

/**
 * Convert a DisputeLetter into a DOCX buffer using the `docx` library.
 */
export async function letterToDocx(letter: DisputeLetter): Promise<Uint8Array> {
  const paragraphs: Paragraph[] = [];
  const lines = letter.bodyText.split(/\r?\n/);

  for (const line of lines) {
    paragraphs.push(
      new Paragraph({
        children: [new TextRun(line)],
      }),
    );
  }

  const doc = new Document({
    sections: [
      {
        properties: {},
        children: paragraphs,
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  return new Uint8Array(buffer);
}
