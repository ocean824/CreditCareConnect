import { PDFDocument, StandardFonts } from "pdf-lib";
import { DisputeLetter } from "../types";

/**
 * Convert a DisputeLetter into a PDF buffer using pdf-lib.
 */
export async function letterToPdf(letter: DisputeLetter): Promise<Uint8Array> {
  const doc = await PDFDocument.create();
  let page = doc.addPage();
  let { width, height } = page.getSize();

  const font = await doc.embedFont(StandardFonts.TimesRoman);
  const fontSize = 11;
  const margin = 50;
  const maxWidth = width - margin * 2;

  const lines = wrapText(letter.bodyText, 90);
  let y = height - margin;

  for (const line of lines) {
    if (y < margin) {
      page = doc.addPage();
      ({ width, height } = page.getSize());
      y = height - margin;
    }
    page.drawText(line, {
      x: margin,
      y,
      size: fontSize,
      font,
    });
    y -= fontSize + 2;
  }

  const pdfBytes = await doc.save();
  return pdfBytes;
}

function wrapText(text: string, maxChars: number): string[] {
  const lines: string[] = [];
  const rawLines = text.split(/\r?\n/);
  for (const raw of rawLines) {
    if (raw.length <= maxChars) {
      lines.push(raw);
      continue;
    }
    let current = raw;
    while (current.length > maxChars) {
      let breakIndex = current.lastIndexOf(" ", maxChars);
      if (breakIndex <= 0) breakIndex = maxChars;
      lines.push(current.slice(0, breakIndex));
      current = current.slice(breakIndex).trimStart();
    }
    if (current.length) lines.push(current);
  }
  return lines;
}
