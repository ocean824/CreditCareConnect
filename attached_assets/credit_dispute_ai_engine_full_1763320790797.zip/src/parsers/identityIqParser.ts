import fs from "fs/promises";
import pdfParse from "pdf-parse";
import {
  Bureau,
  CreditAccount,
  AccountType,
  AccountStatus,
} from "../types";

/**
 * High-level entry: PDF path → CreditAccount[]
 */
export async function parseIdentityIqPdf(pdfPath: string): Promise<CreditAccount[]> {
  const buffer = await fs.readFile(pdfPath);
  const parsed = await (pdfParse as any)(buffer);
  const rawText: string = parsed.text || "";
  return parseIdentityIqText(rawText);
}

/**
 * Core parser: text → CreditAccount[]
 *
 * This assumes a text-based IdentityIQ report (not a scanned image).
 */
export function parseIdentityIqText(rawText: string): CreditAccount[] {
  const text = normalizeWhitespace(rawText);

  const sections = splitByBureauSections(text);
  const accounts: CreditAccount[] = [];

  for (const section of sections) {
    const blocks = splitIntoAccountBlocks(section.text);

    for (const block of blocks) {
      const acct = parseAccountBlock(section.bureau, block);
      if (acct) {
        accounts.push(acct);
      }
    }
  }

  return accounts;
}

function normalizeWhitespace(text: string): string {
  return text
    .replace(/\r\n/g, "\n")
    .replace(/\t/g, "  ")
    .replace(/[ \u00A0]+/g, " ")
    .replace(/\n{3,}/g, "\n\n");
}

function splitByBureauSections(text: string): { bureau: Bureau; text: string }[] {
  const markers: { bureau: Bureau; index: number }[] = [];

  const tuMatch = /TransUnion/i.exec(text);
  if (tuMatch) markers.push({ bureau: "TU", index: tuMatch.index });

  const exMatch = /Experian/i.exec(text);
  if (exMatch) markers.push({ bureau: "EX", index: exMatch.index });

  const eqMatch = /Equifax/i.exec(text);
  if (eqMatch) markers.push({ bureau: "EQ", index: eqMatch.index });

  if (!markers.length) {
    return [
      {
        bureau: "EX",
        text,
      },
    ];
  }

  markers.sort((a, b) => a.index - b.index);

  const sections: { bureau: Bureau; text: string }[] = [];
  for (let i = 0; i < markers.length; i++) {
    const current = markers[i];
    const next = markers[i + 1];
    const start = current.index;
    const end = next ? next.index : text.length;
    const sectionText = text.slice(start, end);
    sections.push({ bureau: current.bureau, text: sectionText });
  }

  return sections;
}

function splitIntoAccountBlocks(sectionText: string): string[] {
  const blocks: string[] = [];
  const pattern = /(?:^|\n)Account Name:\s*/gi;

  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = pattern.exec(sectionText)) !== null) {
    const start = match.index;

    if (start > lastIndex) {
      const prevBlock = sectionText.slice(lastIndex, start).trim();
      if (prevBlock && lastIndex !== 0) {
        blocks.push(prevBlock);
      }
    }

    lastIndex = start;
  }

  if (lastIndex < sectionText.length) {
    const lastBlock = sectionText.slice(lastIndex).trim();
    if (lastBlock) blocks.push(lastBlock);
  }

  return blocks.filter((b) => /Account Number:/i.test(b));
}

function parseAccountBlock(bureau: Bureau, block: string): CreditAccount | null {
  const headerMatch = /Account Name:\s*(.+)/i.exec(block);
  const creditorNameRaw = headerMatch ? headerMatch[1].split("\n")[0].trim() : undefined;
  if (!creditorNameRaw) return null;

  const acctNumberMasked =
    matchFirst(block, /Account Number:\s*([^\n]+)/i) ||
    "UNKNOWN";

  const rawAccountType = matchFirst(block, /Account Type:\s*([^\n]+)/i) || "";
  const rawPayStatus = matchFirst(block, /(Pay Status|Status):\s*([^\n]+)/i, 2) || "";
  const rawComments = matchFirst(block, /Comments?:\s*([^\n]+)/i) || "";

  const dateOpened = matchFirstDate(block, /Date Opened:\s*([0-9/]+)/i);
  const dateReported = matchFirstDate(block, /(Date Reported|Date Updated):\s*([0-9/]+)/i, 2);
  const dateLastPayment = matchFirstDate(block, /(Date Last Payment|Last Payment):\s*([0-9/]+)/i, 2);

  const dofd =
    matchFirstDate(block, /(Date of First Delinquency|DOFD):\s*([0-9/]+)/i, 2) ||
    matchFirstDate(
      block,
      /Estimated month and year that you first became delinquent on the account:\s*([0-9/]+)/i,
      1,
    );

  const balance = parseMoney(
    matchFirst(block, /Balance:\s*\$?([0-9,.-]+)/i) ||
      matchFirst(block, /Current Balance:\s*\$?([0-9,.-]+)/i),
  );

  const creditLimit = parseMoney(
    matchFirst(block, /(Credit Limit|High Credit):\s*\$?([0-9,.-]+)/i, 2),
  );

  const pastDue = parseMoney(
    matchFirst(block, /Past Due:\s*\$?([0-9,.-]+)/i),
  );

  const priorDisputeNoted = /dispute/i.test(rawComments) || /consumer disputes/i.test(block);

  const accountType = normalizeAccountType(rawAccountType, creditorNameRaw);
  const status = normalizeStatus(rawPayStatus, block);
  const creditorCanonical = canonicalizeCreditorName(creditorNameRaw);

  const { isDebtBuyer, isOriginalCreditor } = inferDebtBuyerFlags(
    creditorCanonical,
    accountType,
  );
  const { isMortgage, isAuto } = inferProductFlags(accountType, creditorCanonical, rawAccountType);

  const acct: CreditAccount = {
    id: `idq_${bureau}_${hashString(creditorNameRaw + acctNumberMasked)}`,
    bureau,
    creditorNameRaw,
    creditorCanonical,
    acctNumberMasked,
    accountType,
    status,
    balance,
    creditLimit,
    pastDue,
    dateOpened,
    dateLastReported: dateReported,
    dateLastPayment,
    dateOfFirstDelinquency: dofd,
    commentsRaw: rawComments,
    paymentHistoryRaw: extractPaymentHistory(block),
    priorDisputeNoted,
    isDebtBuyer,
    isOriginalCreditor,
    isMortgage,
    isAuto,
    meta: {},
  };

  return acct;
}

function matchFirst(
  text: string,
  regex: RegExp,
  groupIndex: number = 1,
): string | undefined {
  const m = regex.exec(text);
  return m && m[groupIndex] ? m[groupIndex].trim() : undefined;
}

function matchFirstDate(
  text: string,
  regex: RegExp,
  groupIndex: number = 1,
): string | undefined {
  const raw = matchFirst(text, regex, groupIndex);
  if (!raw) return undefined;
  const parts = raw.split("/");
  if (parts.length === 3) {
    const [mm, dd, yyyy] = parts;
    return `${yyyy.padStart(4, "0")}-${mm.padStart(2, "0")}-${dd.padStart(2, "0")}`;
  }
  if (parts.length === 2) {
    const [mm, yyyy] = parts;
    return `${yyyy.padStart(4, "0")}-${mm.padStart(2, "0")}-01`;
  }
  return undefined;
}

function parseMoney(raw: string | undefined | null): number {
  if (!raw) return 0;
  const cleaned = raw.replace(/[^0-9.-]/g, "");
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : 0;
}

function hashString(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash * 31 + str.charCodeAt(i)) | 0;
  }
  return Math.abs(hash).toString(36);
}

function extractPaymentHistory(block: string): string {
  const m = /Payment History:(.*?)(?:\n\n|$)/is.exec(block);
  if (!m) return "";
  return m[1].trim();
}

function normalizeAccountType(rawType: string, creditorName: string): AccountType {
  const t = rawType.toLowerCase();

  if (/mortgage|real estate|home loan/.test(t)) return "MORTGAGE";
  if (/auto|vehicle|car loan|automo/.test(t)) return "AUTO";
  if (/charge account|charge card/.test(t)) return "CHARGE_ACCOUNT";
  if (/revolving|credit card|line of credit/.test(t)) return "REVOLVING";
  if (/personal loan|installment|signature loan/.test(t)) return "INSTALLMENT";
  if (/collection/.test(t)) return "COLLECTION";

  if (/lvnv|portfolio recovery|midland|jefferson|cavalry/i.test(creditorName)) {
    return "COLLECTION";
  }

  return "OTHER";
}

function normalizeStatus(rawStatus: string, block: string): AccountStatus {
  const s = rawStatus.toLowerCase();

  if (/pays as agreed|current|ok/.test(s)) return "OPEN_CURRENT";
  if (/30 days past due|30 days late/.test(s)) return "OPEN_LATE_30";
  if (/60 days past due|60 days late/.test(s)) return "OPEN_LATE_60";
  if (/90 days past due|90 days late/.test(s)) return "OPEN_LATE_90";
  if (/120 days past due|120 days late/.test(s)) return "OPEN_LATE_120";

  if (/charge[- ]?off|charged off/.test(s)) return "CHARGEOFF";
  if (/collection/.test(s)) return "COLLECTION";
  if (/foreclosure/.test(s)) return "FORECLOSURE";
  if (/transferred/.test(s)) return "TRANSFERRED";
  if (/sold/.test(s)) return "SOLD";

  if (/closed/.test(s) && /derog|late|charge|collection/.test(block.toLowerCase())) {
    return "CLOSED_DEROG";
  }
  if (/closed/.test(s)) {
    return "CLOSED_CURRENT";
  }

  return "OPEN_CURRENT";
}

function canonicalizeCreditorName(raw: string): string {
  const upper = raw.toUpperCase();

  if (/CROSSCOUNTRY/.test(upper) || /CROSSCMTG/.test(upper)) return "CROSSCOUNTRY";
  if (/GM FINANCIAL/.test(upper)) return "GM FINANCIAL";
  if (/MIDFLORIDA/.test(upper)) return "MIDFLORIDA";
  if (/NAVY FEDERAL/.test(upper)) return "NAVY FCU";
  if (/WEBBANK/.test(upper) && /NEW WAVE/.test(upper)) return "WEBBANK_NEW_WAVE";
  if (/ACHIEVE/.test(upper) && /PERSONAL/.test(upper)) return "ACHIEVEPL";
  if (/LVNV/.test(upper)) return "LVNV";
  if (/JEFFERSON/.test(upper)) return "JEFFERSON CAPITAL";
  if (/PORTFOLIO RECOVERY/.test(upper)) return "PORTFOLIO RECOVERY";
  if (/AUSTINCAPBK|AUSTIN CAPITAL/.test(upper)) return "AUSTIN CAPITAL BANK";

  return upper.replace(/\s+/g, " ").trim();
}

function inferDebtBuyerFlags(
  creditorCanonical: string,
  accountType: AccountType,
): { isDebtBuyer: boolean; isOriginalCreditor: boolean } {
  const upper = creditorCanonical.toUpperCase();
  const isDebtBuyer =
    /LVNV|PORTFOLIO RECOVERY|MIDLAND|JEFFERSON|CAVALRY|ENHANCED RECOVERY/.test(upper) ||
    accountType === "COLLECTION";

  return {
    isDebtBuyer,
    isOriginalCreditor: !isDebtBuyer,
  };
}

function inferProductFlags(
  accountType: AccountType,
  creditorCanonical: string,
  rawAccountType: string,
): { isMortgage: boolean; isAuto: boolean } {
  const upperName = creditorCanonical.toUpperCase();
  const lowerType = rawAccountType.toLowerCase();

  const isMortgage =
    accountType === "MORTGAGE" ||
    /MORTGAGE|HOME LOAN|REAL ESTATE/.test(upperName) ||
    /mortgage|home/.test(lowerType);

  const isAuto =
    accountType === "AUTO" ||
    /GM FINANCIAL|ALLY|FORD|HONDA FINANCE|TOYOTA FINANCIAL/.test(upperName) ||
    /auto|vehicle|car loan/.test(lowerType);

  return { isMortgage, isAuto };
}
