import { v4 as uuid } from "uuid";

export type Bureau = "TU" | "EX" | "EQ";

export type AccountType =
  | "MORTGAGE"
  | "AUTO"
  | "INSTALLMENT"
  | "REVOLVING"
  | "CHARGE_ACCOUNT"
  | "COLLECTION"
  | "OTHER";

export type AccountStatus =
  | "OPEN_CURRENT"
  | "OPEN_LATE_30"
  | "OPEN_LATE_60"
  | "OPEN_LATE_90"
  | "OPEN_LATE_120"
  | "CHARGEOFF"
  | "COLLECTION"
  | "FORECLOSURE"
  | "TRANSFERRED"
  | "SOLD"
  | "CLOSED_CURRENT"
  | "CLOSED_DEROG";

export type IssueType =
  | "INCONSISTENT_BALANCE"
  | "INCONSISTENT_PAST_DUE_AFTER_CHARGEOFF"
  | "TRANSFERRED_MIS_STATUS"
  | "HARDSHIP_MISREPORTING"
  | "DOFD_MISMATCH"
  | "DEBT_BUYER_NEEDS_VALIDATION"
  | "POSSIBLE_DOUBLE_REPORTING"
  | "FORECLOSURE_STATUS_CHALLENGE"
  | "REPO_STATUS_CHALLENGE"
  | "GENERIC_ACCURACY_CHALLENGE";

export type LegalBasis =
  | "FCRA_MAXIMUM_POSSIBLE_ACCURACY"
  | "FCRA_REINVESTIGATION"
  | "FCRA_FURNISHER_DUTIES"
  | "FDCPA_VALIDATION"
  | "METRO2_CODING";

export type Severity = "LOW" | "MEDIUM" | "HIGH";

export interface CreditAccount {
  id: string;
  bureau: Bureau;
  creditorNameRaw: string;
  creditorCanonical?: string;
  acctNumberMasked: string;
  accountType: AccountType;
  status: AccountStatus;
  balance: number;
  creditLimit?: number | null;
  pastDue?: number | null;
  dateOpened?: string | null; // ISO date
  dateLastReported?: string | null;
  dateLastPayment?: string | null;
  dateOfFirstDelinquency?: string | null;
  commentsRaw?: string;
  paymentHistoryRaw?: string;
  priorDisputeNoted?: boolean;
  isDebtBuyer?: boolean;
  isOriginalCreditor?: boolean;
  isMortgage?: boolean;
  isAuto?: boolean;
  meta?: Record<string, unknown>;
}

export interface DetectedIssue {
  id: string;
  accountId: string;
  bureau: Bureau;
  issueType: IssueType;
  severity: Severity;
  legalBasis: LegalBasis[];
  description: string;
  fieldsInQuestion: string[];
  data?: Record<string, unknown>;
}

export interface DisputeSnippet {
  accountId: string;
  bureau: Bureau;
  creditorName: string;
  acctNumberMasked: string;
  text: string;
  issueIds: string[];
}

export interface DisputeLetter {
  id: string;
  recipientType: "CRA" | "DEBT_COLLECTOR" | "CREDITOR";
  round: 1 | 2 | 3;
  recipientName: string;
  recipientAddress: string;
  bodyText: string;
  snippets: DisputeSnippet[];
  meta?: Record<string, unknown>;
}

export interface ConsumerProfile {
  fullName: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  postalCode: string;
  phone?: string;
  email?: string;
  dob?: string; // ISO date
  ssnLast4?: string;
}

export interface AccountGroup {
  logicalKey: string;
  accounts: CreditAccount[];
}

/**
 * Convenience helper for generating IDs where needed.
 */
export function newId(): string {
  return uuid();
}
