import express from "express";
import cors from "cors";
import { disputesRouter } from "./routes/disputes";

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api", disputesRouter);

const port = Number(process.env.PORT || 5000);

app.listen(port, () => {
  console.log(`Credit Dispute AI Engine listening on port ${port}`);
});
