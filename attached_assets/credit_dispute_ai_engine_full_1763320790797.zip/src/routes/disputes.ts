import path from "path";
import fs from "fs/promises";
import { Router, Request, Response, NextFunction } from "express";
import multer from "multer";
import { randomUUID } from "crypto";

import {
  ConsumerProfile,
  CreditAccount,
} from "../types";
import {
  DefaultDisputeEngineService,
  InMemoryProcessingQueue,
  PdfToAccountsFn,
  UploadedReportJob,
  ProcessingJob,
} from "../services/DisputeEngineService";
import { letterToPdf } from "../utils/pdfExporter";
import { parseIdentityIqPdf } from "../parsers/identityIqParser";
import { letterToDocx } from "../utils/docxExporter";

// ---------- File upload setup ----------
const upload = multer({
  dest: "/tmp", // Replit's temp dir; adjust if needed
});

// ---------- IdentityIQ PDF -> accounts parser ----------
const pdfToAccounts: PdfToAccountsFn = async (pdfPath: string) => {
  return parseIdentityIqPdf(pdfPath);
};

// ---------- Engine + Queue singletons ----------
const queue = new InMemoryProcessingQueue(pdfToAccounts);
const engine: DefaultDisputeEngineService = queue.getEngine();

// ---------- Router ----------
export const disputesRouter = Router();

/**
 * POST /api/reports/upload
 *
 * - Accepts multipart/form-data:
 *   - file field: "report" (PDF)
 *   - text fields:
 *     - consumer: JSON string of ConsumerProfile
 *     - round: "1" | "2" | "3" (optional, defaults to 1)
 *
 * Returns: { jobId: string, status: string }
 */
disputesRouter.post(
  "/reports/upload",
  upload.single("report"),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      if (!req.file?.path) {
        return res.status(400).json({ error: "Missing report file" });
      }

      if (!req.body.consumer) {
        return res.status(400).json({ error: "Missing consumer JSON" });
      }

      const consumer: ConsumerProfile = JSON.parse(req.body.consumer);
      const roundRaw = Number(req.body.round || "1");
      const round = (roundRaw === 2 || roundRaw === 3 ? roundRaw : 1) as 1 | 2 | 3;

      const job: UploadedReportJob = {
        id: randomUUID(),
        rawReportPath: req.file.path,
        consumer,
        round,
      };

      const enqueued = await engine.enqueueReportJob(job);

      return res.status(202).json({
        jobId: enqueued.id,
        status: enqueued.status,
      });
    } catch (err) {
      return next(err);
    }
  },
);

/**
 * GET /api/reports/:jobId/status
 *
 * Returns the current job status and high-level result info.
 */
disputesRouter.get(
  "/reports/:jobId/status",
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const jobId = req.params.jobId;
      const job: ProcessingJob | undefined = await engine.getJob(jobId);

      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      return res.json({
        id: job.id,
        status: job.status,
        error: job.error,
        resultSummary: job.result
          ? {
              accountsCount: job.result.accounts.length,
              issuesCount: job.result.issues.length,
              lettersCount: job.result.letters.length,
              letterIds: job.result.letters.map((l) => l.id),
            }
          : null,
      });
    } catch (err) {
      return next(err);
    }
  },
);

/**
 * GET /api/letters/:letterId.pdf?jobId=...
 *
 * Streams a single letter as PDF.
 */
disputesRouter.get(
  "/letters/:letterId.pdf",
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const letterId = req.params.letterId;
      const jobId = req.query.jobId as string | undefined;

      if (!jobId) {
        return res.status(400).json({ error: "Missing jobId query param" });
      }

      const job = await engine.getJob(jobId);
      if (!job || job.status !== "COMPLETED" || !job.result) {
        return res.status(404).json({ error: "Completed job not found for this jobId" });
      }

      const letter = job.result.letters.find((l) => l.id === letterId);
      if (!letter) {
        return res.status(404).json({ error: "Letter not found for job" });
      }

      const pdfBytes = await letterToPdf(letter);
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader(
        "Content-Disposition",
        `attachment; filename=dispute-${letter.id}.pdf`,
      );
      return res.send(Buffer.from(pdfBytes));
    } catch (err) {
      return next(err);
    }
  },
);

/**
 * GET /api/letters/:letterId.docx?jobId=...
 *
 * Streams a single letter as DOCX.
 */
disputesRouter.get(
  "/letters/:letterId.docx",
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const letterId = req.params.letterId;
      const jobId = req.query.jobId as string | undefined;

      if (!jobId) {
        return res.status(400).json({ error: "Missing jobId query param" });
      }

      const job = await engine.getJob(jobId);
      if (!job || job.status !== "COMPLETED" || !job.result) {
        return res.status(404).json({ error: "Completed job not found for this jobId" });
      }

      const letter = job.result.letters.find((l) => l.id === letterId);
      if (!letter) {
        return res.status(404).json({ error: "Letter not found for job" });
      }

      const docxBytes = await letterToDocx(letter);
      res.setHeader(
        "Content-Type",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      );
      res.setHeader(
        "Content-Disposition",
        `attachment; filename=dispute-${letter.id}.docx`,
      );
      return res.send(Buffer.from(docxBytes));
    } catch (err) {
      return next(err);
    }
  },
);
