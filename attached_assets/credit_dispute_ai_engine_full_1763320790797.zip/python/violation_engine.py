from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Any, Optional


class Bureau(str, Enum):
    TU = "TU"
    EX = "EX"
    EQ = "EQ"


class AccountType(str, Enum):
    MORTGAGE = "MORTGAGE"
    AUTO = "AUTO"
    INSTALLMENT = "INSTALLMENT"
    REVOLVING = "REVOLVING"
    CHARGE_ACCOUNT = "CHARGE_ACCOUNT"
    COLLECTION = "COLLECTION"
    OTHER = "OTHER"


class AccountStatus(str, Enum):
    OPEN_CURRENT = "OPEN_CURRENT"
    OPEN_LATE_30 = "OPEN_LATE_30"
    OPEN_LATE_60 = "OPEN_LATE_60"
    OPEN_LATE_90 = "OPEN_LATE_90"
    OPEN_LATE_120 = "OPEN_LATE_120"
    CHARGEOFF = "CHARGEOFF"
    COLLECTION = "COLLECTION"
    FORECLOSURE = "FORECLOSURE"
    TRANSFERRED = "TRANSFERRED"
    SOLD = "SOLD"
    CLOSED_CURRENT = "CLOSED_CURRENT"
    CLOSED_DEROG = "CLOSED_DEROG"


class IssueType(str, Enum):
    INCONSISTENT_BALANCE = "INCONSISTENT_BALANCE"
    INCONSISTENT_PAST_DUE_AFTER_CHARGEOFF = "INCONSISTENT_PAST_DUE_AFTER_CHARGEOFF"
    TRANSFERRED_MIS_STATUS = "TRANSFERRED_MIS_STATUS"
    HARDSHIP_MISREPORTING = "HARDSHIP_MISREPORTING"
    DOFD_MISMATCH = "DOFD_MISMATCH"
    DEBT_BUYER_NEEDS_VALIDATION = "DEBT_BUYER_NEEDS_VALIDATION"
    POSSIBLE_DOUBLE_REPORTING = "POSSIBLE_DOUBLE_REPORTING"
    FORECLOSURE_STATUS_CHALLENGE = "FORECLOSURE_STATUS_CHALLENGE"
    REPO_STATUS_CHALLENGE = "REPO_STATUS_CHALLENGE"
    GENERIC_ACCURACY_CHALLENGE = "GENERIC_ACCURACY_CHALLENGE"


class LegalBasis(str, Enum):
    FCRA_MAXIMUM_POSSIBLE_ACCURACY = "FCRA_MAXIMUM_POSSIBLE_ACCURACY"
    FCRA_REINVESTIGATION = "FCRA_REINVESTIGATION"
    FCRA_FURNISHER_DUTIES = "FCRA_FURNISHER_DUTIES"
    FDCPA_VALIDATION = "FDCPA_VALIDATION"
    METRO2_CODING = "METRO2_CODING"


class Severity(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


@dataclass
class CreditAccount:
    id: str
    bureau: Bureau
    creditorNameRaw: str
    acctNumberMasked: str
    accountType: AccountType
    status: AccountStatus
    balance: float
    creditorCanonical: Optional[str] = None
    creditLimit: Optional[float] = None
    pastDue: Optional[float] = None
    dateOpened: Optional[str] = None
    dateLastReported: Optional[str] = None
    dateLastPayment: Optional[str] = None
    dateOfFirstDelinquency: Optional[str] = None
    commentsRaw: Optional[str] = None
    paymentHistoryRaw: Optional[str] = None
    priorDisputeNoted: bool = False
    isDebtBuyer: bool = False
    isOriginalCreditor: bool = False
    isMortgage: bool = False
    isAuto: bool = False
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DetectedIssue:
    id: str
    accountId: str
    bureau: Bureau
    issueType: IssueType
    severity: Severity
    legalBasis: List[LegalBasis]
    description: str
    fieldsInQuestion: List[str]
    data: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ConsumerProfile:
    fullName: str
    addressLine1: str
    city: str
    state: str
    postalCode: str
    addressLine2: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    dob: Optional[str] = None
    ssnLast4: Optional[str] = None


@dataclass
class AccountGroup:
    logicalKey: str
    accounts: List[CreditAccount]


class ViolationEngine:
    def group_accounts(self, accounts: List[CreditAccount]) -> List[AccountGroup]:
        groups: Dict[str, List[CreditAccount]] = {}
        for acct in accounts:
            name = (acct.creditorCanonical or acct.creditorNameRaw or "").upper().replace(" ", "")
            tail = "".join(ch for ch in acct.acctNumberMasked if ch.isdigit())[-4:] or "UNK"
            key = f"{name}_{tail}"
            groups.setdefault(key, []).append(acct)
        return [AccountGroup(logicalKey=k, accounts=v) for k, v in groups.items()]

    def run_per_account_rules(self, acct: CreditAccount) -> List[DetectedIssue]:
        issues: List[DetectedIssue] = []

        if acct.status == AccountStatus.CHARGEOFF and acct.pastDue and acct.pastDue > 0:
            issues.append(
                DetectedIssue(
                    id=f"iss_{acct.id}_co_pd",
                    accountId=acct.id,
                    bureau=acct.bureau,
                    issueType=IssueType.INCONSISTENT_PAST_DUE_AFTER_CHARGEOFF,
                    severity=Severity.MEDIUM,
                    legalBasis=[
                        LegalBasis.FCRA_MAXIMUM_POSSIBLE_ACCURACY,
                        LegalBasis.METRO2_CODING,
                    ],
                    description=(
                        "Account is reported as charged-off but still shows an active past-due amount, "
                        "which may misrepresent the status."
                    ),
                    fieldsInQuestion=["status", "pastDue"],
                    data={"balance": acct.balance, "pastDue": acct.pastDue},
                )
            )

        if acct.isDebtBuyer and acct.accountType == AccountType.COLLECTION:
            issues.append(
                DetectedIssue(
                    id=f"iss_{acct.id}_debtbuyer",
                    accountId=acct.id,
                    bureau=acct.bureau,
                    issueType=IssueType.DEBT_BUYER_NEEDS_VALIDATION,
                    severity=Severity.HIGH,
                    legalBasis=[
                        LegalBasis.FDCPA_VALIDATION,
                        LegalBasis.FCRA_MAXIMUM_POSSIBLE_ACCURACY,
                    ],
                    description=(
                        "Debt buyer collection account requires validation and chain-of-title documentation "
                        "under FDCPA and FCRA accuracy standards."
                    ),
                    fieldsInQuestion=["creditorNameRaw", "balance", "commentsRaw"],
                    data={"creditor": acct.creditorNameRaw, "balance": acct.balance},
                )
            )

        return issues

    def run_cross_bureau_rules(self, groups: List[AccountGroup]) -> List[DetectedIssue]:
        issues: List[DetectedIssue] = []
        for group in groups:
            balances = [a.balance for a in group.accounts]
            if len(set(balances)) > 1:
                for acct in group.accounts:
                    issues.append(
                        DetectedIssue(
                            id=f"iss_{acct.id}_incons_bal",
                            accountId=acct.id,
                            bureau=acct.bureau,
                            issueType=IssueType.INCONSISTENT_BALANCE,
                            severity=Severity.HIGH,
                            legalBasis=[LegalBasis.FCRA_MAXIMUM_POSSIBLE_ACCURACY],
                            description=(
                                "Balance for this account differs from other bureaus for the same alleged debt."
                            ),
                            fieldsInQuestion=["balance"],
                            data={
                                "allBureauBalances": [
                                    {"bureau": a.bureau, "balance": a.balance}
                                    for a in group.accounts
                                ]
                            },
                        )
                    )
        return issues

    def analyze_report(self, accounts: List[CreditAccount]) -> List[DetectedIssue]:
        issues: List[DetectedIssue] = []
        for acct in accounts:
            issues.extend(self.run_per_account_rules(acct))
        groups = self.group_accounts(accounts)
        issues.extend(self.run_cross_bureau_rules(groups))
        return issues
