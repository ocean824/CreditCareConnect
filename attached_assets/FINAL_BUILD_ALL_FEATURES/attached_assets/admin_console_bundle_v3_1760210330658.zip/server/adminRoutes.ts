
import { Router } from "express";
import { db } from "./db";
import { users, mailBatches, deliveryEvents, clientResponses } from "@shared/schema";
import { adminOnly } from "./adminOnly";
import { isAuthenticated } from "./replitAuth";
import { eq, desc } from "drizzle-orm";

export const adminRouter = Router();

adminRouter.use(isAuthenticated, adminOnly);

adminRouter.get("/users", async (req, res) => {
  const rows = await db.select().from(users).orderBy(desc(users.createdAt));
  res.json(rows);
});

adminRouter.put("/users/:id/role", async (req, res) => {
  const id = String(req.params.id);
  const { role } = req.body || {};
  if (!["user", "admin"].includes(role)) return res.status(400).json({ message: "role must be 'user' or 'admin'" });
  await db.update(users).set({ role }).where(eq(users.id, id));
  res.json({ ok: true });
});

adminRouter.get("/cases", async (req, res) => {
  const rows = await db.select().from(mailBatches).orderBy(desc(mailBatches.createdAt));
  const byCase = new Map<string, any>();
  for (const r of rows) {
    const key = r.caseId;
    const cur = byCase.get(key);
    if (!cur || new Date(r.createdAt).getTime() > new Date(cur.createdAt).getTime()) {
      byCase.set(key, r);
    }
  }
  const latest = Array.from(byCase.values());
  const out = [];
  for (const r of latest) {
    const u = (await db.select().from(users).where(eq(users.id, r.clientId))).at(0);
    out.push({ ...r, clientName: u?.name, clientEmail: u?.email });
  }
  res.json(out);
});

adminRouter.get("/letters", async (req, res) => {
  const batches = await db.select().from(mailBatches).orderBy(desc(mailBatches.createdAt));
  const eventsFor = new Map<string, any>();
  for (const b of batches) {
    const ev = await db.select().from(deliveryEvents).where(eq(deliveryEvents.batchId, b.id)).orderBy(desc(deliveryEvents.createdAt));
    eventsFor.set(b.id, ev[0] || null);
  }
  const out = batches.map(b => ({
    ...b,
    lastEvent: eventsFor.get(b.id)
  }));
  res.json(out);
});

adminRouter.get("/responses", async (req, res) => {
  const rows = await db.select().from(clientResponses).orderBy(desc(clientResponses.createdAt));
  res.json(rows);
});
