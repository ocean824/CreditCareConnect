
import React, { useEffect, useState } from 'react';
import AdminNav from '../../components/AdminNav';

export default function AdminCases() {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch('/api/admin/cases');
        if (!r.ok) throw new Error(await r.text());
        setRows(await r.json());
      } catch (e:any) { setError(e.message); } finally { setLoading(false); }
    })();
  }, []);

  return (
    <div style={{padding:16}}>
      <h2>Admin · Cases</h2>
      <AdminNav />
      {loading && <p>Loading…</p>}
      {error && <p style={{color:'red'}}>{error}</p>}
      {!loading && !error && (
        <table cellPadding={8} style={{width:'100%', borderCollapse:'collapse'}}>
          <thead><tr><th>Case ID</th><th>Client</th><th>Bureau</th><th>Round</th><th>Status</th><th>Created</th></tr></thead>
          <tbody>
            {rows.map((r:any) => (
              <tr key={r.caseId}>
                <td>{r.caseId}</td>
                <td>{r.clientName} <small>({r.clientEmail})</small></td>
                <td>{r.bureau}</td>
                <td>{r.round}</td>
                <td>{r.status}</td>
                <td>{r.createdAt ? new Date(r.createdAt).toLocaleString() : ''}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
