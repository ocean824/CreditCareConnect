
import React, { useEffect, useState } from 'react';
import AdminNav from '../../components/AdminNav';

export default function AdminLetters() {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try {
      const r = await fetch('/api/admin/letters');
      if (!r.ok) throw new Error(await r.text());
      setRows(await r.json());
      setError(null);
    } catch (e:any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, []);

  return (
    <div style={{padding:16}}>
      <h2>Admin · Letters</h2>
      <AdminNav />
      {loading && <p>Loading…</p>}
      {error && <p style={{color:'red'}}>{error}</p>}
      {!loading && !error && (
        <table cellPadding={8} style={{width:'100%', borderCollapse:'collapse'}}>
          <thead><tr><th>Batch</th><th>Case</th><th>Client</th><th>Bureau</th><th>Round</th><th>Status</th><th>Tracking</th><th>Proof/3811</th><th>Last Event</th></tr></thead>
          <tbody>
            {rows.map((b:any) => (
              <tr key={b.id}>
                <td>{b.id}</td>
                <td>{b.caseId}</td>
                <td>{b.clientId}</td>
                <td>{b.bureau}</td>
                <td>{b.round}</td>
                <td>{b.status}</td>
                <td>{b.uspsTracking || ''}</td>
                <td>{b.proofUrl ? <a href={b.proofUrl} target="_blank">View</a> : ''}</td>
                <td>{b.lastEvent ? `${b.lastEvent.kind} @ ${new Date(b.lastEvent.createdAt).toLocaleString()}` : ''}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
