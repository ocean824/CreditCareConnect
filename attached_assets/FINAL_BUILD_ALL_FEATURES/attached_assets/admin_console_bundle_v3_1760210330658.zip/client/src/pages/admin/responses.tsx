
import React, { useEffect, useState } from 'react';
import AdminNav from '../../components/AdminNav';

export default function AdminResponses() {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch('/api/admin/responses');
        if (!r.ok) throw new Error(await r.text());
        setRows(await r.json());
      } catch (e:any) { setError(e.message); } finally { setLoading(false); }
    })();
  }, []);

  return (
    <div style={{padding:16}}>
      <h2>Admin · Client Responses</h2>
      <AdminNav />
      {loading && <p>Loading…</p>}
      {error && <p style={{color:'red'}}>{error}</p>}
      {!loading && !error && (
        <table cellPadding={8} style={{width:'100%', borderCollapse:'collapse'}}>
          <thead><tr><th>ID</th><th>Client</th><th>Case</th><th>Round</th><th>File</th><th>Uploaded</th></tr></thead>
          <tbody>
            {rows.map((r:any) => (
              <tr key={r.id}>
                <td>{r.id}</td>
                <td>{r.clientId}</td>
                <td>{r.caseId}</td>
                <td>{r.round}</td>
                <td>{r.fileUrl ? <a href={r.fileUrl} target="_blank">Open</a> : ''}</td>
                <td>{r.createdAt ? new Date(r.createdAt).toLocaleString() : ''}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
