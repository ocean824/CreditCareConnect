
import React, { useEffect, useState } from 'react';
import AdminNav from '../../components/AdminNav';

export default function AdminUsers() {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try {
      const r = await fetch('/api/admin/users');
      if (!r.ok) throw new Error(await r.text());
      setRows(await r.json());
      setError(null);
    } catch (e:any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, []);

  async function setRole(id: string, role: 'user'|'admin') {
    const r = await fetch(`/api/admin/users/${id}/role`, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ role })});
    if (r.ok) load();
  }

  return (
    <div style={{padding:16}}>
      <h2>Admin · Users</h2>
      <AdminNav />
      {loading && <p>Loading…</p>}
      {error && <p style={{color:'red'}}>{error}</p>}
      {!loading && !error && (
        <table cellPadding={8} style={{width:'100%', borderCollapse:'collapse'}}>
          <thead><tr><th>Email</th><th>Name</th><th>Role</th><th>Joined</th><th>Actions</th></tr></thead>
          <tbody>
            {rows.map(u => (
              <tr key={u.id}>
                <td>{u.email}</td>
                <td>{u.name}</td>
                <td>{u.role || 'user'}</td>
                <td>{u.createdAt ? new Date(u.createdAt).toLocaleString() : ''}</td>
                <td>
                  <button onClick={() => setRole(u.id, 'user')}>Make user</button>
                  <button onClick={() => setRole(u.id, 'admin')} style={{marginLeft:8}}>Make admin</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
