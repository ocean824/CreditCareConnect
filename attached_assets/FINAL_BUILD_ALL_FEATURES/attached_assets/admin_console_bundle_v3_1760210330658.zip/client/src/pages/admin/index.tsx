
import React from 'react';
import AdminNav from '../../components/AdminNav';

export default function AdminHome() {
  return (
    <div style={{padding:16}}>
      <h2>Admin · Overview</h2>
      <AdminNav />
      <p>Use the tabs above to manage Users, Cases, Letters, and Client Responses.</p>
    </div>
  );
}
