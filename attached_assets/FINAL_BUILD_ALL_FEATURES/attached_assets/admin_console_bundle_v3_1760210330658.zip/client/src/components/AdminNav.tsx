
import React from 'react';
import { Link } from 'react-router-dom';

export default function AdminNav() {
  return (
    <nav style={{display:'flex', gap:12, marginBottom:16}}>
      <Link to="/admin">Overview</Link>
      <Link to="/admin/users">Users</Link>
      <Link to="/admin/cases">Cases</Link>
      <Link to="/admin/letters">Letters</Link>
      <Link to="/admin/responses">Responses</Link>
    </nav>
  );
}
