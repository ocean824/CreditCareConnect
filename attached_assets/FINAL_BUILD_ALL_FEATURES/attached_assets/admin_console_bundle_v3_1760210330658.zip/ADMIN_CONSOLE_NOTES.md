
# Admin Console Bundle v3

Adds:
- Backend `/api/admin` router (users list, role update, cases, letters, responses)
- Frontend pages: /admin, /admin/users, /admin/cases, /admin/letters, /admin/responses
- `AdminNav` component

## Server integration
In `server/routes.ts`:
```ts
import { adminRouter } from "./adminRoutes";
app.use('/api/admin', adminRouter);
```

## Client routing
Map routes to the new pages (React Router).

## Security
All `/api/admin/*` routes use `isAuthenticated` + `adminOnly` (from the RBAC patch).
