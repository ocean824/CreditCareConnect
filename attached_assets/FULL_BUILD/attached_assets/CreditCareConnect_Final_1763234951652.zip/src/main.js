import { createUI } from './components/ui.js';

window.addEventListener('DOMContentLoaded', () => {
  createUI(document.getElementById('app'));
});