# Case Detail + Bulk Actions Bundle (v5)

## Server (additions to `server/adminRoutes.ts`)
- `GET /api/admin/cases/:id` — returns `{ timeline[], client, caseId }`
  - `timeline` mixes: mail batches, delivery events, client uploads (sorted newest first)
- `GET /api/admin/cases/eligible-day34` — latest batch per case that is >=34 days old and status in mailed/in_transit/delivered
- `POST /api/admin/cases/bulk-remind-day34` — body `{ caseIds: string[] }`, sends Day‑34 email for each

> See `server/_adminRoutes_case_bulk_patch.txt` for the exact code to paste.

## Client (new pages)
- `client/src/pages/admin/case.tsx` — Case timeline view
- `client/src/pages/admin/bulk.tsx` — Select-many, send Day‑34 reminders

## Navigation
- Patch `AdminNav.tsx` to add a **Bulk** link.
- In the **Cases** page, make the Case ID clickable:
  ```tsx
  <Link to={\`/admin/case/${r.caseId}\`}>{r.caseId}</Link>
  ```

## Security
All endpoints live under `/api/admin` and should already be behind `isAuthenticated` + `adminOnly`.

## Notes
- Bulk reminder uses your existing token + email flow. SMS can be added similarly.
- Timeline is read-only; actions (re-mail, remind) remain on the Letters page.
