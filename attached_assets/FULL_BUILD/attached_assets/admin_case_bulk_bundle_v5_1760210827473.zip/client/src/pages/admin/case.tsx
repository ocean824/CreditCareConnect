import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import AdminNav from '../../components/AdminNav';

export default function AdminCaseDetail() {
  const { id } = useParams();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch(`/api/admin/cases/${id}`);
        if (!r.ok) throw new Error(await r.text());
        setData(await r.json());
      } catch (e:any) { setError(e.message); } finally { setLoading(false); }
    })();
  }, [id]);

  return (
    <div style={{padding:16}}>
      <h2>Admin · Case Detail</h2>
      <AdminNav />
      {loading && <p>Loading…</p>}
      {error && <p style={{color:'red'}}>{error}</p>}
      {data && (
        <>
          <p><b>Case:</b> {data.caseId}</p>
          <p><b>Client:</b> {data.client?.name} <small>({data.client?.email})</small></p>
          <h3>Timeline</h3>
          <ul>
            {data.timeline.map((t:any, i:number) => (
              <li key={i}>
                <code>{t.type}</code> · {t.at ? new Date(t.at).toLocaleString() : ''}
                {t.type === 'mail_batch' && (
                  <span> — Round {t.data.round} → {t.data.bureau} [{t.data.status}]</span>
                )}
                {t.type === 'delivery_event' && (
                  <span> — {t.data.kind}</span>
                )}
                {t.type === 'client_response' && (
                  <span> — <a href={t.data.fileUrl} target="_blank">uploaded file</a></span>
                )}
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}
