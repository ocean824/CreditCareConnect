import React, { useEffect, useState } from 'react';
import AdminNav from '../../components/AdminNav';

export default function AdminBulkActions() {
  const [rows, setRows] = useState<any[]>([]);
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch('/api/admin/cases/eligible-day34');
        if (!r.ok) throw new Error(await r.text());
        setRows(await r.json());
      } catch (e:any) { setError(e.message); } finally { setLoading(false); }
    })();
  }, []);

  const allIds = rows.map((r:any) => r.caseId);
  function toggleAll() {
    const next: Record<string, boolean> = {};
    const enabled = !allIds.every(id => selected[id]);
    for (const id of allIds) next[id] = enabled;
    setSelected(next);
  }
  function toggle(id: string) {
    setSelected(prev => ({ ...prev, [id]: !prev[id] }));
  }

  async function bulkRemind() {
    const caseIds = Object.entries(selected).filter(([,v]) => v).map(([k])=>k);
    if (caseIds.length === 0) return;
    setStatus(null);
    const r = await fetch('/api/admin/cases/bulk-remind-day34', {
      method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ caseIds })
    });
    if (r.ok) {
      const j = await r.json();
      setStatus(`Sent ${j.sent} reminder(s).`);
    } else {
      setStatus(`Error: ${await r.text()}`);
    }
  }

  return (
    <div style={{padding:16}}>
      <h2>Admin · Bulk Actions</h2>
      <AdminNav />
      {loading && <p>Loading…</p>}
      {error && <p style={{color:'red'}}>{error}</p>}
      {!loading && !error && (
        <>
          <div style={{margin:'8px 0'}}>
            <button onClick={toggleAll}>Select/Deselect All</button>
            <button onClick={bulkRemind} style={{marginLeft:8}}>Send Day‑34 Reminder</button>
            {status && <span style={{marginLeft:12}}>{status}</span>}
          </div>
          <table cellPadding={8} style={{width:'100%', borderCollapse:'collapse'}}>
            <thead><tr><th></th><th>Case</th><th>Client</th><th>Bureau</th><th>Round</th><th>Status</th><th>Created</th></tr></thead>
            <tbody>
              {rows.map((r:any) => (
                <tr key={r.caseId}>
                  <td><input type="checkbox" checked={!!selected[r.caseId]} onChange={()=>toggle(r.caseId)} /></td>
                  <td>{r.caseId}</td>
                  <td>{r.clientName} <small>({r.clientEmail})</small></td>
                  <td>{r.bureau}</td>
                  <td>{r.round}</td>
                  <td>{r.status}</td>
                  <td>{r.createdAt ? new Date(r.createdAt).toLocaleString() : ''}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}
    </div>
  );
}
