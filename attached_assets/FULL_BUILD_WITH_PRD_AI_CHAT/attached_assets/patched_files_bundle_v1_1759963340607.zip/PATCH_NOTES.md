# Patched Files Bundle v1

This bundle adds:
- One-time token flow (Yes/No + upload)
- Day-34 scheduler (hourly sweep)
- OCR + local LLM (Ollama) analysis
- Click2Mail webhook + proof/3811 notifications
- Static file hosting for uploads and generated PDFs
- Drizzle schema tables for tracking

## Files included
- server/oneTimeToken.ts
- server/ocr.ts
- server/scheduler.ts
- server/index.ts (patched)
- server/routes.ts (patched)
- shared/schema.ts (appended tables)

## Add dependencies
In your project root, install:

```bash
pnpm add tesseract.js pdf2pic node-fetch multer
# or: npm i tesseract.js pdf2pic node-fetch multer
```

## Required environment variables
```bash
PUBLIC_URL=https://<your-repl-url>
FILES_DIR=./files
C2M_RETURN_ADDRESS_JSON={"name":"Personal Credit Pro AI","address1":"175 DeSoto Blvd S Ste 3","city":"Naples","state":"FL","zip":"34117"}
```

## Click2Mail
Configure webhook to POST to:
- https://<your-repl-url>/webhooks/click2mail

## Ollama (free, local)
```bash
ollama pull mistral
ollama pull llama3
```

## Drizzle migration
Generate & run a migration for new tables (mail_batches, delivery_events, action_tokens, client_responses) according to your setup.

## Start
- Restart your Replit to pick up the scheduler and new routes.
- Verified endpoints:
  - GET /notify/answer?token=...
  - GET /notify/upload?token=...
  - POST /notify/upload (multipart)
  - POST /webhooks/click2mail
```
