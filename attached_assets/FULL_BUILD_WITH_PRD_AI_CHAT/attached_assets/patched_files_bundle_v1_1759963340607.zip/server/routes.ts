import type { Express } from "express";
import crypto from "crypto";
import multer from "multer";
import path from "path";
import fs from "fs";
import { mintActionToken, verifyAndConsumeToken } from "./oneTimeToken";
import { clientResponses, mailBatches, users, deliveryEvents } from "@shared/schema";
import { db } from "./db";
import { ocrPdfOrImage, ollamaGenerate } from "./ocr";
import { letterGeneratorService } from "./services/letterGenerator";
import { click2mailService } from "./services/click2mail";
import { eq } from "drizzle-orm";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
// import { analyzeCreditReport, generateDisputeLetter, chatWithAI, generateCFPBComplaint } from "./services/openai";
import { click2mailService } from "./services/click2mail";
import { letterGeneratorService } from "./services/letterGenerator";
import { notificationService } from "./services/notificationService";
import { insertCreditReportSchema, insertViolationSchema, insertDisputeLetterSchema, insertChatConversationSchema, insertCfpbComplaintSchema } from "@shared/schema";
import { createPaypalOrder, capturePaypalOrder, loadPaypalDefault } from "./paypal";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // PayPal routes
  app.get("/api/paypal/setup", async (req, res) => {
    await loadPaypalDefault(req, res);
  });

  app.post("/api/paypal/order", async (req, res) => {
    await createPaypalOrder(req, res);
  });

  app.post("/api/paypal/order/:orderID/capture", async (req, res) => {
    await capturePaypalOrder(req, res);
  });

  // PayPal subscription route
  app.post('/api/create-subscription', isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    let user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    if (user.paypalSubscriptionId) {
      return res.send({
        subscriptionId: user.paypalSubscriptionId,
        status: "active"
      });
    }
    
    if (!user.email) {
      return res.status(400).json({ message: 'No user email on file' });
    }

    try {
      // For now, create a simple subscription record
      // In production, you'd integrate with PayPal's subscription API
      const subscriptionId = `paypal_sub_${Date.now()}`;
      const customerId = user.paypalCustomerId || `paypal_cust_${Date.now()}`;
      
      await storage.updateUserPaypalInfo(userId, customerId, subscriptionId);
      await storage.updateUserPlan(userId, "DONE_FOR_YOU");
      
      // Send upgrade confirmation
      await notificationService.sendUpgradeConfirmation(user.email, user.firstName || 'User');
  
      res.send({
        subscriptionId: subscriptionId,
        status: "active"
      });
    } catch (error: any) {
      console.error("PayPal subscription error:", error);
      return res.status(400).send({ error: { message: error.message } });
    }
  });

  // Credit Report Analysis
  app.post('/api/credit-reports/upload', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { fileName, fileUrl, bureau } = req.body;

      // Validate request
      const validatedData = insertCreditReportSchema.parse({
        userId,
        fileName,
        fileUrl,
        bureau,
        analysisStatus: "PENDING"
      });

      const creditReport = await storage.createCreditReport(validatedData);

      // Start analysis in background (simplified for this implementation)
      setTimeout(async () => {
        try {
          // In real implementation, you'd extract text from PDF first
          const mockReportText = "Sample credit report text for analysis...";
          const analysis = {
            violations: [
              {
                accountName: "Test Account",
                accountNumber: "1234567890",
                bureau: bureau || "EQUIFAX",
                violationType: "INACCURATE_INFORMATION",
                description: "Account showing incorrect balance",
                statute: "FCRA Section 611",
                severity: "HIGH"
              }
            ]
          };
          
          // Update credit report with analysis results
          await storage.updateCreditReportAnalysis(
            creditReport.id, 
            analysis, 
            "COMPLETED"
          );

          // Create violation records
          for (const violation of analysis.violations) {
            await storage.createViolation({
              creditReportId: creditReport.id,
              accountName: violation.accountName,
              accountNumber: violation.accountNumber,
              bureau: violation.bureau,
              violationType: violation.violationType,
              description: violation.description,
              statute: violation.statute,
              severity: violation.severity,
              status: "IDENTIFIED"
            });
          }
        } catch (error) {
          console.error("Error in background analysis:", error);
          await storage.updateCreditReportAnalysis(creditReport.id, null, "FAILED");
        }
      }, 5000);

      res.json(creditReport);
    } catch (error) {
      console.error("Error uploading credit report:", error);
      res.status(500).json({ message: "Failed to upload credit report" });
    }
  });

  app.get('/api/credit-reports', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const creditReports = await storage.getCreditReportsByUserId(userId);
      res.json(creditReports);
    } catch (error) {
      console.error("Error fetching credit reports:", error);
      res.status(500).json({ message: "Failed to fetch credit reports" });
    }
  });

  // Violations
  app.get('/api/violations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const violations = await storage.getViolationsByUserId(userId);
      res.json(violations);
    } catch (error) {
      console.error("Error fetching violations:", error);
      res.status(500).json({ message: "Failed to fetch violations" });
    }
  });

  // Dispute Letters
  app.post('/api/dispute-letters/generate', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const { bureau, violationIds } = req.body;

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Get violations for letter generation
      const allViolations = await storage.getViolationsByUserId(userId);
      const selectedViolations = allViolations.filter(v => violationIds.includes(v.id));

      if (selectedViolations.length === 0) {
        return res.status(400).json({ message: "No violations selected" });
      }

      // Generate letter using AI
      const clientInfo = {
        name: `${user.firstName || ''} ${user.lastName || ''}`.trim() || 'Client',
        address: "123 Main Street", // You'd get this from user profile
        city: "Anytown",
        state: "FL",
        zip: "32801",
        dob: "01/01/1990", // You'd get this from user profile
        ssnLast4: "1234" // You'd get this from user profile
      };

      const { letterContent, pdfBuffer } = await letterGeneratorService.generateDisputeLetterPDF(
        selectedViolations.map(v => ({
          accountName: v.accountName,
          accountNumber: v.accountNumber || undefined,
          bureau: v.bureau,
          violationType: v.violationType,
          description: v.description,
          statute: v.statute,
          severity: v.severity
        })),
        bureau,
        clientInfo
      );

      // Save letter to database
      const disputeLetter = await storage.createDisputeLetter({
        userId,
        bureau,
        letterType: "INITIAL",
        content: letterContent,
        pdfUrl: `/api/dispute-letters/${bureau.toLowerCase()}-dispute.pdf`, // Simplified URL
        status: "GENERATED"
      });

      // If user is on Done-For-You plan, automatically send via Click2Mail
      if (user.plan === "DONE_FOR_YOU") {
        try {
          const mailingResult = await click2mailService.sendLetter({
            addressFrom: {
              name: "Personal Credit Pros",
              address1: "123 Business Ave",
              city: "Tampa",
              state: "FL",
              zip: "33601"
            },
            addressTo: {
              name: clientInfo.name,
              address1: clientInfo.address,
              city: clientInfo.city,
              state: clientInfo.state,
              zip: clientInfo.zip
            },
            document: pdfBuffer.toString('base64')
          });

          await storage.updateDisputeLetterStatus(
            disputeLetter.id,
            "SENT",
            mailingResult.jobId
          );
        } catch (mailingError) {
          console.error("Error sending letter via Click2Mail:", mailingError);
          // Letter is still generated, just not sent automatically
        }
      }

      res.json(disputeLetter);
    } catch (error) {
      console.error("Error generating dispute letter:", error);
      res.status(500).json({ message: "Failed to generate dispute letter" });
    }
  });

  app.get('/api/dispute-letters', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const letters = await storage.getDisputeLettersByUserId(userId);
      res.json(letters);
    } catch (error) {
      console.error("Error fetching dispute letters:", error);
      res.status(500).json({ message: "Failed to fetch dispute letters" });
    }
  });

  app.get('/api/dispute-letters/:id/download', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const letters = await storage.getDisputeLettersByUserId(req.user.claims.sub);
      const letter = letters.find(l => l.id === id);

      if (!letter) {
        return res.status(404).json({ message: "Letter not found" });
      }

      // In a real implementation, you'd retrieve the actual PDF
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${letter.bureau}-dispute-letter.pdf"`);
      res.send(Buffer.from("Sample PDF content"));
    } catch (error) {
      console.error("Error downloading dispute letter:", error);
      res.status(500).json({ message: "Failed to download dispute letter" });
    }
  });

  // AI Chat (stubbed until OpenAI key is configured)
  app.post('/api/chat', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const { message, conversationId } = req.body;

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Get conversation history
      let conversation;
      let conversationHistory: any[] = [];

      if (conversationId) {
        const conversations = await storage.getChatConversationsByUserId(userId);
        conversation = conversations.find(c => c.id === conversationId);
        if (conversation) {
          conversationHistory = conversation.messages as any[];
        }
      }

      // Get user's violations for context
      const violations = await storage.getViolationsByUserId(userId);

      // Generate AI response (stubbed for now)
      const aiResponse = "I'm here to help with your credit repair questions. This AI feature is currently being configured."

      // Update conversation
      const newMessage = { role: "user", content: message, timestamp: new Date() };
      const aiMessage = { role: "assistant", content: aiResponse, timestamp: new Date() };
      const updatedMessages = [...conversationHistory, newMessage, aiMessage];

      if (conversation) {
        await storage.updateChatConversation(conversation.id, updatedMessages);
      } else {
        conversation = await storage.createChatConversation({
          userId,
          messages: updatedMessages
        });
      }

      res.json({
        conversationId: conversation.id,
        response: aiResponse,
        messages: updatedMessages
      });
    } catch (error) {
      console.error("Error in AI chat:", error);
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });

  // CFPB Complaint Generation
  app.post('/api/cfpb-complaints/generate', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Get user's violations and dispute history
      const violations = await storage.getViolationsByUserId(userId);
      const disputeLetters = await storage.getDisputeLettersByUserId(userId);

      const clientInfo = {
        name: `${user.firstName || ''} ${user.lastName || ''}`.trim() || 'Client',
        email: user.email
      };

      // Generate CFPB complaint (stubbed for now)
      const complaintText = "Sample CFPB complaint text will be generated here.";
      const caseLawCitations = ["Sample case law citation"];

      // Generate PDF packet
      const pdfBuffer = await letterGeneratorService.generateCFPBPacketPDF(
        complaintText,
        caseLawCitations,
        disputeLetters.map(l => l.bureau + " Dispute Letter")
      );

      // Save to database
      const cfpbComplaint = await storage.createCfpbComplaint({
        userId,
        content: complaintText,
        supporting_documents: disputeLetters.map(l => l.pdfUrl || ""),
        caseLawCitations,
        status: "DRAFT"
      });

      res.json({
        ...cfpbComplaint,
        pdfUrl: `/api/cfpb-complaints/${cfpbComplaint.id}/download`
      });
    } catch (error) {
      console.error("Error generating CFPB complaint:", error);
      res.status(500).json({ message: "Failed to generate CFPB complaint" });
    }
  });

  // Admin Routes (protected by plan check)
  app.get('/api/admin/stats', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      
      // Simple admin check - in production you'd have proper role-based access
      if (!user?.email?.includes('admin')) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getUserStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });

  app.get('/api/admin/users', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      
      if (!user?.email?.includes('admin')) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ 
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        database: 'connected',
        paypal: process.env.PAYPAL_CLIENT_ID ? 'configured' : 'not configured',
        openai: process.env.OPENAI_API_KEY ? 'configured' : 'not configured',
        click2mail: process.env.CLICK2MAIL_API_KEY ? 'configured' : 'not configured',
        twilio: process.env.TWILIO_ACCOUNT_SID ? 'configured' : 'not configured'
      }
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}


    // --- One-time action endpoints ---
    app.get("/notify/answer", async (req, res) => {
      try {
        const tok = String(req.query.token || "");
        const row = await verifyAndConsumeToken(tok);
        if (row.purpose === "day34_yes") {
          const upTok = await mintActionToken(row.clientId, row.caseId, "upload_response");
          const url = `${process.env.PUBLIC_URL || ""}/notify/upload?token=${upTok}`;
          return res.status(200).send(`<h3>Great—please upload the bureau letter:</h3><a href="${url}">Upload</a>`);
        }
        return res.status(200).send("<h3>Thanks! If a letter arrives later, use the upload link we'll send next.</h3>");
      } catch {
        return res.status(410).send("<h3>Link invalid or expired.</h3>");
      }
    });

    app.get("/notify/upload", async (req, res) => {
      try {
        const tok = String(req.query.token || "");
        // validate
        await verifyAndConsumeToken(tok); // consume
        // mint a fresh token so POST can't be replayed with GET token
        const rowTok = await mintActionToken(String((req as any).user?.id || ""), String(req.query.caseId || ""), "upload_response", 24);
        res.status(200).send(`
          <form method="post" action="/notify/upload" enctype="multipart/form-data">
            <input type="hidden" name="token" value="${rowTok}"/>
            <input type="file" name="file" accept=".pdf,.jpg,.jpeg,.png" required/>
            <button type="submit">Upload</button>
          </form>
        `);
      } catch {
        return res.status(410).send("<h3>Link invalid or expired.</h3>");
      }
    });

    const upload = multer({ dest: process.env.FILES_DIR || path.join(process.cwd(), "files") });

    app.post("/notify/upload", upload.single("file"), async (req, res) => {
      try {
        const tok = String(req.body.token || "");
        const row = await verifyAndConsumeToken(tok);
        const file = req.file;
        if (!file) return res.status(400).send("Missing file");

        const fileUrl = `/files/${file.filename}`;
        await db.insert(clientResponses).values({
          id: crypto.randomUUID(),
          clientId: row.clientId,
          caseId: row.caseId,
          round: 1,
          fileUrl
        });

        const abs = path.join(process.env.FILES_DIR || path.join(process.cwd(), "files"), file.filename);
        const text = await ocrPdfOrImage(abs);

        const analysis = await ollamaGenerate("mistral", `You are a credit dispute analyst. Classify this bureau letter and propose the next dispute step.
Return JSON with: outcome(one of: verified, deleted, updated, needs_more_info, unclear),
reason, next_letter_guidance (<=200 words).
LETTER:
${text.slice(0, 8000)}
        `);

        const client = (await db.select().from(users).where(eq(users.id, row.clientId))).at(0);
        const batches = await db.select().from(mailBatches).where(eq(mailBatches.caseId, row.caseId));
        const last = batches.sort((a: any,b: any)=>+new Date(b.createdAt)-+new Date(a.createdAt))[0];
        const nextRound = Math.min((last?.round || 1) + 1, 3);
        const bureau = last?.bureau || "TransUnion";

        const body = await ollamaGenerate("llama3", `Draft a UNIQUE, specific dispute letter for round ${nextRound}.
Client: ${client?.name || ""} | ${client?.address || ""}
Bureau: ${bureau}
Use the analysis:
${analysis}
Keep < 250 words, include FCRA references, professional tone.`);

        const pdf = await letterGeneratorService.generateLetterPdf({
          client: { name: client?.name || "Client", address: client?.address || "", city: "", state: "", zip: "" },
          bureau: { name: bureau, address1: "", city: "", state: "", zip: "" },
          body
        });

        const outName = `round${nextRound}_${Date.now()}.pdf`;
        const outPath = path.join(process.env.FILES_DIR || path.join(process.cwd(), "files"), outName);
        fs.writeFileSync(outPath, pdf);
        const job = await click2mailService.submitCertifiedMail({
          addressFrom: JSON.parse(process.env.C2M_RETURN_ADDRESS_JSON || `{"name":"Personal Credit Pro AI","address1":"175 DeSoto Blvd S Ste 3","city":"Naples","state":"FL","zip":"34117"}`),
          addressTo: { name: bureau, address1: "", city: "", state: "", zip: "" },
          document: Buffer.from(pdf).toString("base64")
        });

        await db.insert(mailBatches).values({
          id: crypto.randomUUID(),
          clientId: row.clientId,
          caseId: row.caseId,
          bureau,
          round: nextRound,
          click2mailJobId: (job as any).jobId,
          status: "mailed"
        });

        res.status(200).send("<h3>Uploaded—thanks! We processed your response and mailed the next round automatically.</h3>");
      } catch (e) {
        console.error(e);
        return res.status(500).send("Upload failed");
      }
    });

    // Click2Mail webhook
    app.post("/webhooks/click2mail", async (req, res) => {
      try {
        const payload = req.body || {};
        const jobId = payload.jobId || payload.job_id;
        const tracking = payload.uspsTracking;
        const proofUrl = payload.proofUrl || payload.greenCardUrl;
        const status = String(payload.status || "").toLowerCase();

        const batch = (await db.select().from(mailBatches).where(eq(mailBatches.click2mailJobId, jobId))).at(0);
        if (!batch) return res.json({ ok: true });

        await db.insert(deliveryEvents).values({
          id: crypto.randomUUID(),
          batchId: batch.id,
          kind: status || "unknown",
          payload
        });

        const updates: any = {};
        if (tracking && !batch.uspsTracking) updates.uspsTracking = tracking;
        if (proofUrl) updates.proofUrl = proofUrl;
        if (status) updates.status = status;
        if (Object.keys(updates).length) {
          await db.update(mailBatches).set(updates).where(eq(mailBatches.id, batch.id));
        }

        if (["mailed", "delivered", "3811_available"].includes(status)) {
          const client = (await db.select({ email: users.email }).from(users).where(eq(users.id, batch.clientId))).at(0);
          if (client?.email) {
            let html = `<p>Status update for your certified letter to ${batch.bureau}: <b>${status.toUpperCase()}</b></p>`;
            if (tracking) html += `<p>USPS tracking: ${tracking}</p>`;
            if (proofUrl) html += `<p>Proof / 3811: <a href="${proofUrl}">View</a></p>`;
            await notificationService.sendEmail(client.email, `Certified Mail Update – ${status}`, html);
          }
        }

        res.json({ ok: true });
      } catch (e) {
        console.error("click2mail webhook error", e);
        res.status(500).json({ ok: false });
      }
    });
