import { db } from "./db";
import { users } from "@shared/schema";
import { eq, inArray } from "drizzle-orm";

// Accept ADMIN_EMAILS="a@x.com,b@y.com" as bootstrap override
const ADMIN_EMAILS = (process.env.ADMIN_EMAILS || "")
  .split(",")
  .map(s => s.trim().toLowerCase())
  .filter(Boolean);

export async function adminOnly(req: any, res: any, next: any) {
  if (!req.user?.claims?.sub) return res.status(401).json({ message: "Unauthorized" });
  const uid = req.user.claims.sub;
  const [u] = await db.select().from(users).where(eq(users.id, uid));
  if (!u) return res.status(401).json({ message: "Unauthorized" });

  // Role check or bootstrap email allowlist
  const email = (u.email || "").toLowerCase();
  const bootstrapOK = ADMIN_EMAILS.includes(email);
  if (u.role === "admin" || bootstrapOK) return next();

  return res.status(403).json({ message: "Admin access required" });
}
