# RBAC Patch Bundle v2 (Admin Portal Hardening)

This patch converts the admin access from a fragile "email contains 'admin'" check to **real RBAC** using a `role` field, and exposes the role to the client.

## Files
- `shared/schema.ts` — adds `role` column to `users` (default `'user'`).
- `server/adminOnly.ts` — middleware to enforce `role==='admin'` (or emails in `ADMIN_EMAILS` for bootstrap).
- `server/routes.ts` — admin endpoints now use `adminOnly`; added `/api/me` to surface `{ role }` to the client.
- `server/index.ts` — optional startup bootstrap that promotes any emails in `ADMIN_EMAILS` env var to admin in DB.
- `client/src/components/Navigation.tsx` — shows **Admin** link only if `user.role==='admin'`.

## Environment
- `ADMIN_EMAILS="owner@yourdomain.com, admin@yourdomain.com"` (optional bootstrap)

## Migration
- Add `role` column to `users` via your Drizzle migration. Example SQL:
  ```sql
  ALTER TABLE users ADD COLUMN role varchar(10) NOT NULL DEFAULT 'user';
  ```
  Or generate via Drizzle migration tooling.

## After deploy
- Set `ADMIN_EMAILS` with your email(s) once, restart the app, and your account becomes `role='admin'`.
- You can later unset `ADMIN_EMAILS`; the role stays persisted in DB.
- Admin portal remains at `/admin`. Client nav now shows it only for admins.
