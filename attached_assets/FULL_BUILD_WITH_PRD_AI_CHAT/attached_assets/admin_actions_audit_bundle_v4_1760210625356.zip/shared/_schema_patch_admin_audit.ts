
// --- ADMIN AUDIT LOGS ---
import { pgTable, varchar, jsonb, timestamp } from "drizzle-orm/pg-core";
import { users } from "./schema"; // adjust import if needed

export const adminAuditLogs = pgTable("admin_audit_logs", {
  id: varchar("id").primaryKey(),
  actorId: varchar("actor_id").notNull().references(() => users.id),
  action: varchar("action").notNull(),             // e.g., 'remind_day34', 'remail'
  targetType: varchar("target_type").notNull(),    // 'mail_batch' | 'case' | 'user'
  targetId: varchar("target_id").notNull(),
  meta: jsonb("meta"),
  createdAt: timestamp("created_at").defaultNow()
});
