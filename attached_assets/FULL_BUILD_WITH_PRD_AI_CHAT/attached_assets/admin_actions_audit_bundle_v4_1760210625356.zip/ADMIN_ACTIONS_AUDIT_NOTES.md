
# Admin Actions + Audit Bundle (v4)

Adds:
- **Audit logs** table `admin_audit_logs` + server helper `logAdminAction(...)`
- **Letters actions**: POST `/api/admin/letters/:id/remind-day34` and `/api/admin/letters/:id/remail`
- **Letters listing** now includes client name/email
- **Audit page** at `/admin/audit`

## Server integration steps
1) Merge `shared/_schema_patch_admin_audit.ts` content into your `shared/schema.ts` and run a migration.
2) In `server/adminRoutes.ts`, integrate the code from `server/_adminRoutes_patch.txt`:
   - Extra imports
   - Replace the existing `/letters` handler with the enriched one
   - Add the two POST action routes
   - Add `/audit` route
3) Ensure you already have:
   - `oneTimeToken` utilities
   - `letterGeneratorService` and `click2mailService`
   - `notificationService`

## Client integration
- Replace your `client/src/pages/admin/letters.tsx` with the provided file to show buttons and names.
- Add the new page `client/src/pages/admin/audit.tsx` and map route `/admin/audit`.
- Add the "Audit" link to `AdminNav.tsx` as shown in `client/src/components/_AdminNav_patch.txt`.

## Security
All endpoints are under `/api/admin` and assume `isAuthenticated` + `adminOnly` are applied via the admin router.
