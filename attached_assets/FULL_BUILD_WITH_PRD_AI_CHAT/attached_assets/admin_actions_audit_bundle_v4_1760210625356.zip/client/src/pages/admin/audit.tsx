
import React, { useEffect, useState } from 'react';
import AdminNav from '../../components/AdminNav';

export default function AdminAudit() {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch('/api/admin/audit?limit=200');
        if (!r.ok) throw new Error(await r.text());
        setRows(await r.json());
      } catch (e:any) { setError(e.message); } finally { setLoading(false); }
    })();
  }, []);

  return (
    <div style={{padding:16}}>
      <h2>Admin · Audit Log</h2>
      <AdminNav />
      {loading && <p>Loading…</p>}
      {error && <p style={{color:'red'}}>{error}</p>}
      {!loading && !error && (
        <table cellPadding={8} style={{width:'100%', borderCollapse:'collapse'}}>
          <thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Target</th><th>Meta</th></tr></thead>
          <tbody>
            {rows.map((r:any) => (
              <tr key={r.id}>
                <td>{r.createdAt ? new Date(r.createdAt).toLocaleString() : ''}</td>
                <td>{r.actorId}</td>
                <td>{r.action}</td>
                <td>{r.targetType}:{r.targetId}</td>
                <td><pre style={{margin:0}}>{r.meta ? JSON.stringify(r.meta) : ''}</pre></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
