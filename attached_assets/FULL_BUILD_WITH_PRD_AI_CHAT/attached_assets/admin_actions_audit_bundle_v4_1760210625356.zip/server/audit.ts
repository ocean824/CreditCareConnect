
import crypto from "crypto";
import { db } from "./db";
import { adminAuditLogs } from "@shared/schema";

export async function logAdminAction(actorId: string, action: string, targetType: string, targetId: string, meta?: any) {
  await db.insert(adminAuditLogs).values({
    id: crypto.randomUUID(),
    actorId, action, targetType, targetId, meta: meta || {}
  });
}
