import {
  users,
  creditReports,
  violations,
  disputeLetters,
  disputeLetterViolations,
  chatConversations,
  notifications,
  cfpbComplaints,
  analysisRuns,
  issues,
  aiIssueExplanations,
  accountSummaries,
  type User,
  type UpsertUser,
  type InsertCreditReport,
  type CreditReport,
  type InsertViolation,
  type Violation,
  type InsertDisputeLetter,
  type DisputeLetter,
  type InsertChatConversation,
  type ChatConversation,
  type InsertNotification,
  type Notification,
  type InsertCfpbComplaint,
  type CfpbComplaint,
  type InsertAnalysisRun,
  type AnalysisRun,
  type InsertIssue,
  type Issue,
  type InsertAiIssueExplanation,
  type AiIssueExplanation,
  type InsertAccountSummary,
  type AccountSummary,
} from "@shared/schema";
import {
  extractionRunsV2,
  documentPagesV2,
  documentBlocksV2,
  analysisRunsV2,
  parsedReportSnapshotsV2,
  reportEntitiesV2,
  entityEvidenceV2,
  aiVerificationTasksV2,
  ruleFindingsV2,
  ruleFindingEvidenceV2,
  findingExplanationsV2,
  reviewQueueV2,
  disputeLetterItemsV2,
  type ExtractionRunV2,
  type InsertExtractionRunV2,
  type DocumentPageV2,
  type InsertDocumentPageV2,
  type DocumentBlockV2,
  type InsertDocumentBlockV2,
  type AnalysisRunV2,
  type InsertAnalysisRunV2,
  type ParsedReportSnapshotV2,
  type InsertParsedReportSnapshotV2,
  type ReportEntityV2,
  type InsertReportEntityV2,
  type EntityEvidenceV2,
  type InsertEntityEvidenceV2,
  type RuleFindingV2Row,
  type InsertRuleFindingV2,
  type RuleFindingEvidenceV2,
  type InsertRuleFindingEvidenceV2,
  type FindingExplanationV2,
  type InsertFindingExplanationV2,
  type ReviewQueueV2,
  type InsertReviewQueueV2,
  type DisputeLetterItemV2,
  type InsertDisputeLetterItemV2,
} from "@shared/schema.credit-analysis-v2";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserStripeInfo(userId: string, customerId: string, subscriptionId: string): Promise<User>;
  updateUserPlan(userId: string, plan: string): Promise<User>;
  updateUserProfile(userId: string, data: { firstName?: string; lastName?: string }): Promise<User>;
  
  // Credit Report operations
  createCreditReport(report: InsertCreditReport): Promise<CreditReport>;
  getCreditReportById(id: string): Promise<CreditReport | undefined>;
  getCreditReportsByUserId(userId: string, includeDeleted?: boolean): Promise<CreditReport[]>;
  updateCreditReportAnalysis(id: string, analysisResults: any, status: string, analysisNumber?: number): Promise<CreditReport>;
  deleteCreditReport(id: string): Promise<void>;
  softDeleteCreditReport(id: string): Promise<CreditReport>;
  restoreCreditReport(id: string): Promise<CreditReport>;
  getNextAnalysisNumber(userId: string): Promise<number>;
  updateCreditReportRetention(id: string, retainAnalysis: boolean): Promise<CreditReport>;
  clearLastAnalysis(userId: string): Promise<void>;
  
  // Violations operations
  createViolation(violation: InsertViolation): Promise<Violation>;
  getViolationsByReportId(creditReportId: string): Promise<Violation[]>;
  getViolationsByUserId(userId: string): Promise<Violation[]>;
  deleteViolationsByReportId(creditReportId: string): Promise<void>;
  deleteAnalysisDataByReportId(creditReportId: string): Promise<void>;
  
  // Dispute Letters operations
  createDisputeLetter(letter: InsertDisputeLetter): Promise<DisputeLetter>;
  getDisputeLettersByUserId(userId: string): Promise<DisputeLetter[]>;
  updateDisputeLetterStatus(id: string, status: string, mailingId?: string): Promise<DisputeLetter>;
  
  // Chat operations
  createChatConversation(conversation: InsertChatConversation): Promise<ChatConversation>;
  getChatConversationsByUserId(userId: string): Promise<ChatConversation[]>;
  updateChatConversation(id: string, messages: any[]): Promise<ChatConversation>;
  
  // Notifications operations
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotificationsByUserId(userId: string): Promise<Notification[]>;
  
  // CFPB operations
  createCfpbComplaint(complaint: InsertCfpbComplaint): Promise<CfpbComplaint>;
  getCfpbComplaintsByUserId(userId: string): Promise<CfpbComplaint[]>;
  
  // Admin operations
  getAllUsers(): Promise<User[]>;
  getUserStats(): Promise<{
    totalUsers: number;
    proSubscribers: number;
    monthlyRevenue: number;
    lettersSent: number;
  }>;
  
  // Advanced Analysis operations
  createAnalysisRun(run: InsertAnalysisRun): Promise<AnalysisRun>;
  getAnalysisRunsByReportId(creditReportId: string): Promise<AnalysisRun[]>;
  updateAnalysisRunStatus(id: string, status: string, completedAt?: Date, issueCount?: number, aiIssueCount?: number): Promise<AnalysisRun>;
  
  createIssue(issue: InsertIssue): Promise<Issue>;
  getIssuesByRunId(runId: string): Promise<Issue[]>;
  
  createAiIssueExplanation(explanation: InsertAiIssueExplanation): Promise<AiIssueExplanation>;
  getAiIssueExplanationsByRunId(runId: string): Promise<AiIssueExplanation[]>;
  
  createAccountSummary(summary: InsertAccountSummary): Promise<AccountSummary>;
  getAccountSummariesByRunId(runId: string): Promise<AccountSummary[]>;

  // V2 analysis pipeline
  createExtractionRunV2(run: InsertExtractionRunV2): Promise<ExtractionRunV2>;
  createDocumentPageV2(page: InsertDocumentPageV2): Promise<DocumentPageV2>;
  createDocumentBlockV2(block: InsertDocumentBlockV2): Promise<DocumentBlockV2>;
  createAnalysisRunV2(run: InsertAnalysisRunV2): Promise<AnalysisRunV2>;
  updateAnalysisRunV2Status(id: string, status: string, opts?: { reviewStatus?: string; overallConfidence?: number; summary?: Record<string, unknown>; completedAt?: Date | null }): Promise<AnalysisRunV2>;
  createParsedReportSnapshotV2(row: InsertParsedReportSnapshotV2): Promise<ParsedReportSnapshotV2>;
  createReportEntityV2(row: InsertReportEntityV2): Promise<ReportEntityV2>;
  createEntityEvidenceV2(row: InsertEntityEvidenceV2): Promise<EntityEvidenceV2>;
  createRuleFindingV2(row: InsertRuleFindingV2): Promise<RuleFindingV2Row>;
  createRuleFindingEvidenceV2(row: InsertRuleFindingEvidenceV2): Promise<RuleFindingEvidenceV2>;
  createFindingExplanationV2(row: InsertFindingExplanationV2): Promise<FindingExplanationV2>;
  createReviewQueueV2(row: InsertReviewQueueV2): Promise<ReviewQueueV2>;
  createDisputeLetterItemV2(row: InsertDisputeLetterItemV2): Promise<DisputeLetterItemV2>;
  getLatestAnalysisRunV2ByReportId(creditReportId: string): Promise<AnalysisRunV2 | undefined>;
  getRuleFindingsV2ByRunId(runId: string): Promise<RuleFindingV2Row[]>;
  getFindingExplanationsV2ByRunId(runId: string): Promise<FindingExplanationV2[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existingUser = await this.getUserByEmail(userData.email!);
    
    if (existingUser) {
      const updateData: any = {};
      Object.keys(userData).forEach(key => {
        if (userData[key as keyof UpsertUser] !== undefined) {
          updateData[key] = userData[key as keyof UpsertUser];
        }
      });
      updateData.updatedAt = new Date();
      
      const [user] = await db
        .update(users)
        .set(updateData)
        .where(eq(users.id, existingUser.id))
        .returning();
      return user;
    } else {
      const [user] = await db
        .insert(users)
        .values({
          ...userData,
          plan: userData.plan || 'DIY',
        })
        .returning();
      return user;
    }
  }

  async updateUserStripeInfo(userId: string, customerId: string, subscriptionId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        stripeCustomerId: customerId,
        stripeSubscriptionId: subscriptionId,
        plan: "DONE_FOR_YOU",
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserPlan(userId: string, plan: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        plan,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserProfile(userId: string, data: { firstName?: string; lastName?: string }): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Credit Report operations
  async createCreditReport(report: InsertCreditReport): Promise<CreditReport> {
    const [creditReport] = await db
      .insert(creditReports)
      .values(report)
      .returning();
    return creditReport;
  }

  async getCreditReportById(id: string): Promise<CreditReport | undefined> {
    const [report] = await db.select().from(creditReports).where(eq(creditReports.id, id));
    return report;
  }

  async getCreditReportsByUserId(userId: string, includeDeleted: boolean = false): Promise<CreditReport[]> {
    if (includeDeleted) {
      return await db
        .select()
        .from(creditReports)
        .where(eq(creditReports.userId, userId))
        .orderBy(desc(creditReports.createdAt));
    }
    return await db
      .select()
      .from(creditReports)
      .where(and(
        eq(creditReports.userId, userId),
        eq(creditReports.isDeleted, false)
      ))
      .orderBy(desc(creditReports.createdAt));
  }

  async updateCreditReportAnalysis(id: string, analysisResults: any, status: string, analysisNumber?: number): Promise<CreditReport> {
    const updateData: any = {
      analysisResults,
      analysisStatus: status,
    };
    if (analysisNumber !== undefined) {
      updateData.analysisNumber = analysisNumber;
    }
    const [creditReport] = await db
      .update(creditReports)
      .set(updateData)
      .where(eq(creditReports.id, id))
      .returning();
    return creditReport;
  }

  async deleteCreditReport(id: string): Promise<void> {
    // Delete related records first
    await db.delete(violations).where(eq(violations.creditReportId, id));
    await db.delete(analysisRuns).where(eq(analysisRuns.creditReportId, id));
    await db.delete(issues).where(eq(issues.runId, sql`(SELECT id FROM analysis_runs WHERE credit_report_id = ${id})`));
    await db.delete(aiIssueExplanations).where(eq(aiIssueExplanations.runId, sql`(SELECT id FROM analysis_runs WHERE credit_report_id = ${id})`));
    // Delete the credit report itself
    await db.delete(creditReports).where(eq(creditReports.id, id));
  }

  async softDeleteCreditReport(id: string): Promise<CreditReport> {
    const [creditReport] = await db
      .update(creditReports)
      .set({
        isDeleted: true,
        deletedAt: new Date(),
      })
      .where(eq(creditReports.id, id))
      .returning();
    return creditReport;
  }

  async restoreCreditReport(id: string): Promise<CreditReport> {
    const [creditReport] = await db
      .update(creditReports)
      .set({
        isDeleted: false,
        deletedAt: null,
      })
      .where(eq(creditReports.id, id))
      .returning();
    return creditReport;
  }

  async getNextAnalysisNumber(userId: string): Promise<number> {
    const result = await db
      .select({ maxNumber: sql<number>`COALESCE(MAX(${creditReports.analysisNumber}), 0)` })
      .from(creditReports)
      .where(eq(creditReports.userId, userId));
    return (result[0]?.maxNumber || 0) + 1;
  }

  async updateCreditReportRetention(id: string, retainAnalysis: boolean): Promise<CreditReport> {
    const [creditReport] = await db
      .update(creditReports)
      .set({ retainAnalysis })
      .where(eq(creditReports.id, id))
      .returning();
    return creditReport;
  }

  async clearLastAnalysis(userId: string): Promise<void> {
    // Get the most recent analysis for this user
    const reports = await db
      .select()
      .from(creditReports)
      .where(and(
        eq(creditReports.userId, userId),
        eq(creditReports.isDeleted, false)
      ))
      .orderBy(desc(creditReports.createdAt))
      .limit(1);
    
    if (reports.length > 0) {
      const reportId = reports[0].id;
      // Only clear if retainAnalysis is false
      if (!reports[0].retainAnalysis) {
        await db.delete(violations).where(eq(violations.creditReportId, reportId));
        await this.deleteAnalysisDataByReportId(reportId);
        await db
          .update(creditReports)
          .set({
            analysisResults: null,
            analysisStatus: "PENDING",
          })
          .where(eq(creditReports.id, reportId));
      }
    }
  }

  // Violations operations
  async createViolation(violation: InsertViolation): Promise<Violation> {
    const [newViolation] = await db
      .insert(violations)
      .values(violation)
      .returning();
    return newViolation;
  }

  async getViolationsByReportId(creditReportId: string): Promise<Violation[]> {
    return await db
      .select()
      .from(violations)
      .where(eq(violations.creditReportId, creditReportId))
      .orderBy(desc(violations.createdAt));
  }

  async getViolationsByUserId(userId: string): Promise<Violation[]> {
    return await db
      .select({
        id: violations.id,
        creditReportId: violations.creditReportId,
        accountName: violations.accountName,
        accountNumber: violations.accountNumber,
        bureau: violations.bureau,
        violationType: violations.violationType,
        description: violations.description,
        statute: violations.statute,
        severity: violations.severity,
        status: violations.status,
        createdAt: violations.createdAt,
      })
      .from(violations)
      .innerJoin(creditReports, eq(violations.creditReportId, creditReports.id))
      .where(eq(creditReports.userId, userId))
      .orderBy(desc(violations.createdAt));
  }

  async deleteViolationsByReportId(creditReportId: string): Promise<void> {
    await db.delete(violations).where(eq(violations.creditReportId, creditReportId));
  }

  async deleteAnalysisDataByReportId(creditReportId: string): Promise<void> {
    const runs = await db.select().from(analysisRuns).where(eq(analysisRuns.creditReportId, creditReportId));
    for (const run of runs) {
      await db.delete(issues).where(eq(issues.runId, run.id));
      await db.delete(aiIssueExplanations).where(eq(aiIssueExplanations.runId, run.id));
    }
    await db.delete(analysisRuns).where(eq(analysisRuns.creditReportId, creditReportId));
  }

  // Dispute Letters operations
  async createDisputeLetter(letter: InsertDisputeLetter): Promise<DisputeLetter> {
    const [disputeLetter] = await db
      .insert(disputeLetters)
      .values(letter)
      .returning();
    return disputeLetter;
  }

  async getDisputeLettersByUserId(userId: string): Promise<DisputeLetter[]> {
    return await db
      .select()
      .from(disputeLetters)
      .where(eq(disputeLetters.userId, userId))
      .orderBy(desc(disputeLetters.createdAt));
  }

  async updateDisputeLetterStatus(id: string, status: string, mailingId?: string): Promise<DisputeLetter> {
    const updateData: any = { status };
    if (mailingId) {
      updateData.mailingId = mailingId;
    }
    if (status === "SENT") {
      updateData.sentAt = new Date();
      // Set response deadline to 30 days from sent date
      updateData.responseDeadline = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    }

    const [disputeLetter] = await db
      .update(disputeLetters)
      .set(updateData)
      .where(eq(disputeLetters.id, id))
      .returning();
    return disputeLetter;
  }

  // Chat operations
  async createChatConversation(conversation: InsertChatConversation): Promise<ChatConversation> {
    const [chatConversation] = await db
      .insert(chatConversations)
      .values(conversation)
      .returning();
    return chatConversation;
  }

  async getChatConversationsByUserId(userId: string): Promise<ChatConversation[]> {
    return await db
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.userId, userId))
      .orderBy(desc(chatConversations.updatedAt));
  }

  async updateChatConversation(id: string, messages: any[]): Promise<ChatConversation> {
    const [chatConversation] = await db
      .update(chatConversations)
      .set({
        messages,
        updatedAt: new Date(),
      })
      .where(eq(chatConversations.id, id))
      .returning();
    return chatConversation;
  }

  // Notifications operations
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db
      .insert(notifications)
      .values(notification)
      .returning();
    return newNotification;
  }

  async getNotificationsByUserId(userId: string): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  // CFPB operations
  async createCfpbComplaint(complaint: InsertCfpbComplaint): Promise<CfpbComplaint> {
    const [cfpbComplaint] = await db
      .insert(cfpbComplaints)
      .values(complaint)
      .returning();
    return cfpbComplaint;
  }

  async getCfpbComplaintsByUserId(userId: string): Promise<CfpbComplaint[]> {
    return await db
      .select()
      .from(cfpbComplaints)
      .where(eq(cfpbComplaints.userId, userId))
      .orderBy(desc(cfpbComplaints.createdAt));
  }

  // Admin operations
  async getAllUsers(): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .orderBy(desc(users.createdAt));
  }

  async getUserStats(): Promise<{
    totalUsers: number;
    proSubscribers: number;
    monthlyRevenue: number;
    lettersSent: number;
  }> {
    const allUsers = await this.getAllUsers();
    const totalUsers = allUsers.length;
    const diySubscribers = allUsers.filter(user => user.plan === "DIY").length;
    const proSubscribers = allUsers.filter(user => user.plan === "DONE_FOR_YOU").length;
    const monthlyRevenue = (diySubscribers * 19.95) + (proSubscribers * 149.99); // $19.95 per DIY + $149.99 per pro subscriber
    
    // Count sent letters
    const sentLetters = await db
      .select()
      .from(disputeLetters)
      .where(eq(disputeLetters.status, "SENT"));
    
    return {
      totalUsers,
      proSubscribers,
      monthlyRevenue,
      lettersSent: sentLetters.length,
    };
  }

  // Advanced Analysis operations
  async createAnalysisRun(run: InsertAnalysisRun): Promise<AnalysisRun> {
    const [analysisRun] = await db
      .insert(analysisRuns)
      .values(run)
      .returning();
    return analysisRun;
  }

  async getAnalysisRunsByReportId(creditReportId: string): Promise<AnalysisRun[]> {
    return await db
      .select()
      .from(analysisRuns)
      .where(eq(analysisRuns.creditReportId, creditReportId))
      .orderBy(desc(analysisRuns.startedAt));
  }

  async updateAnalysisRunStatus(
    id: string, 
    status: string, 
    completedAt?: Date, 
    issueCount?: number, 
    aiIssueCount?: number
  ): Promise<AnalysisRun> {
    const updateData: any = { status };
    if (completedAt) updateData.completedAt = completedAt;
    if (issueCount !== undefined) updateData.issueCount = issueCount;
    if (aiIssueCount !== undefined) updateData.aiIssueCount = aiIssueCount;

    const [analysisRun] = await db
      .update(analysisRuns)
      .set(updateData)
      .where(eq(analysisRuns.id, id))
      .returning();
    return analysisRun;
  }

  async createIssue(issue: InsertIssue): Promise<Issue> {
    const [newIssue] = await db
      .insert(issues)
      .values(issue)
      .returning();
    return newIssue;
  }

  async getIssuesByRunId(runId: string): Promise<Issue[]> {
    return await db
      .select()
      .from(issues)
      .where(eq(issues.runId, runId))
      .orderBy(desc(issues.createdAt));
  }

  async createAiIssueExplanation(explanation: InsertAiIssueExplanation): Promise<AiIssueExplanation> {
    const [newExplanation] = await db
      .insert(aiIssueExplanations)
      .values(explanation)
      .returning();
    return newExplanation;
  }

  async getAiIssueExplanationsByRunId(runId: string): Promise<AiIssueExplanation[]> {
    return await db
      .select()
      .from(aiIssueExplanations)
      .where(eq(aiIssueExplanations.runId, runId))
      .orderBy(desc(aiIssueExplanations.createdAt));
  }

  async createAccountSummary(summary: InsertAccountSummary): Promise<AccountSummary> {
    const [newSummary] = await db
      .insert(accountSummaries)
      .values(summary)
      .returning();
    return newSummary;
  }

  async getAccountSummariesByRunId(runId: string): Promise<AccountSummary[]> {
    return await db
      .select()
      .from(accountSummaries)
      .where(eq(accountSummaries.runId, runId))
      .orderBy(desc(accountSummaries.createdAt));
  }

  async createExtractionRunV2(run: InsertExtractionRunV2): Promise<ExtractionRunV2> {
    const [row] = await db.insert(extractionRunsV2).values(run).returning();
    return row;
  }

  async createDocumentPageV2(page: InsertDocumentPageV2): Promise<DocumentPageV2> {
    const [row] = await db.insert(documentPagesV2).values(page).returning();
    return row;
  }

  async createDocumentBlockV2(block: InsertDocumentBlockV2): Promise<DocumentBlockV2> {
    const [row] = await db.insert(documentBlocksV2).values(block).returning();
    return row;
  }

  async createAnalysisRunV2(run: InsertAnalysisRunV2): Promise<AnalysisRunV2> {
    const [row] = await db.insert(analysisRunsV2).values(run).returning();
    return row;
  }

  async updateAnalysisRunV2Status(id: string, status: string, opts?: { reviewStatus?: string; overallConfidence?: number; summary?: Record<string, unknown>; completedAt?: Date | null }): Promise<AnalysisRunV2> {
    const updateData: any = { status };
    if (opts?.reviewStatus !== undefined) updateData.reviewStatus = opts.reviewStatus;
    if (opts?.overallConfidence !== undefined) updateData.overallConfidence = String(opts.overallConfidence);
    if (opts?.summary !== undefined) updateData.summary = opts.summary;
    if (opts?.completedAt !== undefined) updateData.completedAt = opts.completedAt;
    const [row] = await db.update(analysisRunsV2).set(updateData).where(eq(analysisRunsV2.id, id)).returning();
    return row;
  }

  async createParsedReportSnapshotV2(row: InsertParsedReportSnapshotV2): Promise<ParsedReportSnapshotV2> {
    const [created] = await db.insert(parsedReportSnapshotsV2).values(row).returning();
    return created;
  }

  async createReportEntityV2(row: InsertReportEntityV2): Promise<ReportEntityV2> {
    const [created] = await db.insert(reportEntitiesV2).values(row).returning();
    return created;
  }

  async createEntityEvidenceV2(row: InsertEntityEvidenceV2): Promise<EntityEvidenceV2> {
    const [created] = await db.insert(entityEvidenceV2).values(row).returning();
    return created;
  }

  async createRuleFindingV2(row: InsertRuleFindingV2): Promise<RuleFindingV2Row> {
    const [created] = await db.insert(ruleFindingsV2).values(row).returning();
    return created;
  }

  async createRuleFindingEvidenceV2(row: InsertRuleFindingEvidenceV2): Promise<RuleFindingEvidenceV2> {
    const [created] = await db.insert(ruleFindingEvidenceV2).values(row).returning();
    return created;
  }

  async createFindingExplanationV2(row: InsertFindingExplanationV2): Promise<FindingExplanationV2> {
    const [created] = await db.insert(findingExplanationsV2).values(row).returning();
    return created;
  }

  async createReviewQueueV2(row: InsertReviewQueueV2): Promise<ReviewQueueV2> {
    const [created] = await db.insert(reviewQueueV2).values(row).returning();
    return created;
  }

  async createDisputeLetterItemV2(row: InsertDisputeLetterItemV2): Promise<DisputeLetterItemV2> {
    const [created] = await db.insert(disputeLetterItemsV2).values(row).returning();
    return created;
  }

  async getLatestAnalysisRunV2ByReportId(creditReportId: string): Promise<AnalysisRunV2 | undefined> {
    const [row] = await db.select().from(analysisRunsV2).where(eq(analysisRunsV2.creditReportId, creditReportId)).orderBy(desc(analysisRunsV2.startedAt)).limit(1);
    return row;
  }

  async getRuleFindingsV2ByRunId(runId: string): Promise<RuleFindingV2Row[]> {
    return db.select().from(ruleFindingsV2).where(eq(ruleFindingsV2.analysisRunId, runId)).orderBy(desc(ruleFindingsV2.createdAt));
  }

  async getFindingExplanationsV2ByRunId(runId: string): Promise<FindingExplanationV2[]> {
    return db.select().from(findingExplanationsV2).where(eq(findingExplanationsV2.analysisRunId, runId)).orderBy(desc(findingExplanationsV2.createdAt));
  }

}

export const storage = new DatabaseStorage();
