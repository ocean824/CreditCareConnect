import type { CanonicalCreditReport, RuleFinding, RuleSeverity, RuleFamily } from '../../models/canonicalCreditReport';

export interface RuleContext {
  report: CanonicalCreditReport;
  runId: string;
  thresholds: {
    minEntityConfidence: number;
    minRuleConfidence: number;
    autoDraftThreshold: number;
  };
}

export interface RuleDefinition<T> {
  ruleId: string;
  family: RuleFamily;
  category: string;
  severity: RuleSeverity;
  appliesTo: 'tradeline' | 'collection' | 'inquiry' | 'public_record' | 'identity' | 'cross_bureau';
  requiredFields: string[];
  evaluate: (entity: T, context: RuleContext) => RuleFinding | null;
}
