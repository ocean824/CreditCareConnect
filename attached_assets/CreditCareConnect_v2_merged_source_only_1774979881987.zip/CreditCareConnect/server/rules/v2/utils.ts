import { randomUUID } from 'crypto';
import type { CanonicalTradeline, RuleFinding } from '../../models/canonicalCreditReport';

export function buildTradelineFinding(input: {
  ruleId: string;
  category: string;
  descriptionMachine: string;
  entity: CanonicalTradeline;
  confidence: number;
  statutes: string[];
  severity?: RuleFinding['severity'];
  family?: RuleFinding['family'];
  disputeAngle?: RuleFinding['disputeAngle'];
  requestedRemedy?: RuleFinding['requestedRemedy'];
  explanationTemplateKey?: string;
}): RuleFinding {
  return {
    findingId: randomUUID(),
    ruleId: input.ruleId,
    family: input.family ?? 'CROSS_BUREAU',
    category: input.category,
    severity: input.severity ?? 'HIGH',
    entityType: 'tradeline',
    entityIds: [input.entity.entityId],
    affectedBureaus: Object.keys(input.entity.bureauViews) as RuleFinding['affectedBureaus'],
    statutes: input.statutes,
    disputeAngle: input.disputeAngle ?? 'INACCURATE',
    requestedRemedy: input.requestedRemedy ?? 'CORRECT',
    predicates: [],
    confidence: input.confidence,
    reviewStatus: input.confidence >= 0.9 ? 'auto_approved' : input.confidence >= 0.85 ? 'ai_verification' : 'human_review',
    descriptionMachine: input.descriptionMachine,
    explanationTemplateKey: input.explanationTemplateKey ?? input.ruleId,
    evidenceRefs: input.entity.normalizedCreditorName.evidence,
    details: {},
  };
}
