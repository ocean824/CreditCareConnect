import type { CanonicalTradeline } from '../../../models/canonicalCreditReport';
import type { RuleDefinition, RuleContext } from '../types';
import { buildTradelineFinding } from '../utils';

export const crossBureauBalanceMismatchRule: RuleDefinition<CanonicalTradeline> = {
  ruleId: 'CB_BALANCE_001',
  family: 'CROSS_BUREAU',
  category: 'Cross-bureau balance inconsistency',
  severity: 'HIGH',
  appliesTo: 'tradeline',
  requiredFields: ['normalizedCreditorName', 'bureauViews.*.balance'],
  evaluate(entity: CanonicalTradeline, _context: RuleContext) {
    const balances = Object.values(entity.bureauViews)
      .map((view) => view?.balance.value)
      .filter((value): value is number => typeof value === 'number');

    if (balances.length < 2) return null;
    const min = Math.min(...balances);
    const max = Math.max(...balances);
    if (max - min < 50) return null;

    return buildTradelineFinding({
      ruleId: 'CB_BALANCE_001',
      category: 'Cross-bureau balance inconsistency',
      descriptionMachine: `Balance varies materially across bureaus for ${entity.normalizedCreditorName.value ?? 'account'}.`,
      entity,
      confidence: entity.overallConfidence,
      statutes: ['15_USC_1681e_b', '15_USC_1681i'],
      requestedRemedy: 'CORRECT',
    });
  },
};
