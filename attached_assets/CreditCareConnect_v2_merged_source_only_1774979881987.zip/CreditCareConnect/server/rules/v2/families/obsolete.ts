import type { CanonicalTradeline } from '../../../models/canonicalCreditReport';
import type { RuleDefinition, RuleContext } from '../types';
import { buildTradelineFinding } from '../utils';

function yearsBetween(from: string, to: string): number {
  const a = new Date(from);
  const b = new Date(to);
  return (b.getTime() - a.getTime()) / (365.25 * 24 * 60 * 60 * 1000);
}

export const obsoleteDerogatoryRule: RuleDefinition<CanonicalTradeline> = {
  ruleId: 'OBS_001',
  family: 'OBSOLETE',
  category: 'Potential obsolete derogatory reporting',
  severity: 'CRITICAL',
  appliesTo: 'tradeline',
  requiredFields: ['bureauViews.*.dateOfFirstDelinquency', 'bureauViews.*.status'],
  evaluate(entity: CanonicalTradeline, _context: RuleContext) {
    const dofd = Object.values(entity.bureauViews).map((view) => view?.dateOfFirstDelinquency.value).find(Boolean);
    if (!dofd) return null;
    const age = yearsBetween(dofd, new Date().toISOString());
    if (age < 7.2) return null;

    return buildTradelineFinding({
      ruleId: 'OBS_001',
      category: 'Potential obsolete derogatory reporting',
      descriptionMachine: `Derogatory account may be reported beyond the permissible reporting period for ${entity.normalizedCreditorName.value ?? 'account'}.`,
      entity,
      confidence: Math.min(entity.overallConfidence, 0.92),
      statutes: ['15_USC_1681c'],
      severity: 'CRITICAL',
      disputeAngle: 'OBSOLETE',
      requestedRemedy: 'DELETE',
    });
  },
};
