import type { CanonicalCreditReport, RuleFinding } from '../../models/canonicalCreditReport';
import type { RuleContext } from './types';
import { crossBureauBalanceMismatchRule } from './families/crossBureau';
import { obsoleteDerogatoryRule } from './families/obsolete';

const TRADELINE_RULES = [crossBureauBalanceMismatchRule, obsoleteDerogatoryRule];

export function runRulesV2(report: CanonicalCreditReport): RuleFinding[] {
  const context: RuleContext = {
    report,
    runId: report.reportId,
    thresholds: {
      minEntityConfidence: 0.85,
      minRuleConfidence: 0.85,
      autoDraftThreshold: 0.9,
    },
  };

  const findings: RuleFinding[] = [];
  for (const tradeline of report.tradelines) {
    if (tradeline.reconciliationStatus === 'insufficient_evidence') continue;
    for (const rule of TRADELINE_RULES) {
      const finding = rule.evaluate(tradeline, context);
      if (finding) findings.push(finding);
    }
  }
  return findings;
}
