import type { CanonicalCreditReport, FindingExplanation, RuleFinding } from '../../models/canonicalCreditReport';

export async function explainFindings(findings: RuleFinding[], _report: CanonicalCreditReport): Promise<FindingExplanation[]> {
  // TODO: replace with OpenAI structured outputs validated against Zod.
  return findings.map((finding) => ({
    findingId: finding.findingId,
    accountLabel: finding.entityIds[0] ?? 'Account',
    humanSummary: finding.descriptionMachine,
    statutes: finding.statutes,
    disputeAngle: finding.disputeAngle,
    recommendedAction: `Request ${finding.requestedRemedy.toLowerCase().replace(/_/g, ' ')}.`,
    priority: finding.severity === 'CRITICAL' ? 5 : finding.severity === 'HIGH' ? 4 : finding.severity === 'MEDIUM' ? 3 : 2,
    explanationConfidence: finding.confidence,
  }));
}
