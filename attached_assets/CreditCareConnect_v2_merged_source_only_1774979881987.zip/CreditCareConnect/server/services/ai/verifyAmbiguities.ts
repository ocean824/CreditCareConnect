import type { CanonicalCreditReport, PageExtraction } from '../../models/canonicalCreditReport';

export async function verifyAmbiguities(report: CanonicalCreditReport, _pages: PageExtraction[]): Promise<CanonicalCreditReport> {
  // TODO: wire to OpenAI structured outputs. This stub intentionally does not invent fields.
  // It only passes through the deterministic report unchanged.
  return report;
}
