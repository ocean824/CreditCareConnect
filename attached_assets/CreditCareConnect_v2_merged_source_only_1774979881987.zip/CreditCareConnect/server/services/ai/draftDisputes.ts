import type { CanonicalCreditReport, DisputeLetterDraft, FindingExplanation, RuleFinding } from '../../models/canonicalCreditReport';
import { composeDisputeLetters } from '../letters/composeDisputeLetter';

export async function draftDisputes(input: {
  report: CanonicalCreditReport;
  findings: RuleFinding[];
  explanations: FindingExplanation[];
  round: 1 | 2 | 3;
}): Promise<DisputeLetterDraft[]> {
  // TODO: replace with OpenAI structured paragraph generation, but only from approved findings.
  return composeDisputeLetters(input.report, input.findings, input.explanations, input.round);
}
