import type { CanonicalCreditReport, EvidenceRef, FieldEvidence, RuleFinding } from '../../models/canonicalCreditReport';

export interface ConfidenceThresholds {
  fieldUsable: number;
  entityVerified: number;
  crossBureauAutoMatch: number;
  ruleFindingEmit: number;
  autoDraft: number;
  humanReview: number;
}

export const DEFAULT_THRESHOLDS: ConfidenceThresholds = {
  fieldUsable: 0.8,
  entityVerified: 0.85,
  crossBureauAutoMatch: 0.9,
  ruleFindingEmit: 0.85,
  autoDraft: 0.9,
  humanReview: 0.75,
};

export function scoreField<T>(field: FieldEvidence<T>, pageConfidence = 0.9, labelMatch = 0.9, valueFormat = 0.9, crossFieldConsistency = 0.9): number {
  const ambiguityPenalty = field.warnings.length ? 0.1 : 0;
  return Math.max(0, Math.min(1, pageConfidence * 0.4 + labelMatch * 0.25 + valueFormat * 0.2 + crossFieldConsistency * 0.15 - ambiguityPenalty));
}

export function scoreEntity(confidences: number[]): number {
  if (!confidences.length) return 0;
  return Number((confidences.reduce((s, v) => s + v, 0) / confidences.length).toFixed(4));
}

export function scoreEvidenceCoverage(evidenceRefs: EvidenceRef[]): number {
  if (!evidenceRefs.length) return 0;
  const pages = new Set(evidenceRefs.map((e) => e.sourcePage));
  return Math.min(1, 0.4 + pages.size * 0.15 + evidenceRefs.length * 0.05);
}

export function scoreReport(report: CanonicalCreditReport): number {
  const entityScores = [
    ...report.tradelines.map((t) => t.overallConfidence),
    ...report.collections.map((c) => c.overallConfidence),
    ...report.inquiries.map((i) => i.overallConfidence),
    ...report.publicRecords.map((p) => p.overallConfidence),
  ];
  return scoreEntity(entityScores.length ? entityScores : [report.overallConfidence]);
}

export function isAutoDraftEligible(finding: RuleFinding, thresholds: ConfidenceThresholds = DEFAULT_THRESHOLDS): boolean {
  return finding.reviewStatus === 'auto_approved' && finding.confidence >= thresholds.autoDraft;
}
