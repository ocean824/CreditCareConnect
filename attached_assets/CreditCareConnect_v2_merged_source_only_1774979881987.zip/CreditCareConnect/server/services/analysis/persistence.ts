import { storage } from '../../storage';
import type {
  CanonicalCollection,
  CanonicalCreditReport,
  CanonicalInquiry,
  CanonicalPublicRecord,
  CanonicalTradeline,
  DisputeLetterDraft,
  FieldEvidence,
  RuleFinding,
  FindingExplanation,
  DocumentExtractionResult,
} from '../../models/canonicalCreditReport';

export interface PersistV2AnalysisInput {
  creditReportId: string;
  userId: string;
  extraction: DocumentExtractionResult;
  canonicalReport: CanonicalCreditReport;
  findings: RuleFinding[];
  explanations: FindingExplanation[];
  drafts: DisputeLetterDraft[];
  overallConfidence: number;
  aiModel?: string;
}

export interface PersistV2AnalysisResult {
  extractionRunId: string;
  analysisRunId: string;
  disputeLetterIds: string[];
}

export async function persistV2Analysis(input: PersistV2AnalysisInput): Promise<PersistV2AnalysisResult> {
  const extractionRun = await storage.createExtractionRunV2({
    creditReportId: input.creditReportId,
    methodSummary: summarizeMethods(input.extraction.pages),
    providerGuess: input.extraction.providerGuess,
    triMerge: input.extraction.triMerge,
    bureausDetected: input.extraction.bureausDetected,
    overallConfidence: String(input.extraction.overallConfidence) as any,
    warnings: input.extraction.warnings,
  });

  for (const page of input.extraction.pages) {
    const pageRow = await storage.createDocumentPageV2({
      extractionRunId: extractionRun.id,
      pageNumber: page.pageNumber,
      method: page.method,
      text: page.text,
      charCount: page.charCount,
      textDensity: String(page.textDensity) as any,
      confidence: String(page.confidence) as any,
      layoutHints: page.layoutHints,
      warnings: page.warnings,
    });

    for (const block of page.blocks) {
      await storage.createDocumentBlockV2({
        pageId: pageRow.id,
        blockKey: block.blockId,
        text: block.text,
        labelGuess: block.labelGuess,
        rowIndex: block.rowIndex,
        columnIndex: block.columnIndex,
        bbox: block.bbox ?? null,
      });
    }
  }

  const analysisRun = await storage.createAnalysisRunV2({
    creditReportId: input.creditReportId,
    extractionRunId: extractionRun.id,
    parserVersion: 'v2-stub-merge-1',
    rulesVersion: 'v2-stub-merge-1',
    aiModel: input.aiModel || process.env.OPENAI_MODEL || 'gpt-5.1-chat-latest',
    status: 'completed',
    reviewStatus: input.findings.every((f) => f.reviewStatus === 'auto_approved') ? 'auto_approved' : 'human_review',
    overallConfidence: String(input.overallConfidence) as any,
    summary: {
      provider: input.extraction.providerGuess,
      pages: input.extraction.pages.length,
      findings: input.findings.length,
      explanations: input.explanations.length,
      drafts: input.drafts.length,
    },
  });

  await storage.createParsedReportSnapshotV2({
    analysisRunId: analysisRun.id,
    canonicalReport: input.canonicalReport as any,
    overallConfidence: String(input.overallConfidence) as any,
    warnings: input.canonicalReport.warnings,
  });

  for (const entity of input.canonicalReport.tradelines) await persistEntity(analysisRun.id, entity);
  for (const entity of input.canonicalReport.collections) await persistEntity(analysisRun.id, entity);
  for (const entity of input.canonicalReport.inquiries) await persistEntity(analysisRun.id, entity);
  for (const entity of input.canonicalReport.publicRecords) await persistEntity(analysisRun.id, entity);

  for (const finding of input.findings) {
    const findingRow = await storage.createRuleFindingV2({
      analysisRunId: analysisRun.id,
      findingId: finding.findingId,
      ruleId: finding.ruleId,
      family: finding.family,
      category: finding.category,
      severity: finding.severity,
      entityType: finding.entityType,
      entityIds: finding.entityIds as any,
      affectedBureaus: finding.affectedBureaus,
      statutes: finding.statutes,
      disputeAngle: finding.disputeAngle,
      requestedRemedy: finding.requestedRemedy,
      confidence: String(finding.confidence) as any,
      reviewStatus: finding.reviewStatus,
      descriptionMachine: finding.descriptionMachine,
      explanationTemplateKey: finding.explanationTemplateKey,
      details: finding.details as any,
    });

    for (const evidence of finding.evidenceRefs) {
      await storage.createRuleFindingEvidenceV2({
        findingRowId: findingRow.id,
        sourcePage: evidence.sourcePage,
        sourceBlockIds: evidence.sourceBlockIds as any,
        sourceLabel: evidence.sourceLabel,
        rawTextSnippet: evidence.rawTextSnippet,
        method: evidence.method,
      });
    }

    if (finding.reviewStatus !== 'auto_approved') {
      await storage.createReviewQueueV2({
        analysisRunId: analysisRun.id,
        scopeType: 'finding',
        scopeId: finding.findingId,
        reason: `Finding requires ${finding.reviewStatus}`,
        priority: finding.severity === 'CRITICAL' ? 5 : finding.severity === 'HIGH' ? 4 : 3,
        status: 'open',
        assignedTo: null as any,
        resolutionNotes: null as any,
      });
    }
  }

  for (const explanation of input.explanations) {
    await storage.createFindingExplanationV2({
      analysisRunId: analysisRun.id,
      findingId: explanation.findingId,
      accountLabel: explanation.accountLabel,
      humanSummary: explanation.humanSummary,
      statutes: explanation.statutes,
      disputeAngle: explanation.disputeAngle,
      recommendedAction: explanation.recommendedAction,
      priority: explanation.priority,
      explanationConfidence: String(explanation.explanationConfidence) as any,
      rawAiPayload: explanation as any,
    });
  }

  const disputeLetterIds: string[] = [];
  for (const draft of input.drafts) {
    const legacyLetter = await storage.createDisputeLetter({
      userId: input.userId,
      bureau: draft.bureau || draft.recipientName,
      letterType: draft.recipientType,
      round: draft.round,
      recipientType: draft.recipientType,
      recipientName: draft.recipientName,
      content: renderDraftContent(draft),
      status: 'DRAFT',
      pdfUrl: null as any,
      sentAt: null as any,
      responseDeadline: null as any,
      mailingId: null as any,
    });
    disputeLetterIds.push(legacyLetter.id);

    for (const item of draft.findingItems) {
      await storage.createDisputeLetterItemV2({
        disputeLetterId: legacyLetter.id,
        findingId: item.findingId,
        entityId: item.entityId,
        accountLabel: item.accountLabel,
        factualStatement: item.factualStatement,
        evidenceSummary: item.evidenceSummary,
        statutes: item.statutes,
        requestedAction: item.requestedAction,
        confidence: String(item.confidence) as any,
      });
    }
  }

  await storage.updateAnalysisRunV2Status(analysisRun.id, 'completed', {
    reviewStatus: input.findings.every((f) => f.reviewStatus === 'auto_approved') ? 'auto_approved' : 'human_review',
    overallConfidence: input.overallConfidence,
    summary: {
      provider: input.extraction.providerGuess,
      pages: input.extraction.pages.length,
      findings: input.findings.length,
      explanations: input.explanations.length,
      drafts: input.drafts.length,
      disputeLetterIds,
    },
    completedAt: new Date(),
  });

  return {
    extractionRunId: extractionRun.id,
    analysisRunId: analysisRun.id,
    disputeLetterIds,
  };
}

function summarizeMethods(pages: DocumentExtractionResult['pages']): string {
  const methods = [...new Set(pages.map((page) => page.method))];
  if (methods.length === 1) return methods[0];
  if (methods.includes('hybrid')) return 'hybrid';
  return methods.join(',');
}

async function persistEntity(
  analysisRunId: string,
  entity: CanonicalTradeline | CanonicalCollection | CanonicalInquiry | CanonicalPublicRecord,
): Promise<void> {
  const entityType = 'entityType' in entity ? entity.entityType : inferEntityType(entity as CanonicalInquiry | CanonicalPublicRecord);
  const normalizedName = getNormalizedName(entity);
  const matchKey = 'inferredMatchKey' in entity ? entity.inferredMatchKey : entity.entityId;
  const reconciliationStatus = 'reconciliationStatus' in entity ? entity.reconciliationStatus : 'verified';
  const matchConfidence = 'matchConfidence' in entity ? entity.matchConfidence : entity.overallConfidence;

  await storage.createReportEntityV2({
    analysisRunId,
    entityId: entity.entityId,
    entityType,
    normalizedName,
    matchKey,
    reconciliationStatus,
    matchConfidence: String(matchConfidence) as any,
    overallConfidence: String(entity.overallConfidence) as any,
    entityPayload: entity as any,
  });

  const fieldEntries = extractEvidenceFields(entity);
  for (const [fieldPath, field] of fieldEntries) {
    await storage.createEntityEvidenceV2({
      analysisRunId,
      entityId: entity.entityId,
      fieldPath,
      valueJson: field.value as any,
      normalizedValueJson: field.normalizedValue as any,
      confidence: String(field.confidence) as any,
      evidenceRefs: field.evidence as any,
      warnings: field.warnings,
    });
  }
}

function inferEntityType(entity: CanonicalInquiry | CanonicalPublicRecord): string {
  if ('recordType' in entity) return 'public_record';
  return 'inquiry';
}

function getNormalizedName(entity: any): string | null {
  return entity.normalizedCreditorName?.value || entity.normalizedCollectorName?.value || entity.inquirerName?.value || entity.courtName?.value || null;
}

function isFieldEvidence(value: unknown): value is FieldEvidence<unknown> {
  return !!value && typeof value === 'object' && 'confidence' in (value as any) && 'evidence' in (value as any) && 'warnings' in (value as any);
}

function extractEvidenceFields(entity: Record<string, any>, prefix = ''): Array<[string, FieldEvidence<unknown>]> {
  const rows: Array<[string, FieldEvidence<unknown>]> = [];
  for (const [key, value] of Object.entries(entity)) {
    const path = prefix ? `${prefix}.${key}` : key;
    if (isFieldEvidence(value)) {
      rows.push([path, value]);
      continue;
    }
    if (Array.isArray(value)) continue;
    if (value && typeof value === 'object') {
      rows.push(...extractEvidenceFields(value as Record<string, any>, path));
    }
  }
  return rows;
}

function renderDraftContent(draft: DisputeLetterDraft): string {
  return [
    draft.subject,
    '',
    ...draft.introParagraphs,
    '',
    ...draft.findingItems.map((item) => `- ${item.accountLabel}: ${item.factualStatement}\n  ${item.evidenceSummary}\n  Requested action: ${item.requestedAction}`),
    '',
    ...draft.closingParagraphs,
  ].join('\n');
}
