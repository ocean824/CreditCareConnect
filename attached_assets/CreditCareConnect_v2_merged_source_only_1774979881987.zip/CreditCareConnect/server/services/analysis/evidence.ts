import type { EvidenceRef } from '../../models/canonicalCreditReport';

export function summarizeEvidence(evidenceRefs: EvidenceRef[]): string {
  const uniquePages = [...new Set(evidenceRefs.map((ref) => ref.sourcePage))].sort((a, b) => a - b);
  const labels = [...new Set(evidenceRefs.map((ref) => ref.sourceLabel).filter(Boolean))] as string[];
  return `Evidence located on page(s) ${uniquePages.join(', ')}${labels.length ? ` under ${labels.join(', ')}` : ''}.`;
}
