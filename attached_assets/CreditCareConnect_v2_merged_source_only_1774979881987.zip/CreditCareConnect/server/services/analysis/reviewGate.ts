import type { RuleFinding, ReviewStatus } from '../../models/canonicalCreditReport';
import { DEFAULT_THRESHOLDS, type ConfidenceThresholds } from './confidence';

export function computeFindingReviewStatus(finding: RuleFinding, thresholds: ConfidenceThresholds = DEFAULT_THRESHOLDS): ReviewStatus {
  if (finding.confidence >= thresholds.autoDraft) return 'auto_approved';
  if (finding.confidence >= thresholds.ruleFindingEmit) return 'ai_verification';
  if (finding.confidence >= thresholds.humanReview) return 'human_review';
  return 'rejected';
}
