import type { CanonicalCreditReport, DisputeLetterDraft, FindingExplanation, RuleFinding, DocumentExtractionResult } from '../../models/canonicalCreditReport';
import { ingestDocument } from '../document/ingest';
import { parseIdentityIqReport } from '../parsers/identityIqParser';
import { parseSmartCreditReport } from '../parsers/smartCreditParser';
import { parseSingleBureauReport } from '../parsers/singleBureauParser';
import { reconcileCanonicalReport } from '../parsers/reconciler';
import { runRulesV2 } from '../../rules/v2/catalog';
import { verifyAmbiguities } from '../ai/verifyAmbiguities';
import { explainFindings } from '../ai/explainFindings';
import { draftDisputes } from '../ai/draftDisputes';
import { scoreReport } from './confidence';

export interface AnalyzeCreditReportInput {
  creditReportId: string;
  userId: string;
  filePath: string;
}

export interface AnalyzeCreditReportResult {
  extraction: DocumentExtractionResult;
  canonicalReport: CanonicalCreditReport;
  findings: RuleFinding[];
  explanations: FindingExplanation[];
  drafts: DisputeLetterDraft[];
  overallConfidence: number;
}

export async function analyzeCreditReportV2(input: AnalyzeCreditReportInput): Promise<AnalyzeCreditReportResult> {
  const extraction = await ingestDocument({ creditReportId: input.creditReportId, filePath: input.filePath });

  let canonicalReport: CanonicalCreditReport;
  switch (extraction.providerGuess) {
    case 'IDENTITYIQ':
      canonicalReport = await parseIdentityIqReport(extraction, input.userId);
      break;
    case 'SMARTCREDIT':
      canonicalReport = await parseSmartCreditReport(extraction, input.userId);
      break;
    default:
      canonicalReport = await parseSingleBureauReport(extraction, input.userId);
  }

  canonicalReport = reconcileCanonicalReport(canonicalReport);
  const verifiedReport = await verifyAmbiguities(canonicalReport, extraction.pages);
  const findings = runRulesV2(verifiedReport);
  const explanations = await explainFindings(findings, verifiedReport);
  const drafts = await draftDisputes({ report: verifiedReport, findings, explanations, round: 1 });

  return {
    extraction,
    canonicalReport: verifiedReport,
    findings,
    explanations,
    drafts,
    overallConfidence: scoreReport(verifiedReport),
  };
}
