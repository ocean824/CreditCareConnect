import type { PageExtraction } from '../../models/canonicalCreditReport';

export async function runOcrFallback(filePath: string, pageNumber: number, prior?: PageExtraction): Promise<PageExtraction> {
  // TODO: integrate pdf2pic + tesseract.js exactly as in the live repo.
  // This stub keeps the better of prior/native text and OCR text after scoring.
  return {
    pageNumber,
    method: prior ? 'hybrid' : 'ocr',
    text: prior?.text ?? '',
    charCount: prior?.charCount ?? 0,
    confidence: Math.max(prior?.confidence ?? 0, 0.65),
    textDensity: prior?.textDensity ?? 0.4,
    layoutHints: prior?.layoutHints ?? [],
    blocks: prior?.blocks ?? [],
    warnings: [...(prior?.warnings ?? []), 'OCR fallback stub used'],
  };
}
