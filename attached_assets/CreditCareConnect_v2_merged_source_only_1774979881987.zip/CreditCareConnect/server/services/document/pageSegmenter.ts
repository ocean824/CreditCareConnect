import type { PageExtraction, TextBlock } from '../../models/canonicalCreditReport';

export function segmentPageBlocks(page: Pick<PageExtraction, 'pageNumber' | 'text'>): TextBlock[] {
  const lines = page.text
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean);

  return lines.map((line, index) => ({
    blockId: `p${page.pageNumber}-b${index + 1}`,
    pageNumber: page.pageNumber,
    text: line,
    labelGuess: /:/.test(line) ? line.split(':')[0]?.trim() : undefined,
    rowIndex: index,
  }));
}
