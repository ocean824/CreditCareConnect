import type { BureauCode, PageExtraction, ProviderCode } from '../../models/canonicalCreditReport';

export interface ReportClassification {
  provider: ProviderCode;
  triMerge: boolean;
  bureausDetected: BureauCode[];
  warnings: string[];
}

export function classifyReport(pages: PageExtraction[]): ReportClassification {
  const text = pages.map((p) => p.text).join('\n');
  const bureaus: BureauCode[] = [];
  if (/Experian/i.test(text)) bureaus.push('EXPERIAN');
  if (/Equifax/i.test(text)) bureaus.push('EQUIFAX');
  if (/TransUnion/i.test(text)) bureaus.push('TRANSUNION');

  const provider: ProviderCode = /IdentityIQ/i.test(text)
    ? 'IDENTITYIQ'
    : /SmartCredit/i.test(text)
      ? 'SMARTCREDIT'
      : bureaus.length > 0
        ? 'BUREAU_DIRECT'
        : 'UNKNOWN';

  return {
    provider,
    triMerge: bureaus.length >= 2,
    bureausDetected: bureaus,
    warnings: provider === 'UNKNOWN' ? ['Unsupported or unknown provider layout'] : [],
  };
}
