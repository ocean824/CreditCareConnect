import pdf from 'pdf-parse';
import type { PageExtraction } from '../../models/canonicalCreditReport';

export async function extractNativeTextPages(filePath: string): Promise<PageExtraction[]> {
  // TODO: replace with true per-page extraction. pdf-parse returns aggregate text by default.
  const buffer = await import('fs/promises').then((m) => m.readFile(filePath));
  const parsed = await pdf(buffer);
  const rawPages = parsed.text.split(/\f|\n\s*Page\s+\d+\s*\n/i).filter(Boolean);

  return rawPages.map((text, idx) => {
    const charCount = text.length;
    const textDensity = Math.min(1, charCount / 3000);
    const confidence = Math.max(0.2, Math.min(0.98, textDensity));
    return {
      pageNumber: idx + 1,
      method: 'native-text' as const,
      text,
      charCount,
      confidence,
      textDensity,
      layoutHints: [],
      blocks: [],
      warnings: charCount < 80 ? ['Low native-text density'] : [],
    };
  });
}
