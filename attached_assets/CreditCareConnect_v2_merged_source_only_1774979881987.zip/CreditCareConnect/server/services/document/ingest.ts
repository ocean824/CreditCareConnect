import { randomUUID } from 'crypto';
import { documentExtractionResultSchema } from '../../schemas/creditAnalysis';
import type { DocumentExtractionResult, PageExtraction } from '../../models/canonicalCreditReport';
import { classifyReport } from './classifier';
import { extractNativeTextPages } from './nativeText';
import { runOcrFallback } from './ocrFallback';
import { segmentPageBlocks } from './pageSegmenter';

export interface IngestDocumentInput {
  creditReportId: string;
  filePath: string;
  mimeType?: string;
}

export async function ingestDocument(input: IngestDocumentInput): Promise<DocumentExtractionResult> {
  const nativePages = await extractNativeTextPages(input.filePath);
  const enhancedPages: PageExtraction[] = [];

  for (const page of nativePages) {
    const needsOcr = page.confidence < 0.8 || page.charCount < 80;
    const finalPage = needsOcr ? await runOcrFallback(input.filePath, page.pageNumber, page) : page;
    enhancedPages.push({ ...finalPage, blocks: segmentPageBlocks(finalPage), warnings: finalPage.warnings ?? [] });
  }

  const classification = classifyReport(enhancedPages);
  const result: DocumentExtractionResult = {
    extractionRunId: randomUUID(),
    creditReportId: input.creditReportId,
    providerGuess: classification.provider,
    triMerge: classification.triMerge,
    bureausDetected: classification.bureausDetected,
    pages: enhancedPages,
    overallConfidence: enhancedPages.length ? enhancedPages.reduce((s, p) => s + p.confidence, 0) / enhancedPages.length : 0,
    warnings: classification.warnings,
  };

  return documentExtractionResultSchema.parse(result);
}
