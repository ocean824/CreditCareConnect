import { randomUUID } from 'crypto';
import type { CanonicalCreditReport, DisputeLetterDraft, FindingExplanation, RuleFinding } from '../../models/canonicalCreditReport';
import { summarizeEvidence } from '../analysis/evidence';
import { groupFindingsByRecipient } from './groupFindingsByRecipient';

export function composeDisputeLetters(
  report: CanonicalCreditReport,
  findings: RuleFinding[],
  explanations: FindingExplanation[],
  round: 1 | 2 | 3,
): DisputeLetterDraft[] {
  const explanationMap = new Map(explanations.map((item) => [item.findingId, item]));

  return groupFindingsByRecipient(findings)
    .filter((group) => group.findings.length > 0)
    .map((group) => ({
      draftId: randomUUID(),
      reportId: report.reportId,
      recipientType: group.recipientType,
      recipientName: group.recipientName,
      bureau: group.bureau,
      round,
      subject: `Credit Report Dispute - Round ${round}`,
      introParagraphs: [buildIntro(round, group.recipientName)],
      findingItems: group.findings.map((finding) => ({
        findingId: finding.findingId,
        entityId: finding.entityIds[0] ?? 'unknown-entity',
        accountLabel: explanationMap.get(finding.findingId)?.accountLabel ?? (finding.entityIds[0] ?? 'Account'),
        factualStatement: explanationMap.get(finding.findingId)?.humanSummary ?? finding.descriptionMachine,
        evidenceSummary: summarizeEvidence(finding.evidenceRefs),
        statutes: finding.statutes,
        requestedAction: finding.requestedRemedy,
        confidence: finding.confidence,
      })),
      closingParagraphs: [buildClosing(round)],
      relatedFindingIds: group.findings.map((finding) => finding.findingId),
      overallConfidence: group.findings.reduce((s, f) => s + f.confidence, 0) / group.findings.length,
      reviewStatus: group.findings.every((f) => f.reviewStatus === 'auto_approved') ? 'auto_approved' : 'human_review',
    }));
}

function buildIntro(round: 1 | 2 | 3, recipientName: string): string {
  if (round === 1) return `I am disputing inaccurate and/or unverifiable information appearing on my consumer report with ${recipientName}. Please conduct a reasonable reinvestigation.`;
  if (round === 2) return `This is a follow-up dispute regarding information previously challenged with ${recipientName}. The inaccuracies remain unresolved and require correction.`;
  return `This is a final notice regarding unresolved reporting inaccuracies with ${recipientName}. Continued failure to correct or delete unsupported reporting may be treated as willful noncompliance.`;
}

function buildClosing(round: 1 | 2 | 3): string {
  if (round === 1) return 'Please provide the results of your reinvestigation and your method of verification within the required time.';
  if (round === 2) return 'Please correct or delete the disputed items promptly and provide your reinvestigation results.';
  return 'If these issues are not corrected, I may pursue complaints with regulators and other available remedies.';
}
