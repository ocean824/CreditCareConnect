import type { BureauCode, RuleFinding } from '../../models/canonicalCreditReport';

export interface RecipientGroup {
  recipientType: 'BUREAU' | 'COLLECTOR';
  recipientName: string;
  bureau?: BureauCode;
  findings: RuleFinding[];
}

export function groupFindingsByRecipient(findings: RuleFinding[]): RecipientGroup[] {
  const groups = new Map<string, RecipientGroup>();

  for (const finding of findings) {
    for (const bureau of finding.affectedBureaus) {
      const key = `bureau:${bureau}`;
      if (!groups.has(key)) {
        groups.set(key, { recipientType: 'BUREAU', recipientName: bureau, bureau, findings: [] });
      }
      groups.get(key)!.findings.push(finding);
    }
  }

  return [...groups.values()];
}
