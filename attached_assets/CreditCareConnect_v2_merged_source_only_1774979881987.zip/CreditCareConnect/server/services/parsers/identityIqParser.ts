import type { CanonicalCreditReport, DocumentExtractionResult } from '../../models/canonicalCreditReport';
import { splitSections } from './sectionSplitter';
import { canonicalizeIdentityIq } from './canonicalizer';

export async function parseIdentityIqReport(extraction: DocumentExtractionResult, userId: string): Promise<CanonicalCreditReport> {
  const sections = splitSections(extraction.pages);
  // TODO: implement deterministic IdentityIQ row parsing for bureau columns and label/value rows.
  return canonicalizeIdentityIq({ extraction, sections, userId });
}
