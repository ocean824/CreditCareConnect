import type { EvidenceRef, PaymentHistoryPoint, PaymentCode } from '../../models/canonicalCreditReport';

const VALID_CODES = new Set<PaymentCode>(['OK', '30', '60', '90', '120', '150', 'CO', 'COL', 'CLS', 'UNK']);

export function parsePaymentHistory(rawCodes: Array<{ month: string; code: string; evidence: EvidenceRef[] }>): PaymentHistoryPoint[] {
  return rawCodes.map((row) => ({
    month: row.month,
    code: VALID_CODES.has(row.code as PaymentCode) ? (row.code as PaymentCode) : 'UNK',
    confidence: VALID_CODES.has(row.code as PaymentCode) ? 0.95 : 0.4,
    evidence: row.evidence,
  }));
}
