import type { PageExtraction } from '../../models/canonicalCreditReport';

export type SectionName = 'consumer' | 'account_history' | 'collections' | 'public_records' | 'inquiries' | 'creditor_contacts' | 'unknown';

export interface SectionBlock {
  section: SectionName;
  pageNumber: number;
  blockIds: string[];
  text: string[];
}

export function splitSections(pages: PageExtraction[]): SectionBlock[] {
  const sections: SectionBlock[] = [];

  for (const page of pages) {
    let currentSection: SectionName = 'unknown';
    let current: SectionBlock = { section: currentSection, pageNumber: page.pageNumber, blockIds: [], text: [] };

    for (const block of page.blocks) {
      const marker = block.text.toLowerCase();
      if (marker.includes('account history')) currentSection = 'account_history';
      else if (marker.includes('collection')) currentSection = 'collections';
      else if (marker.includes('public information') || marker.includes('public record')) currentSection = 'public_records';
      else if (marker.includes('inquiries')) currentSection = 'inquiries';
      else if (marker.includes('creditor contacts')) currentSection = 'creditor_contacts';
      else if (marker.includes('consumer') || marker.includes('personal information')) currentSection = 'consumer';

      if (current.section !== currentSection) {
        if (current.blockIds.length) sections.push(current);
        current = { section: currentSection, pageNumber: page.pageNumber, blockIds: [], text: [] };
      }

      current.blockIds.push(block.blockId);
      current.text.push(block.text);
    }

    if (current.blockIds.length) sections.push(current);
  }

  return sections;
}
