import type { CanonicalCollection, CanonicalCreditReport, CanonicalTradeline, ReconciliationStatus } from '../../models/canonicalCreditReport';

export function reconcileCanonicalReport(report: CanonicalCreditReport): CanonicalCreditReport {
  return {
    ...report,
    tradelines: report.tradelines.map(reconcileTradeline),
    collections: report.collections.map(reconcileCollection),
  };
}

function reconcileTradeline(item: CanonicalTradeline): CanonicalTradeline {
  const bureauCount = Object.keys(item.bureauViews).length;
  const status: ReconciliationStatus = bureauCount >= 2 && item.matchConfidence >= 0.9 ? 'verified' : item.matchConfidence >= 0.75 ? 'ambiguous' : 'insufficient_evidence';
  return { ...item, reconciliationStatus: status };
}

function reconcileCollection(item: CanonicalCollection): CanonicalCollection {
  const bureauCount = Object.keys(item.bureauViews).length;
  const status: ReconciliationStatus = bureauCount >= 1 && item.matchConfidence >= 0.85 ? 'verified' : item.matchConfidence >= 0.7 ? 'ambiguous' : 'insufficient_evidence';
  return { ...item, reconciliationStatus: status };
}
