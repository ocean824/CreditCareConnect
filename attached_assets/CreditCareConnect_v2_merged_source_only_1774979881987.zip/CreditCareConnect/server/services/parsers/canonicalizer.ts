import type { CanonicalCreditReport, DocumentExtractionResult, FieldEvidence } from '../../models/canonicalCreditReport';

interface CanonicalizeInput {
  extraction: DocumentExtractionResult;
  userId: string;
  sections?: Array<{ section: string; pageNumber: number; blockIds: string[]; text: string[] }>;
}

function emptyField<T>(value: T | null = null): FieldEvidence<T> {
  return { value, normalizedValue: value, confidence: value == null ? 0 : 0.5, evidence: [], warnings: [] };
}

export function canonicalizeIdentityIq(input: CanonicalizeInput): CanonicalCreditReport {
  return baseReport(input);
}

export function canonicalizeSmartCredit(input: CanonicalizeInput): CanonicalCreditReport {
  return baseReport(input);
}

export function canonicalizeSingleBureau(input: CanonicalizeInput): CanonicalCreditReport {
  return baseReport(input);
}

function baseReport(input: CanonicalizeInput): CanonicalCreditReport {
  return {
    reportId: input.extraction.creditReportId,
    userId: input.userId,
    provider: input.extraction.providerGuess,
    reportDate: emptyField<string>(null),
    bureausIncluded: input.extraction.bureausDetected,
    consumer: {
      fullName: emptyField<string>(null),
      ssnLast4: emptyField<string>(null),
      dob: emptyField<string>(null),
      addresses: emptyField([]),
      phones: emptyField([]),
      employers: emptyField([]),
    },
    tradelines: [],
    collections: [],
    inquiries: [],
    publicRecords: [],
    overallConfidence: input.extraction.overallConfidence,
    warnings: input.extraction.warnings,
  };
}
