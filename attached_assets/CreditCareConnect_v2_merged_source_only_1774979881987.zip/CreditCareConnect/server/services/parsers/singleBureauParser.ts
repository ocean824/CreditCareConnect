import type { CanonicalCreditReport, DocumentExtractionResult } from '../../models/canonicalCreditReport';
import { canonicalizeSingleBureau } from './canonicalizer';

export async function parseSingleBureauReport(extraction: DocumentExtractionResult, userId: string): Promise<CanonicalCreditReport> {
  // TODO: implement bureau-direct layout parsing.
  return canonicalizeSingleBureau({ extraction, userId });
}
