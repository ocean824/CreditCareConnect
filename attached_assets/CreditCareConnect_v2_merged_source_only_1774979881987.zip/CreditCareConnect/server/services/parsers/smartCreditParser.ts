import type { CanonicalCreditReport, DocumentExtractionResult } from '../../models/canonicalCreditReport';
import { canonicalizeSmartCredit } from './canonicalizer';

export async function parseSmartCreditReport(extraction: DocumentExtractionResult, userId: string): Promise<CanonicalCreditReport> {
  // TODO: build provider-specific deterministic parser for SmartCredit layout.
  return canonicalizeSmartCredit({ extraction, userId });
}
