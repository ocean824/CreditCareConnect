export type BureauCode = 'EXPERIAN' | 'EQUIFAX' | 'TRANSUNION';
export type ProviderCode = 'IDENTITYIQ' | 'SMARTCREDIT' | 'BUREAU_DIRECT' | 'UNKNOWN';
export type ExtractionMethod = 'native-text' | 'ocr' | 'hybrid';
export type ReconciliationStatus = 'verified' | 'ambiguous' | 'insufficient_evidence';
export type ReviewStatus = 'auto_approved' | 'ai_verification' | 'human_review' | 'rejected';

export interface TextBlock {
  blockId: string;
  pageNumber: number;
  text: string;
  labelGuess?: string;
  rowIndex?: number;
  columnIndex?: number;
  bbox?: { x: number; y: number; w: number; h: number };
}

export interface PageExtraction {
  pageNumber: number;
  method: ExtractionMethod;
  text: string;
  charCount: number;
  confidence: number;
  textDensity: number;
  layoutHints: string[];
  blocks: TextBlock[];
  warnings: string[];
}

export interface DocumentExtractionResult {
  extractionRunId: string;
  creditReportId: string;
  providerGuess: ProviderCode;
  triMerge: boolean;
  bureausDetected: BureauCode[];
  pages: PageExtraction[];
  overallConfidence: number;
  warnings: string[];
}

export interface EvidenceRef {
  sourcePage: number;
  sourceBlockIds: string[];
  sourceLabel?: string;
  rawTextSnippet: string;
  method: 'layout-rule' | 'regex' | 'native-text' | 'ocr' | 'ai-verified' | 'derived';
}

export interface FieldEvidence<T> {
  value: T | null;
  normalizedValue?: T | null;
  confidence: number;
  evidence: EvidenceRef[];
  warnings: string[];
}

export type PaymentCode = 'OK' | '30' | '60' | '90' | '120' | '150' | 'CO' | 'COL' | 'CLS' | 'UNK';

export interface PaymentHistoryPoint {
  month: string;
  code: PaymentCode;
  confidence: number;
  evidence: EvidenceRef[];
}

export type CanonicalAccountType =
  | 'MORTGAGE'
  | 'AUTO'
  | 'CREDIT_CARD'
  | 'PERSONAL_LOAN'
  | 'HELOC'
  | 'STUDENT_LOAN'
  | 'COLLECTION'
  | 'PUBLIC_RECORD'
  | 'OTHER';

export type CanonicalStatus =
  | 'OPEN'
  | 'CLOSED'
  | 'CURRENT'
  | 'PAID'
  | 'LATE_30'
  | 'LATE_60'
  | 'LATE_90'
  | 'LATE_120'
  | 'LATE_150_PLUS'
  | 'COLLECTION'
  | 'CHARGE_OFF'
  | 'FORECLOSURE'
  | 'REPOSSESSION'
  | 'SETTLED'
  | 'UNKNOWN';

export interface CanonicalConsumerIdentity {
  fullName: FieldEvidence<string>;
  ssnLast4: FieldEvidence<string>;
  dob: FieldEvidence<string>;
  addresses: FieldEvidence<Array<{
    line1?: string;
    line2?: string;
    city?: string;
    state?: string;
    postalCode?: string;
  }>>;
  phones: FieldEvidence<string[]>;
  employers: FieldEvidence<string[]>;
}

export interface BureauTradelineView {
  bureau: BureauCode;
  status: FieldEvidence<CanonicalStatus>;
  balance: FieldEvidence<number>;
  pastDue: FieldEvidence<number>;
  openedDate: FieldEvidence<string>;
  closedDate: FieldEvidence<string>;
  lastPaymentDate: FieldEvidence<string>;
  lastReportedDate: FieldEvidence<string>;
  dateOfFirstDelinquency: FieldEvidence<string>;
  accountNumberMasked: FieldEvidence<string>;
  paymentHistory: PaymentHistoryPoint[];
  remarks: FieldEvidence<string[]>;
}

export interface CanonicalTradeline {
  entityId: string;
  entityType: 'tradeline';
  normalizedCreditorName: FieldEvidence<string>;
  originalCreditorName?: FieldEvidence<string>;
  accountType: FieldEvidence<CanonicalAccountType>;
  bureauViews: Partial<Record<BureauCode, BureauTradelineView>>;
  inferredMatchKey: string;
  reconciliationStatus: ReconciliationStatus;
  matchConfidence: number;
  overallConfidence: number;
}

export interface CanonicalCollection {
  entityId: string;
  entityType: 'collection';
  normalizedCollectorName: FieldEvidence<string>;
  originalCreditorName?: FieldEvidence<string>;
  bureauViews: Partial<Record<BureauCode, BureauTradelineView>>;
  inferredMatchKey: string;
  reconciliationStatus: ReconciliationStatus;
  matchConfidence: number;
  overallConfidence: number;
}

export interface CanonicalInquiry {
  entityId: string;
  bureau: BureauCode;
  inquirerName: FieldEvidence<string>;
  inquiryDate: FieldEvidence<string>;
  inquiryType: FieldEvidence<'HARD' | 'SOFT' | 'UNKNOWN'>;
  overallConfidence: number;
}

export interface CanonicalPublicRecord {
  entityId: string;
  recordType: FieldEvidence<'BANKRUPTCY' | 'TAX_LIEN' | 'JUDGMENT' | 'OTHER'>;
  courtName: FieldEvidence<string>;
  docketNumber: FieldEvidence<string>;
  filedDate: FieldEvidence<string>;
  resolvedDate: FieldEvidence<string>;
  status: FieldEvidence<string>;
  bureaus: BureauCode[];
  overallConfidence: number;
}

export interface CanonicalCreditReport {
  reportId: string;
  userId: string;
  provider: ProviderCode;
  reportDate: FieldEvidence<string>;
  bureausIncluded: BureauCode[];
  consumer: CanonicalConsumerIdentity;
  tradelines: CanonicalTradeline[];
  collections: CanonicalCollection[];
  inquiries: CanonicalInquiry[];
  publicRecords: CanonicalPublicRecord[];
  overallConfidence: number;
  warnings: string[];
}

export type RuleFamily =
  | 'IDENTITY'
  | 'BALANCE'
  | 'STATUS'
  | 'TIMELINE'
  | 'COLLECTION'
  | 'OBSOLETE'
  | 'METRO2'
  | 'CROSS_BUREAU'
  | 'HARDSHIP';

export type RuleSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type DisputeAngle = 'INACCURATE' | 'UNVERIFIABLE' | 'OBSOLETE' | 'MISLEADING' | 'HARDSHIP_MISREPORTING';
export type RequestedRemedy = 'DELETE' | 'CORRECT' | 'VERIFY' | 'SUPPRESS' | 'CEASE_COLLECTION' | 'PROVIDE_METHOD_OF_VERIFICATION';

export interface PredicateResult {
  code: string;
  passed: boolean;
  message: string;
  evidenceRefs: EvidenceRef[];
}

export interface RuleFinding {
  findingId: string;
  ruleId: string;
  family: RuleFamily;
  category: string;
  severity: RuleSeverity;
  entityType: 'tradeline' | 'collection' | 'inquiry' | 'public_record' | 'identity' | 'cross_bureau';
  entityIds: string[];
  affectedBureaus: BureauCode[];
  statutes: string[];
  disputeAngle: DisputeAngle;
  requestedRemedy: RequestedRemedy;
  predicates: PredicateResult[];
  confidence: number;
  reviewStatus: ReviewStatus;
  descriptionMachine: string;
  explanationTemplateKey: string;
  evidenceRefs: EvidenceRef[];
  details: Record<string, unknown>;
}

export interface FindingExplanation {
  findingId: string;
  accountLabel: string;
  humanSummary: string;
  statutes: string[];
  disputeAngle: DisputeAngle;
  recommendedAction: string;
  priority: 1 | 2 | 3 | 4 | 5;
  explanationConfidence: number;
}

export type RecipientType = 'BUREAU' | 'COLLECTOR';

export interface LetterFindingItem {
  findingId: string;
  entityId: string;
  accountLabel: string;
  factualStatement: string;
  evidenceSummary: string;
  statutes: string[];
  requestedAction: string;
  confidence: number;
}

export interface DisputeLetterDraft {
  draftId: string;
  reportId: string;
  recipientType: RecipientType;
  recipientName: string;
  bureau?: BureauCode;
  collectorName?: string;
  round: 1 | 2 | 3;
  subject: string;
  introParagraphs: string[];
  findingItems: LetterFindingItem[];
  closingParagraphs: string[];
  relatedFindingIds: string[];
  overallConfidence: number;
  reviewStatus: ReviewStatus;
}
