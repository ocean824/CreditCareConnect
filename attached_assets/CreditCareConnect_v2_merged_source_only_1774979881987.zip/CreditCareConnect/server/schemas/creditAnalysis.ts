import { z } from 'zod';

export const bureauCodeSchema = z.enum(['EXPERIAN', 'EQUIFAX', 'TRANSUNION']);
export const providerCodeSchema = z.enum(['IDENTITYIQ', 'SMARTCREDIT', 'BUREAU_DIRECT', 'UNKNOWN']);
export const extractionMethodSchema = z.enum(['native-text', 'ocr', 'hybrid']);
export const reconciliationStatusSchema = z.enum(['verified', 'ambiguous', 'insufficient_evidence']);
export const reviewStatusSchema = z.enum(['auto_approved', 'ai_verification', 'human_review', 'rejected']);

export const bboxSchema = z.object({ x: z.number(), y: z.number(), w: z.number(), h: z.number() });

export const evidenceRefSchema = z.object({
  sourcePage: z.number().int().nonnegative(),
  sourceBlockIds: z.array(z.string()).default([]),
  sourceLabel: z.string().optional(),
  rawTextSnippet: z.string(),
  method: z.enum(['layout-rule', 'regex', 'native-text', 'ocr', 'ai-verified', 'derived']),
});

export const fieldEvidenceSchema = <T extends z.ZodTypeAny>(inner: T) =>
  z.object({
    value: inner.nullable(),
    normalizedValue: inner.nullable().optional(),
    confidence: z.number().min(0).max(1),
    evidence: z.array(evidenceRefSchema).default([]),
    warnings: z.array(z.string()).default([]),
  });

export const textBlockSchema = z.object({
  blockId: z.string(),
  pageNumber: z.number().int().positive(),
  text: z.string(),
  labelGuess: z.string().optional(),
  rowIndex: z.number().int().optional(),
  columnIndex: z.number().int().optional(),
  bbox: bboxSchema.optional(),
});

export const pageExtractionSchema = z.object({
  pageNumber: z.number().int().positive(),
  method: extractionMethodSchema,
  text: z.string(),
  charCount: z.number().int().nonnegative(),
  confidence: z.number().min(0).max(1),
  textDensity: z.number().min(0),
  layoutHints: z.array(z.string()).default([]),
  blocks: z.array(textBlockSchema).default([]),
  warnings: z.array(z.string()).default([]),
});

export const documentExtractionResultSchema = z.object({
  extractionRunId: z.string(),
  creditReportId: z.string(),
  providerGuess: providerCodeSchema,
  triMerge: z.boolean(),
  bureausDetected: z.array(bureauCodeSchema),
  pages: z.array(pageExtractionSchema),
  overallConfidence: z.number().min(0).max(1),
  warnings: z.array(z.string()).default([]),
});

export const paymentCodeSchema = z.enum(['OK', '30', '60', '90', '120', '150', 'CO', 'COL', 'CLS', 'UNK']);
export const paymentHistoryPointSchema = z.object({
  month: z.string().regex(/^\d{4}-\d{2}$/),
  code: paymentCodeSchema,
  confidence: z.number().min(0).max(1),
  evidence: z.array(evidenceRefSchema).default([]),
});

export const canonicalAccountTypeSchema = z.enum([
  'MORTGAGE',
  'AUTO',
  'CREDIT_CARD',
  'PERSONAL_LOAN',
  'HELOC',
  'STUDENT_LOAN',
  'COLLECTION',
  'PUBLIC_RECORD',
  'OTHER',
]);

export const canonicalStatusSchema = z.enum([
  'OPEN',
  'CLOSED',
  'CURRENT',
  'PAID',
  'LATE_30',
  'LATE_60',
  'LATE_90',
  'LATE_120',
  'LATE_150_PLUS',
  'COLLECTION',
  'CHARGE_OFF',
  'FORECLOSURE',
  'REPOSSESSION',
  'SETTLED',
  'UNKNOWN',
]);

export const addressSchema = z.object({
  line1: z.string().optional(),
  line2: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  postalCode: z.string().optional(),
});

export const canonicalConsumerIdentitySchema = z.object({
  fullName: fieldEvidenceSchema(z.string()),
  ssnLast4: fieldEvidenceSchema(z.string()),
  dob: fieldEvidenceSchema(z.string()),
  addresses: fieldEvidenceSchema(z.array(addressSchema)),
  phones: fieldEvidenceSchema(z.array(z.string())),
  employers: fieldEvidenceSchema(z.array(z.string())),
});

export const bureauTradelineViewSchema = z.object({
  bureau: bureauCodeSchema,
  status: fieldEvidenceSchema(canonicalStatusSchema),
  balance: fieldEvidenceSchema(z.number()),
  pastDue: fieldEvidenceSchema(z.number()),
  openedDate: fieldEvidenceSchema(z.string()),
  closedDate: fieldEvidenceSchema(z.string()),
  lastPaymentDate: fieldEvidenceSchema(z.string()),
  lastReportedDate: fieldEvidenceSchema(z.string()),
  dateOfFirstDelinquency: fieldEvidenceSchema(z.string()),
  accountNumberMasked: fieldEvidenceSchema(z.string()),
  paymentHistory: z.array(paymentHistoryPointSchema).default([]),
  remarks: fieldEvidenceSchema(z.array(z.string())),
});

export const canonicalTradelineSchema = z.object({
  entityId: z.string(),
  entityType: z.literal('tradeline'),
  normalizedCreditorName: fieldEvidenceSchema(z.string()),
  originalCreditorName: fieldEvidenceSchema(z.string()).optional(),
  accountType: fieldEvidenceSchema(canonicalAccountTypeSchema),
  bureauViews: z.record(bureauCodeSchema, bureauTradelineViewSchema).partial(),
  inferredMatchKey: z.string(),
  reconciliationStatus: reconciliationStatusSchema,
  matchConfidence: z.number().min(0).max(1),
  overallConfidence: z.number().min(0).max(1),
});

export const canonicalCollectionSchema = z.object({
  entityId: z.string(),
  entityType: z.literal('collection'),
  normalizedCollectorName: fieldEvidenceSchema(z.string()),
  originalCreditorName: fieldEvidenceSchema(z.string()).optional(),
  bureauViews: z.record(bureauCodeSchema, bureauTradelineViewSchema).partial(),
  inferredMatchKey: z.string(),
  reconciliationStatus: reconciliationStatusSchema,
  matchConfidence: z.number().min(0).max(1),
  overallConfidence: z.number().min(0).max(1),
});

export const canonicalInquirySchema = z.object({
  entityId: z.string(),
  bureau: bureauCodeSchema,
  inquirerName: fieldEvidenceSchema(z.string()),
  inquiryDate: fieldEvidenceSchema(z.string()),
  inquiryType: fieldEvidenceSchema(z.enum(['HARD', 'SOFT', 'UNKNOWN'])),
  overallConfidence: z.number().min(0).max(1),
});

export const canonicalPublicRecordSchema = z.object({
  entityId: z.string(),
  recordType: fieldEvidenceSchema(z.enum(['BANKRUPTCY', 'TAX_LIEN', 'JUDGMENT', 'OTHER'])),
  courtName: fieldEvidenceSchema(z.string()),
  docketNumber: fieldEvidenceSchema(z.string()),
  filedDate: fieldEvidenceSchema(z.string()),
  resolvedDate: fieldEvidenceSchema(z.string()),
  status: fieldEvidenceSchema(z.string()),
  bureaus: z.array(bureauCodeSchema),
  overallConfidence: z.number().min(0).max(1),
});

export const canonicalCreditReportSchema = z.object({
  reportId: z.string(),
  userId: z.string(),
  provider: providerCodeSchema,
  reportDate: fieldEvidenceSchema(z.string()),
  bureausIncluded: z.array(bureauCodeSchema),
  consumer: canonicalConsumerIdentitySchema,
  tradelines: z.array(canonicalTradelineSchema),
  collections: z.array(canonicalCollectionSchema),
  inquiries: z.array(canonicalInquirySchema),
  publicRecords: z.array(canonicalPublicRecordSchema),
  overallConfidence: z.number().min(0).max(1),
  warnings: z.array(z.string()).default([]),
});

export const ruleFamilySchema = z.enum(['IDENTITY', 'BALANCE', 'STATUS', 'TIMELINE', 'COLLECTION', 'OBSOLETE', 'METRO2', 'CROSS_BUREAU', 'HARDSHIP']);
export const ruleSeveritySchema = z.enum(['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']);
export const disputeAngleSchema = z.enum(['INACCURATE', 'UNVERIFIABLE', 'OBSOLETE', 'MISLEADING', 'HARDSHIP_MISREPORTING']);
export const requestedRemedySchema = z.enum(['DELETE', 'CORRECT', 'VERIFY', 'SUPPRESS', 'CEASE_COLLECTION', 'PROVIDE_METHOD_OF_VERIFICATION']);

export const predicateResultSchema = z.object({
  code: z.string(),
  passed: z.boolean(),
  message: z.string(),
  evidenceRefs: z.array(evidenceRefSchema).default([]),
});

export const ruleFindingSchema = z.object({
  findingId: z.string(),
  ruleId: z.string(),
  family: ruleFamilySchema,
  category: z.string(),
  severity: ruleSeveritySchema,
  entityType: z.enum(['tradeline', 'collection', 'inquiry', 'public_record', 'identity', 'cross_bureau']),
  entityIds: z.array(z.string()),
  affectedBureaus: z.array(bureauCodeSchema).default([]),
  statutes: z.array(z.string()).default([]),
  disputeAngle: disputeAngleSchema,
  requestedRemedy: requestedRemedySchema,
  predicates: z.array(predicateResultSchema).default([]),
  confidence: z.number().min(0).max(1),
  reviewStatus: reviewStatusSchema,
  descriptionMachine: z.string(),
  explanationTemplateKey: z.string(),
  evidenceRefs: z.array(evidenceRefSchema).default([]),
  details: z.record(z.string(), z.unknown()).default({}),
});

export const ambiguityTaskSchema = z.object({
  taskId: z.string(),
  reportId: z.string(),
  entityId: z.string(),
  fieldPath: z.string(),
  currentValue: z.unknown(),
  candidateValues: z.array(z.unknown()).default([]),
  evidenceRefs: z.array(evidenceRefSchema).default([]),
});

export const ambiguityResolutionSchema = z.object({
  taskId: z.string(),
  chosenValue: z.unknown().nullable(),
  confidence: z.number().min(0).max(1),
  rationale: z.string(),
  additionalEvidenceRefs: z.array(evidenceRefSchema).default([]),
  resolved: z.boolean(),
});

export const findingExplanationSchema = z.object({
  findingId: z.string(),
  accountLabel: z.string(),
  humanSummary: z.string(),
  statutes: z.array(z.string()).default([]),
  disputeAngle: disputeAngleSchema,
  recommendedAction: z.string(),
  priority: z.union([z.literal(1), z.literal(2), z.literal(3), z.literal(4), z.literal(5)]),
  explanationConfidence: z.number().min(0).max(1),
});

export const letterFindingItemSchema = z.object({
  findingId: z.string(),
  entityId: z.string(),
  accountLabel: z.string(),
  factualStatement: z.string(),
  evidenceSummary: z.string(),
  statutes: z.array(z.string()).default([]),
  requestedAction: z.string(),
  confidence: z.number().min(0).max(1),
});

export const disputeLetterDraftSchema = z.object({
  draftId: z.string(),
  reportId: z.string(),
  recipientType: z.enum(['BUREAU', 'COLLECTOR']),
  recipientName: z.string(),
  bureau: bureauCodeSchema.optional(),
  collectorName: z.string().optional(),
  round: z.union([z.literal(1), z.literal(2), z.literal(3)]),
  subject: z.string(),
  introParagraphs: z.array(z.string()).default([]),
  findingItems: z.array(letterFindingItemSchema).default([]),
  closingParagraphs: z.array(z.string()).default([]),
  relatedFindingIds: z.array(z.string()).default([]),
  overallConfidence: z.number().min(0).max(1),
  reviewStatus: reviewStatusSchema,
});

export type CanonicalCreditReportSchema = z.infer<typeof canonicalCreditReportSchema>;
export type RuleFindingSchema = z.infer<typeof ruleFindingSchema>;
export type DisputeLetterDraftSchema = z.infer<typeof disputeLetterDraftSchema>;
