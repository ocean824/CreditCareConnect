import { sql } from 'drizzle-orm';
import {
  boolean,
  index,
  integer,
  jsonb,
  numeric,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from 'drizzle-orm/pg-core';
import { createInsertSchema } from 'drizzle-zod';
import { z } from 'zod';
import { creditReports, disputeLetters, users } from './schema';

export const extractionRunsV2 = pgTable(
  'extraction_runs_v2',
  {
    id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
    creditReportId: varchar('credit_report_id')
      .notNull()
      .references(() => creditReports.id, { onDelete: 'cascade' }),
    methodSummary: varchar('method_summary').notNull(), // native-text | ocr | hybrid
    providerGuess: varchar('provider_guess').notNull().default('UNKNOWN'),
    triMerge: boolean('tri_merge').notNull().default(false),
    bureausDetected: text('bureaus_detected').array().notNull().default(sql`ARRAY[]::text[]`),
    overallConfidence: numeric('overall_confidence', { precision: 5, scale: 4 }).notNull().default('0'),
    warnings: jsonb('warnings').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('idx_extraction_runs_v2_credit_report').on(table.creditReportId),
    index('idx_extraction_runs_v2_created_at').on(table.createdAt),
  ],
);

export const documentPagesV2 = pgTable(
  'document_pages_v2',
  {
    id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
    extractionRunId: varchar('extraction_run_id')
      .notNull()
      .references(() => extractionRunsV2.id, { onDelete: 'cascade' }),
    pageNumber: integer('page_number').notNull(),
    method: varchar('method').notNull(), // native-text | ocr | hybrid
    text: text('text').notNull(),
    charCount: integer('char_count').notNull().default(0),
    textDensity: numeric('text_density', { precision: 10, scale: 4 }).notNull().default('0'),
    confidence: numeric('confidence', { precision: 5, scale: 4 }).notNull().default('0'),
    layoutHints: text('layout_hints').array().notNull().default(sql`ARRAY[]::text[]`),
    warnings: jsonb('warnings').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('idx_document_pages_v2_run').on(table.extractionRunId),
    uniqueIndex('uq_document_pages_v2_run_page').on(table.extractionRunId, table.pageNumber),
  ],
);

export const documentBlocksV2 = pgTable(
  'document_blocks_v2',
  {
    id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
    pageId: varchar('page_id')
      .notNull()
      .references(() => documentPagesV2.id, { onDelete: 'cascade' }),
    blockKey: varchar('block_key').notNull(),
    text: text('text').notNull(),
    labelGuess: varchar('label_guess'),
    rowIndex: integer('row_index'),
    columnIndex: integer('column_index'),
    bbox: jsonb('bbox').$type<{ x: number; y: number; w: number; h: number } | null>(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('idx_document_blocks_v2_page').on(table.pageId),
    uniqueIndex('uq_document_blocks_v2_page_key').on(table.pageId, table.blockKey),
  ],
);

export const analysisRunsV2 = pgTable(
  'analysis_runs_v2',
  {
    id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
    creditReportId: varchar('credit_report_id')
      .notNull()
      .references(() => creditReports.id, { onDelete: 'cascade' }),
    extractionRunId: varchar('extraction_run_id')
      .notNull()
      .references(() => extractionRunsV2.id, { onDelete: 'cascade' }),
    parserVersion: varchar('parser_version').notNull(),
    rulesVersion: varchar('rules_version').notNull(),
    aiModel: varchar('ai_model'),
    status: varchar('status').notNull().default('queued'), // queued | parsing | rules | review | completed | failed
    reviewStatus: varchar('review_status').notNull().default('human_review'),
    overallConfidence: numeric('overall_confidence', { precision: 5, scale: 4 }).notNull().default('0'),
    summary: jsonb('summary').$type<Record<string, unknown> | null>(),
    startedAt: timestamp('started_at').defaultNow().notNull(),
    completedAt: timestamp('completed_at'),
  },
  (table) => [
    index('idx_analysis_runs_v2_credit_report').on(table.creditReportId),
    index('idx_analysis_runs_v2_status').on(table.status),
  ],
);

export const parsedReportSnapshotsV2 = pgTable(
  'parsed_report_snapshots_v2',
  {
    id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
    analysisRunId: varchar('analysis_run_id')
      .notNull()
      .references(() => analysisRunsV2.id, { onDelete: 'cascade' }),
    canonicalReport: jsonb('canonical_report').notNull(),
    overallConfidence: numeric('overall_confidence', { precision: 5, scale: 4 }).notNull().default('0'),
    warnings: jsonb('warnings').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('idx_parsed_report_snapshots_v2_run').on(table.analysisRunId)],
);

export const reportEntitiesV2 = pgTable(
  'report_entities_v2',
  {
    id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
    analysisRunId: varchar('analysis_run_id')
      .notNull()
      .references(() => analysisRunsV2.id, { onDelete: 'cascade' }),
    entityId: varchar('entity_id').notNull(),
    entityType: varchar('entity_type').notNull(), // tradeline | collection | inquiry | public_record | identity
    normalizedName: varchar('normalized_name'),
    matchKey: varchar('match_key'),
    reconciliationStatus: varchar('reconciliation_status').notNull().default('ambiguous'),
    matchConfidence: numeric('match_confidence', { precision: 5, scale: 4 }).notNull().default('0'),
    overallConfidence: numeric('overall_confidence', { precision: 5, scale: 4 }).notNull().default('0'),
    entityPayload: jsonb('entity_payload').notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('idx_report_entities_v2_run').on(table.analysisRunId),
    uniqueIndex('uq_report_entities_v2_run_entity').on(table.analysisRunId, table.entityId),
  ],
);

export const entityEvidenceV2 = pgTable(
  'entity_evidence_v2',
  {
    id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
    analysisRunId: varchar('analysis_run_id')
      .notNull()
      .references(() => analysisRunsV2.id, { onDelete: 'cascade' }),
    entityId: varchar('entity_id').notNull(),
    fieldPath: varchar('field_path').notNull(),
    valueJson: jsonb('value_json'),
    normalizedValueJson: jsonb('normalized_value_json'),
    confidence: numeric('confidence', { precision: 5, scale: 4 }).notNull().default('0'),
    evidenceRefs: jsonb('evidence_refs').notNull(),
    warnings: jsonb('warnings').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('idx_entity_evidence_v2_run').on(table.analysisRunId),
    index('idx_entity_evidence_v2_entity').on(table.entityId),
  ],
);

export const aiVerificationTasksV2 = pgTable(
  'ai_verification_tasks_v2',
  {
    id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
    analysisRunId: varchar('analysis_run_id')
      .notNull()
      .references(() => analysisRunsV2.id, { onDelete: 'cascade' }),
    entityId: varchar('entity_id').notNull(),
    fieldPath: varchar('field_path').notNull(),
    currentValueJson: jsonb('current_value_json'),
    candidateValuesJson: jsonb('candidate_values_json').notNull(),
    status: varchar('status').notNull().default('queued'), // queued | completed | human_review | rejected
    resolutionJson: jsonb('resolution_json'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    resolvedAt: timestamp('resolved_at'),
  },
  (table) => [index('idx_ai_verification_tasks_v2_run').on(table.analysisRunId)],
);

export const ruleFindingsV2 = pgTable(
  'rule_findings_v2',
  {
    id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
    analysisRunId: varchar('analysis_run_id')
      .notNull()
      .references(() => analysisRunsV2.id, { onDelete: 'cascade' }),
    findingId: varchar('finding_id').notNull(),
    ruleId: varchar('rule_id').notNull(),
    family: varchar('family').notNull(),
    category: varchar('category').notNull(),
    severity: varchar('severity').notNull(),
    entityType: varchar('entity_type').notNull(),
    entityIds: jsonb('entity_ids').notNull(),
    affectedBureaus: text('affected_bureaus').array().notNull().default(sql`ARRAY[]::text[]`),
    statutes: text('statutes').array().notNull().default(sql`ARRAY[]::text[]`),
    disputeAngle: varchar('dispute_angle').notNull(),
    requestedRemedy: varchar('requested_remedy').notNull(),
    confidence: numeric('confidence', { precision: 5, scale: 4 }).notNull().default('0'),
    reviewStatus: varchar('review_status').notNull().default('human_review'),
    descriptionMachine: text('description_machine').notNull(),
    explanationTemplateKey: varchar('explanation_template_key').notNull(),
    details: jsonb('details').notNull().default(sql`'{}'::jsonb`),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('idx_rule_findings_v2_run').on(table.analysisRunId),
    uniqueIndex('uq_rule_findings_v2_run_finding').on(table.analysisRunId, table.findingId),
  ],
);

export const ruleFindingEvidenceV2 = pgTable(
  'rule_finding_evidence_v2',
  {
    id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
    findingRowId: varchar('finding_row_id')
      .notNull()
      .references(() => ruleFindingsV2.id, { onDelete: 'cascade' }),
    sourcePage: integer('source_page').notNull(),
    sourceBlockIds: jsonb('source_block_ids').notNull(),
    sourceLabel: varchar('source_label'),
    rawTextSnippet: text('raw_text_snippet').notNull(),
    method: varchar('method').notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('idx_rule_finding_evidence_v2_finding').on(table.findingRowId)],
);

export const findingExplanationsV2 = pgTable(
  'finding_explanations_v2',
  {
    id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
    analysisRunId: varchar('analysis_run_id')
      .notNull()
      .references(() => analysisRunsV2.id, { onDelete: 'cascade' }),
    findingId: varchar('finding_id').notNull(),
    accountLabel: varchar('account_label').notNull(),
    humanSummary: text('human_summary').notNull(),
    statutes: text('statutes').array().notNull().default(sql`ARRAY[]::text[]`),
    disputeAngle: varchar('dispute_angle').notNull(),
    recommendedAction: text('recommended_action').notNull(),
    priority: integer('priority').notNull(),
    explanationConfidence: numeric('explanation_confidence', { precision: 5, scale: 4 }).notNull().default('0'),
    rawAiPayload: jsonb('raw_ai_payload'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('idx_finding_explanations_v2_run').on(table.analysisRunId),
    uniqueIndex('uq_finding_explanations_v2_run_finding').on(table.analysisRunId, table.findingId),
  ],
);

export const reviewQueueV2 = pgTable(
  'review_queue_v2',
  {
    id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
    analysisRunId: varchar('analysis_run_id')
      .notNull()
      .references(() => analysisRunsV2.id, { onDelete: 'cascade' }),
    scopeType: varchar('scope_type').notNull(), // field | entity | finding | letter
    scopeId: varchar('scope_id').notNull(),
    reason: text('reason').notNull(),
    priority: integer('priority').notNull().default(3),
    status: varchar('status').notNull().default('open'), // open | resolved | rejected
    assignedTo: varchar('assigned_to').references(() => users.id),
    resolutionNotes: text('resolution_notes'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    resolvedAt: timestamp('resolved_at'),
  },
  (table) => [index('idx_review_queue_v2_run').on(table.analysisRunId)],
);

export const disputeLetterItemsV2 = pgTable(
  'dispute_letter_items_v2',
  {
    id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
    disputeLetterId: varchar('dispute_letter_id')
      .notNull()
      .references(() => disputeLetters.id, { onDelete: 'cascade' }),
    findingId: varchar('finding_id').notNull(),
    entityId: varchar('entity_id').notNull(),
    accountLabel: varchar('account_label').notNull(),
    factualStatement: text('factual_statement').notNull(),
    evidenceSummary: text('evidence_summary').notNull(),
    statutes: text('statutes').array().notNull().default(sql`ARRAY[]::text[]`),
    requestedAction: varchar('requested_action').notNull(),
    confidence: numeric('confidence', { precision: 5, scale: 4 }).notNull().default('0'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('idx_dispute_letter_items_v2_letter').on(table.disputeLetterId)],
);

// Insert schemas
export const insertExtractionRunV2Schema = createInsertSchema(extractionRunsV2).omit({ id: true, createdAt: true });
export const insertDocumentPageV2Schema = createInsertSchema(documentPagesV2).omit({ id: true, createdAt: true });
export const insertDocumentBlockV2Schema = createInsertSchema(documentBlocksV2).omit({ id: true, createdAt: true });
export const insertAnalysisRunV2Schema = createInsertSchema(analysisRunsV2).omit({ id: true, startedAt: true, completedAt: true });
export const insertParsedReportSnapshotV2Schema = createInsertSchema(parsedReportSnapshotsV2).omit({ id: true, createdAt: true });
export const insertReportEntityV2Schema = createInsertSchema(reportEntitiesV2).omit({ id: true, createdAt: true });
export const insertEntityEvidenceV2Schema = createInsertSchema(entityEvidenceV2).omit({ id: true, createdAt: true });
export const insertAiVerificationTaskV2Schema = createInsertSchema(aiVerificationTasksV2).omit({ id: true, createdAt: true, resolvedAt: true });
export const insertRuleFindingV2Schema = createInsertSchema(ruleFindingsV2).omit({ id: true, createdAt: true });
export const insertRuleFindingEvidenceV2Schema = createInsertSchema(ruleFindingEvidenceV2).omit({ id: true, createdAt: true });
export const insertFindingExplanationV2Schema = createInsertSchema(findingExplanationsV2).omit({ id: true, createdAt: true });
export const insertReviewQueueV2Schema = createInsertSchema(reviewQueueV2).omit({ id: true, createdAt: true, resolvedAt: true });
export const insertDisputeLetterItemV2Schema = createInsertSchema(disputeLetterItemsV2).omit({ id: true, createdAt: true });

export type ExtractionRunV2 = typeof extractionRunsV2.$inferSelect;
export type InsertExtractionRunV2 = z.infer<typeof insertExtractionRunV2Schema>;
export type DocumentPageV2 = typeof documentPagesV2.$inferSelect;
export type InsertDocumentPageV2 = z.infer<typeof insertDocumentPageV2Schema>;
export type DocumentBlockV2 = typeof documentBlocksV2.$inferSelect;
export type InsertDocumentBlockV2 = z.infer<typeof insertDocumentBlockV2Schema>;
export type AnalysisRunV2 = typeof analysisRunsV2.$inferSelect;
export type InsertAnalysisRunV2 = z.infer<typeof insertAnalysisRunV2Schema>;
export type ParsedReportSnapshotV2 = typeof parsedReportSnapshotsV2.$inferSelect;
export type InsertParsedReportSnapshotV2 = z.infer<typeof insertParsedReportSnapshotV2Schema>;
export type ReportEntityV2 = typeof reportEntitiesV2.$inferSelect;
export type InsertReportEntityV2 = z.infer<typeof insertReportEntityV2Schema>;
export type EntityEvidenceV2 = typeof entityEvidenceV2.$inferSelect;
export type InsertEntityEvidenceV2 = z.infer<typeof insertEntityEvidenceV2Schema>;
export type AiVerificationTaskV2 = typeof aiVerificationTasksV2.$inferSelect;
export type InsertAiVerificationTaskV2 = z.infer<typeof insertAiVerificationTaskV2Schema>;
export type RuleFindingV2Row = typeof ruleFindingsV2.$inferSelect;
export type InsertRuleFindingV2 = z.infer<typeof insertRuleFindingV2Schema>;
export type RuleFindingEvidenceV2 = typeof ruleFindingEvidenceV2.$inferSelect;
export type InsertRuleFindingEvidenceV2 = z.infer<typeof insertRuleFindingEvidenceV2Schema>;
export type FindingExplanationV2 = typeof findingExplanationsV2.$inferSelect;
export type InsertFindingExplanationV2 = z.infer<typeof insertFindingExplanationV2Schema>;
export type ReviewQueueV2 = typeof reviewQueueV2.$inferSelect;
export type InsertReviewQueueV2 = z.infer<typeof insertReviewQueueV2Schema>;
export type DisputeLetterItemV2 = typeof disputeLetterItemsV2.$inferSelect;
export type InsertDisputeLetterItemV2 = z.infer<typeof insertDisputeLetterItemV2Schema>;
