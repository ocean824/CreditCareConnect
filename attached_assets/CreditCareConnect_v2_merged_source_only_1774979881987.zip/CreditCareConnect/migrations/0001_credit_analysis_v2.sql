CREATE TABLE IF NOT EXISTS "extraction_runs_v2" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "credit_report_id" varchar NOT NULL REFERENCES "credit_reports"("id") ON DELETE cascade,
  "method_summary" varchar NOT NULL,
  "provider_guess" varchar NOT NULL DEFAULT 'UNKNOWN',
  "tri_merge" boolean NOT NULL DEFAULT false,
  "bureaus_detected" text[] NOT NULL DEFAULT ARRAY[]::text[],
  "overall_confidence" numeric(5,4) NOT NULL DEFAULT '0',
  "warnings" jsonb NOT NULL DEFAULT '[]'::jsonb,
  "created_at" timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "idx_extraction_runs_v2_credit_report" ON "extraction_runs_v2" ("credit_report_id");
CREATE INDEX IF NOT EXISTS "idx_extraction_runs_v2_created_at" ON "extraction_runs_v2" ("created_at");

CREATE TABLE IF NOT EXISTS "document_pages_v2" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "extraction_run_id" varchar NOT NULL REFERENCES "extraction_runs_v2"("id") ON DELETE cascade,
  "page_number" integer NOT NULL,
  "method" varchar NOT NULL,
  "text" text NOT NULL,
  "char_count" integer NOT NULL DEFAULT 0,
  "text_density" numeric(10,4) NOT NULL DEFAULT '0',
  "confidence" numeric(5,4) NOT NULL DEFAULT '0',
  "layout_hints" text[] NOT NULL DEFAULT ARRAY[]::text[],
  "warnings" jsonb NOT NULL DEFAULT '[]'::jsonb,
  "created_at" timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "idx_document_pages_v2_run" ON "document_pages_v2" ("extraction_run_id");
CREATE UNIQUE INDEX IF NOT EXISTS "uq_document_pages_v2_run_page" ON "document_pages_v2" ("extraction_run_id", "page_number");

CREATE TABLE IF NOT EXISTS "document_blocks_v2" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "page_id" varchar NOT NULL REFERENCES "document_pages_v2"("id") ON DELETE cascade,
  "block_key" varchar NOT NULL,
  "text" text NOT NULL,
  "label_guess" varchar,
  "row_index" integer,
  "column_index" integer,
  "bbox" jsonb,
  "created_at" timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "idx_document_blocks_v2_page" ON "document_blocks_v2" ("page_id");
CREATE UNIQUE INDEX IF NOT EXISTS "uq_document_blocks_v2_page_key" ON "document_blocks_v2" ("page_id", "block_key");

CREATE TABLE IF NOT EXISTS "analysis_runs_v2" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "credit_report_id" varchar NOT NULL REFERENCES "credit_reports"("id") ON DELETE cascade,
  "extraction_run_id" varchar NOT NULL REFERENCES "extraction_runs_v2"("id") ON DELETE cascade,
  "parser_version" varchar NOT NULL,
  "rules_version" varchar NOT NULL,
  "ai_model" varchar,
  "status" varchar NOT NULL DEFAULT 'queued',
  "review_status" varchar NOT NULL DEFAULT 'human_review',
  "overall_confidence" numeric(5,4) NOT NULL DEFAULT '0',
  "summary" jsonb,
  "started_at" timestamp NOT NULL DEFAULT now(),
  "completed_at" timestamp
);
CREATE INDEX IF NOT EXISTS "idx_analysis_runs_v2_credit_report" ON "analysis_runs_v2" ("credit_report_id");
CREATE INDEX IF NOT EXISTS "idx_analysis_runs_v2_status" ON "analysis_runs_v2" ("status");

CREATE TABLE IF NOT EXISTS "parsed_report_snapshots_v2" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "analysis_run_id" varchar NOT NULL REFERENCES "analysis_runs_v2"("id") ON DELETE cascade,
  "canonical_report" jsonb NOT NULL,
  "overall_confidence" numeric(5,4) NOT NULL DEFAULT '0',
  "warnings" jsonb NOT NULL DEFAULT '[]'::jsonb,
  "created_at" timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "idx_parsed_report_snapshots_v2_run" ON "parsed_report_snapshots_v2" ("analysis_run_id");

CREATE TABLE IF NOT EXISTS "report_entities_v2" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "analysis_run_id" varchar NOT NULL REFERENCES "analysis_runs_v2"("id") ON DELETE cascade,
  "entity_id" varchar NOT NULL,
  "entity_type" varchar NOT NULL,
  "normalized_name" varchar,
  "match_key" varchar,
  "reconciliation_status" varchar NOT NULL DEFAULT 'ambiguous',
  "match_confidence" numeric(5,4) NOT NULL DEFAULT '0',
  "overall_confidence" numeric(5,4) NOT NULL DEFAULT '0',
  "entity_payload" jsonb NOT NULL,
  "created_at" timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "idx_report_entities_v2_run" ON "report_entities_v2" ("analysis_run_id");
CREATE UNIQUE INDEX IF NOT EXISTS "uq_report_entities_v2_run_entity" ON "report_entities_v2" ("analysis_run_id", "entity_id");

CREATE TABLE IF NOT EXISTS "entity_evidence_v2" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "analysis_run_id" varchar NOT NULL REFERENCES "analysis_runs_v2"("id") ON DELETE cascade,
  "entity_id" varchar NOT NULL,
  "field_path" varchar NOT NULL,
  "value_json" jsonb,
  "normalized_value_json" jsonb,
  "confidence" numeric(5,4) NOT NULL DEFAULT '0',
  "evidence_refs" jsonb NOT NULL,
  "warnings" jsonb NOT NULL DEFAULT '[]'::jsonb,
  "created_at" timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "idx_entity_evidence_v2_run" ON "entity_evidence_v2" ("analysis_run_id");
CREATE INDEX IF NOT EXISTS "idx_entity_evidence_v2_entity" ON "entity_evidence_v2" ("entity_id");

CREATE TABLE IF NOT EXISTS "ai_verification_tasks_v2" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "analysis_run_id" varchar NOT NULL REFERENCES "analysis_runs_v2"("id") ON DELETE cascade,
  "entity_id" varchar NOT NULL,
  "field_path" varchar NOT NULL,
  "current_value_json" jsonb,
  "candidate_values_json" jsonb NOT NULL,
  "status" varchar NOT NULL DEFAULT 'queued',
  "resolution_json" jsonb,
  "created_at" timestamp NOT NULL DEFAULT now(),
  "resolved_at" timestamp
);
CREATE INDEX IF NOT EXISTS "idx_ai_verification_tasks_v2_run" ON "ai_verification_tasks_v2" ("analysis_run_id");

CREATE TABLE IF NOT EXISTS "rule_findings_v2" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "analysis_run_id" varchar NOT NULL REFERENCES "analysis_runs_v2"("id") ON DELETE cascade,
  "finding_id" varchar NOT NULL,
  "rule_id" varchar NOT NULL,
  "family" varchar NOT NULL,
  "category" varchar NOT NULL,
  "severity" varchar NOT NULL,
  "entity_type" varchar NOT NULL,
  "entity_ids" jsonb NOT NULL,
  "affected_bureaus" text[] NOT NULL DEFAULT ARRAY[]::text[],
  "statutes" text[] NOT NULL DEFAULT ARRAY[]::text[],
  "dispute_angle" varchar NOT NULL,
  "requested_remedy" varchar NOT NULL,
  "confidence" numeric(5,4) NOT NULL DEFAULT '0',
  "review_status" varchar NOT NULL DEFAULT 'human_review',
  "description_machine" text NOT NULL,
  "explanation_template_key" varchar NOT NULL,
  "details" jsonb NOT NULL DEFAULT '{}'::jsonb,
  "created_at" timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "idx_rule_findings_v2_run" ON "rule_findings_v2" ("analysis_run_id");
CREATE UNIQUE INDEX IF NOT EXISTS "uq_rule_findings_v2_run_finding" ON "rule_findings_v2" ("analysis_run_id", "finding_id");

CREATE TABLE IF NOT EXISTS "rule_finding_evidence_v2" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "finding_row_id" varchar NOT NULL REFERENCES "rule_findings_v2"("id") ON DELETE cascade,
  "source_page" integer NOT NULL,
  "source_block_ids" jsonb NOT NULL,
  "source_label" varchar,
  "raw_text_snippet" text NOT NULL,
  "method" varchar NOT NULL,
  "created_at" timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "idx_rule_finding_evidence_v2_finding" ON "rule_finding_evidence_v2" ("finding_row_id");

CREATE TABLE IF NOT EXISTS "finding_explanations_v2" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "analysis_run_id" varchar NOT NULL REFERENCES "analysis_runs_v2"("id") ON DELETE cascade,
  "finding_id" varchar NOT NULL,
  "account_label" varchar NOT NULL,
  "human_summary" text NOT NULL,
  "statutes" text[] NOT NULL DEFAULT ARRAY[]::text[],
  "dispute_angle" varchar NOT NULL,
  "recommended_action" text NOT NULL,
  "priority" integer NOT NULL,
  "explanation_confidence" numeric(5,4) NOT NULL DEFAULT '0',
  "raw_ai_payload" jsonb,
  "created_at" timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "idx_finding_explanations_v2_run" ON "finding_explanations_v2" ("analysis_run_id");
CREATE UNIQUE INDEX IF NOT EXISTS "uq_finding_explanations_v2_run_finding" ON "finding_explanations_v2" ("analysis_run_id", "finding_id");

CREATE TABLE IF NOT EXISTS "review_queue_v2" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "analysis_run_id" varchar NOT NULL REFERENCES "analysis_runs_v2"("id") ON DELETE cascade,
  "scope_type" varchar NOT NULL,
  "scope_id" varchar NOT NULL,
  "reason" text NOT NULL,
  "priority" integer NOT NULL DEFAULT 3,
  "status" varchar NOT NULL DEFAULT 'open',
  "assigned_to" varchar REFERENCES "users"("id"),
  "resolution_notes" text,
  "created_at" timestamp NOT NULL DEFAULT now(),
  "resolved_at" timestamp
);
CREATE INDEX IF NOT EXISTS "idx_review_queue_v2_run" ON "review_queue_v2" ("analysis_run_id");

CREATE TABLE IF NOT EXISTS "dispute_letter_items_v2" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "dispute_letter_id" varchar NOT NULL REFERENCES "dispute_letters"("id") ON DELETE cascade,
  "finding_id" varchar NOT NULL,
  "entity_id" varchar NOT NULL,
  "account_label" varchar NOT NULL,
  "factual_statement" text NOT NULL,
  "evidence_summary" text NOT NULL,
  "statutes" text[] NOT NULL DEFAULT ARRAY[]::text[],
  "requested_action" varchar NOT NULL,
  "confidence" numeric(5,4) NOT NULL DEFAULT '0',
  "created_at" timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "idx_dispute_letter_items_v2_letter" ON "dispute_letter_items_v2" ("dispute_letter_id");
