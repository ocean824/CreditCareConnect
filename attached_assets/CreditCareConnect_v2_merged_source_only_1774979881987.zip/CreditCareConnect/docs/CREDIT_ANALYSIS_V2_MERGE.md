# Credit Analysis V2 Merge Notes

## What was added

This merge wires in a parallel V2 credit-analysis pipeline with:

- dedicated Drizzle schema: `shared/schema.credit-analysis-v2.ts`
- dedicated migration: `migrations/0001_credit_analysis_v2.sql`
- V2 document ingest/parsing/rules/letter stubs under `server/services/*` and `server/rules/v2/*`
- persistence wiring for V2 runs in `server/storage.ts`
- new routes in `server/routes.ts`

## New routes

- `POST /api/credit-reports/upload-v2`
- `POST /api/credit-reports/:id/reanalyze-v2`
- `GET /api/credit-reports/:id/analysis-v2/latest`

## Migration / deploy steps

1. Ensure `DATABASE_URL` is set.
2. Run the new migration, or run `npm run db:push` after verifying the schema array in `drizzle.config.ts`.
3. Deploy the app.

## Important current limitation

The V2 parser wiring is in place, but the provider-specific deterministic parsers are still stubs. The V2 path is therefore fully persisted and routable, but not yet a finished production-grade parser.

That means this merge establishes the architecture and storage foundation without replacing the current live parser.
