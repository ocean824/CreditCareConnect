
import fs from 'fs';

const defaultDB = {
  users: [
    { id: 1, email: "user@domain.com", password: "user1234", tier: "Premium", role: "user" },
    { id: 2, email: "admin@creditcare.com", password: "admin1234", tier: "Super", role: "admin" }
  ],
  files: [
    { id: 1, userId: 1, name: "report_march.pdf", uploaded: "2025-11-01" },
    { id: 2, userId: 1, name: "letter_dispute.png", uploaded: "2025-11-10" }
  ]
};

fs.writeFileSync('./server/db/mock.json', JSON.stringify(defaultDB, null, 2));
console.log("✅ Database has been reset.");
