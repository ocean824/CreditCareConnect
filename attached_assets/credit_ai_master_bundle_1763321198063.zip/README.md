# Credit AI Master Bundle

This bundle contains:

- A normalized credit report model
- A deterministic rules engine for FCRA/FDCPA/Metro 2 issue detection
- AI helpers to generate bureau and collector dispute letters
- A Postgres/Drizzle schema for storing reports, runs, issues, AI explanations, and letters
- Docs describing the GPT-5.1 prompt format and end-to-end flow

## Quick Start

```bash
npm install
npm run build
```

Then in your backend:

```ts
import { runAllRules } from "./credit-ai-master/src/rules/engine";
import {
  buildBureauDisputeLetters,
  buildCollectorDisputeLetters,
} from "./credit-ai-master/src/ai/disputeLetterGenerator";
```

Wire this to your GPT-5.1 calls and your existing Replit app.
