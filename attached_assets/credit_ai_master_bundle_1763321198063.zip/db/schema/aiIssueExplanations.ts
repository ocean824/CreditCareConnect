import { pgTable, uuid, text, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { analysisRuns } from "./analysisRuns";

export const aiIssueExplanations = pgTable("ai_issue_explanations", {
  id: uuid("id").defaultRandom().primaryKey(),
  runId: uuid("run_id")
    .references(() => analysisRuns.id)
    .notNull(),
  issueId: text("issue_id").notNull(),
  accountLabel: text("account_label").notNull(),
  humanSummary: text("human_summary").notNull(),
  statutes: text("statutes").array(),
  disputeAngle: text("dispute_angle").notNull(),
  recommendedAction: text("recommended_action").notNull(),
  priority: integer("priority").notNull(),
  rawAiPayload: jsonb("raw_ai_payload"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});
