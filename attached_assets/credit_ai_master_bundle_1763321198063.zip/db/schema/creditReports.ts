import { pgTable, uuid, text, timestamp, jsonb } from "drizzle-orm/pg-core";
import { users } from "./users";

export const creditReports = pgTable("credit_reports", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id")
    .references(() => users.id)
    .notNull(),
  provider: text("provider").notNull(),
  pulledAt: timestamp("pulled_at", { withTimezone: true }),
  sourceType: text("source_type"),
  sourceRef: text("source_ref"),
  normalizedReport: jsonb("normalized_report").notNull(),
  status: text("status").default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});
