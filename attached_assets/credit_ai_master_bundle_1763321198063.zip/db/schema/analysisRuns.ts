import { pgTable, uuid, text, timestamp, integer } from "drizzle-orm/pg-core";
import { creditReports } from "./creditReports";

export const analysisRuns = pgTable("analysis_runs", {
  id: uuid("id").defaultRandom().primaryKey(),
  reportId: uuid("report_id")
    .references(() => creditReports.id)
    .notNull(),
  engineVersion: text("engine_version").notNull(),
  aiModel: text("ai_model").notNull(),
  status: text("status").default("completed"),
  startedAt: timestamp("started_at", { withTimezone: true }).defaultNow(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  issueCount: integer("issue_count").default(0),
  aiIssueCount: integer("ai_issue_count").default(0),
  notes: text("notes"),
});
