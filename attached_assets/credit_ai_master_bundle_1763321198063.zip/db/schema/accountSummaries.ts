import { pgTable, uuid, text, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { analysisRuns } from "./analysisRuns";

export const accountSummaries = pgTable("account_summaries", {
  id: uuid("id").defaultRandom().primaryKey(),
  runId: uuid("run_id")
    .references(() => analysisRuns.id)
    .notNull(),
  accountLabel: text("account_label").notNull(),
  bureauIds: text("bureau_ids").array(),
  topIssueIds: text("top_issue_ids").array(),
  overallPriority: integer("overall_priority").notNull(),
  meta: jsonb("meta"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});
