import { pgTable, uuid, text, timestamp, jsonb } from "drizzle-orm/pg-core";
import { analysisRuns } from "./analysisRuns";

export const issues = pgTable("issues", {
  id: uuid("id").defaultRandom().primaryKey(),
  runId: uuid("run_id")
    .references(() => analysisRuns.id)
    .notNull(),
  issueId: text("issue_id").notNull(),
  ruleId: text("rule_id").notNull(),
  family: text("family").notNull(),
  category: text("category").notNull(),
  severity: text("severity").notNull(),
  affectedEntityType: text("affected_entity_type").notNull(),
  affectedBureaus: text("affected_bureaus").array(),
  affectedIds: jsonb("affected_ids"),
  statutes: text("statutes").array(),
  descriptionMachine: text("description_machine").notNull(),
  explanationKey: text("explanation_key").notNull(),
  details: jsonb("details"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});
