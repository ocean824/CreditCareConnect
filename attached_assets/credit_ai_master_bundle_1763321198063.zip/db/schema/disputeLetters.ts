import { pgTable, uuid, text, timestamp } from "drizzle-orm/pg-core";
import { analysisRuns } from "./analysisRuns";

export const disputeLetters = pgTable("dispute_letters", {
  id: uuid("id").defaultRandom().primaryKey(),
  runId: uuid("run_id")
    .references(() => analysisRuns.id)
    .notNull(),
  letterType: text("letter_type").notNull(),
  targetKind: text("target_kind").notNull(),
  bureau: text("bureau"),
  collectorName: text("collector_name"),
  recipientName: text("recipient_name").notNull(),
  recipientAddress: text("recipient_address").array().notNull(),
  subject: text("subject").notNull(),
  body: text("body").notNull(),
  relatedIssueIds: text("related_issue_ids").array(),
  channel: text("channel").default("draft"),
  status: text("status").default("draft"),
  click2mailJobId: text("click2mail_job_id"),
  lastSentAt: timestamp("last_sent_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});
