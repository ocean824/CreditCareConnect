# Flow: Upload → Parse → Rules → AI → Letters → Click2Mail

1. **Upload Report**
   - `POST /api/credit/upload`
   - Accepts raw vendor file or normalized `CreditReport` JSON.
   - Stores row in `credit_reports` with `normalized_report` JSONB.

2. **Analyze (Rules + AI)**
   - `POST /api/credit/analyze`
   - Load report by `reportId`.
   - Run `runAllRules(report)` → `IssueFlag[]`.
   - Load `RulesCatalog` via `getRulesCatalog()`.
   - Call GPT-5.1 with `report`, `issues`, `rulesCatalog` and prompt from `docs/ai_prompt_gpt5_issue_explanations.md`.
   - Parse response → `issueExplanations`, `accountSummaries`.
   - Insert `analysis_runs`, `issues`, `ai_issue_explanations`, `account_summaries` rows.

3. **Generate Letters**
   - `POST /api/credit/letters`
   - Load latest analysis run for report.
   - Build bureau contacts (Experian, Equifax, TransUnion).
   - Build collector contacts from known collectors + report collections.
   - Call:
     - `buildBureauDisputeLetters(...)`
     - `buildCollectorDisputeLetters(...)`
   - Insert `dispute_letters` rows with `status = 'draft'`.

4. **Send via Click2Mail**
   - `POST /api/letters/click2mail`
   - Load `dispute_letters` row by `letterId`.
   - Render to PDF/HTML per Click2Mail API.
   - Send using Click2Mail credentials from env vars.
   - Update letter `status` and `click2mail_job_id`.

5. **Dashboard**
   - Use `credit_reports`, `analysis_runs`, `issues`, `ai_issue_explanations`, `account_summaries`, `dispute_letters` to show history and status for each user.
