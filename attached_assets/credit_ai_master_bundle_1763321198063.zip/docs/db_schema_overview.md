# Database Schema Overview

Core tables:

- `users`
- `credit_reports`
- `analysis_runs`
- `issues`
- `ai_issue_explanations`
- `account_summaries`
- `dispute_letters`

Use Drizzle ORM schemas in `db/schema` for Postgres.

Typical dashboard queries:

- List reports per user
- List runs per report
- Issues by severity per run
- Join `issues` ↔ `ai_issue_explanations` for AI-enhanced detail
- Letters per run with status and send history
